#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include "enet/enet.h"
#include "Server_player.h"
#include "Server_world.h"
#include <cmath>
#include <string>
#include <windows.h>
#include <vector>
#include <ctime>
#include <time.h>
#include <sstream>
#include <chrono>
#include <fstream>
#include "json.hpp"
#include <conio.h>
#include <thread>
#include <experimental/filesystem>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <regex>
#include <filesystem>
#include <wininet.h>
#include <cstring>
#include <locale>
#include <stdexcept>

void sendTileUpdate(int x, int y, int tile, int causedBy, ENetPeer* peer)
{
	if (serverIsFrozen == true) return;
	if (tile > itemDefs.size()) {
		return;
	}
	if (!((PlayerInfo*)(peer->data))->haveGrowId)
	{
		Player::OnConsoleMessage(peer, "`5[GTOS]: `4Create your account first");
		return;
	}
	if (((PlayerInfo*)(peer->data))->isIn == false)
	{
		Player::OnConsoleMessage(peer, "`5[GTOS]: `4Dumb haxor lol");
		return;
	}
	if (((PlayerInfo*)(peer->data))->dotrade == true || ((PlayerInfo*)(peer->data))->istrading == true)
	{
		Player::OnTextOverlay(peer, "You cant do that while trading!");
		return;
	}
	//bool isLock = false;
	PlayerMoving data;
	//data.packetType = 0x14;
	data.packetType = 0x3;
	//data.characterState = 0x924; // animation
	data.characterState = 0x0; // animation
	data.x = x;
	data.y = y;
	data.punchX = x;
	data.punchY = y;
	data.XSpeed = 0;
	data.YSpeed = 0;
	data.netID = causedBy;
	data.plantingTree = tile;
	WorldInfo* world = getPlyersWorld(peer);
	if (world == NULL) return;
	if (((PlayerInfo*)(peer->data))->currentWorld == "EXIT") return;
	if (x<0 || y<0 || x>world->width - 1 || y>world->height - 1 || tile > itemDefs.size()) return; // needs - 1
	sendNothingHappened(peer, x, y);
	if (((PlayerInfo*)(peer->data))->cloth_hand == 9482)
	{
		if (((PlayerInfo*)(peer->data))->rawName == world->owner && ((PlayerInfo*)(peer->data))->haveGrowId == true) {
			int xlast = ((PlayerInfo*)(peer->data))->lastPunchX = x;
			int ylast = ((PlayerInfo*)(peer->data))->lastPunchX = y;
			changetile(peer, xlast, ylast);
			int hi = ((PlayerInfo*)(peer->data))->lastPunchX;
			int hi2 = ((PlayerInfo*)(peer->data))->lastPunchY;
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (isHere(peer, currentPeer)) {
					Player::OnParticleEffect(currentPeer, 170, hi, hi2, 0);
				}
			}
		}
	}
	if (world->items[x + (y * world->width)].foreground == 2946 && tile != 18 && tile != 32 && tile > 0) {
	if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
		using namespace std::chrono;
		if (((PlayerInfo*)(peer->data))->lastDISPLAY + 1000 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
		{
			((PlayerInfo*)(peer->data))->lastDISPLAY = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
			bool iscontains = false;
			SearchInventoryItem(peer, tile, 1, iscontains);
			if (!iscontains)
			{
				Player::OnTextOverlay(peer, "Failed to display item!");
				return;
			}
			else {
				if (((PlayerInfo*)(peer->data))->dotrade == true || ((PlayerInfo*)(peer->data))->istrading == true)
				{
					Player::OnTextOverlay(peer, "You cant do that while trading!");
					return;
				}
				((PlayerInfo*)(peer->data))->blockx = x;
				((PlayerInfo*)(peer->data))->blocky = y;
				int hi = data.punchX;
				int hi2 = data.punchY;
				short dfg = world->items[x + (y*world->width)].foreground;
				short dbg = world->items[x + (y*world->width)].background;
				world->items[x + (y * world->width)].displayblock = tile;
				int n = tile;
				if (n == 6336 || n == 8552 || n == 9472 || n == 9482 || n == 9356 || n == 9492 || n == 9498 || n == 8774 || n == 1790 || n == 2592 || n == 1784 || n == 1792 || n == 1794 || n == 7734 || n == 8306 || n == 9458)
				{
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You can't display untradeable items.", 0, true);
					return;
				}
				if (getItemDef(n).blockType == BlockTypes::LOCK || n == 2946)
				{
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "Sorry, no displaying Display Blocks or Locks.", 0, true);
					return;
				}
				int squaresign = ((PlayerInfo*)(peer->data))->blockx + (((PlayerInfo*)(peer->data))->blocky * 100);
				string world = ((PlayerInfo*)(peer->data))->currentWorld;
				string receivedid;
				string currentworld = world + "X" + std::to_string(squaresign);
				ifstream getdisplay("display/" + currentworld + ".txt");
				getdisplay >> receivedid;
				getdisplay.close();

				bool displayexist = std::experimental::filesystem::exists("display/" + currentworld + ".txt");
				if (displayexist) {
					if (receivedid != "")
					{
						Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "Remove what's in there first!", 0, true);
					}
					else {
						ENetPeer* currentPeer;
						for (currentPeer = server->peers;
							currentPeer < &server->peers[server->peerCount];
							++currentPeer)
						{
							if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
								continue;
							if (isHere(peer, currentPeer)) {
								SendDisplayBlock(currentPeer, dfg, dbg, hi, hi2, n);
							}
						}
						ofstream displayupdate("display/" + world + "X" + std::to_string(squaresign) + ".txt");
						displayupdate << n;
						displayupdate.close();
						RemoveInventoryItem(n, 1, peer);
						updateplayerset(peer, n);
					}
				}
				else {
					ENetPeer* currentPeer;
					for (currentPeer = server->peers;
						currentPeer < &server->peers[server->peerCount];
						++currentPeer)
					{
						if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
							continue;
						if (isHere(peer, currentPeer)) {
							SendDisplayBlock(currentPeer, dfg, dbg, hi, hi2, n);
						}
					}
					ofstream displayinsert("display/" + world + "X" + std::to_string(squaresign) + ".txt");
					displayinsert << n;
					displayinsert.close();
					RemoveInventoryItem(n, 1, peer);
					updateplayerset(peer, n);
				}
				return;
			}
		}
		else {
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "Slow down while using display blocks!", 0, true);
			return;
		}
	  }
	  else {
		if (world->owner == "")
		{
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "This area must be locked to put your item on display!", 0, true);
		}
		else if (getPlyersWorld(peer)->isPublic)
		{
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "That area is owned by " + world->owner + "", 0, true);
		}
		else {
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "That area is owned by " + world->owner + "", 0, true);
		}
	  return;
	 }
	}
	if (world->items[x + (y * world->width)].foreground == 2946 && tile == 32)
	{
		if (((PlayerInfo*)(peer->data))->rawName == world->owner || world->owner == "" || getPlyersWorld(peer)->isPublic) {
			int itemid = world->items[x + (y * world->width)].foreground;
			int itembg = world->items[x + (y * world->width)].background;
			string world = ((PlayerInfo*)(peer->data))->currentWorld;
			((PlayerInfo*)(peer->data))->blockx = x;
			((PlayerInfo*)(peer->data))->blocky = y;
			int squaresign = ((PlayerInfo*)(peer->data))->blockx + (((PlayerInfo*)(peer->data))->blocky * 100);
			((PlayerInfo*)(peer->data))->displayfg = itemid;
			((PlayerInfo*)(peer->data))->displaybg = itembg;
			((PlayerInfo*)(peer->data))->displaypunchx = data.punchX;
			((PlayerInfo*)(peer->data))->displaypunchy = data.punchY;
			string receivedid;
			string currentworld = world + "X" + std::to_string(squaresign);
			ifstream getdisplay("display/" + currentworld + ".txt");
			getdisplay >> receivedid;
			getdisplay.close();
			bool displayexist = std::experimental::filesystem::exists("display/" + currentworld + ".txt");
			if (getPlyersWorld(peer)->isPublic && displayexist && ((PlayerInfo*)(peer->data))->rawName != getPlyersWorld(peer)->owner)
			{
				Player::OnDialogRequest(peer, "add_label_with_icon|big|`wDisplay Block|left|" + to_string(itemid) + "|\nadd_spacer|small||\nadd_label|small|`oA " + getItemDef(stoi(receivedid)).name + " is on display here.|\nadd_button|chc000|Okay|0|0|\nadd_quick_exit|\n");
			}
			else if (displayexist && ((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				Player::OnDialogRequest(peer, "add_label_with_icon|big|`wDisplay Block|left|" + to_string(itemid) + "|\nadd_spacer|small||\nadd_label|small|`oA " + getItemDef(stoi(receivedid)).name + " is on display here.|\nadd_button|pickupdisplayitem|Pick it up|0|0|\nadd_quick_exit|\n");
			}
			else if (getPlyersWorld(peer)->owner == "" && displayexist)
			{
				Player::OnDialogRequest(peer, "add_label_with_icon|big|`wDisplay Block|left|" + to_string(itemid) + "|\nadd_spacer|small||\nadd_label|small|`oA " + getItemDef(stoi(receivedid)).name + " is on display here.|\nadd_button|pickupdisplayitem|Pick it up|0|0|\nadd_quick_exit|\n");
			}
			else {
				Player::OnDialogRequest(peer, "add_label_with_icon|big|`wDisplay Block|left|" + to_string(itemid) + "|\nadd_spacer|small||\nadd_label|small|`oThe Display Block is empty. Use an item on it to display the item!|\nend_dialog||Close||\n");
			}
			return;
		}
		else {
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "That area is owned by " + world->owner + "", 0, true);
			return;
		}
	}
	if (world->items[x + (y * world->width)].foreground == 2946 && tile == 18)
	{
		if (getPlyersWorld(peer)->isPublic || find(world->worldaccess.begin(), world->worldaccess.end(), ((PlayerInfo*)(peer->data))->rawName) != world->worldaccess.end())
		{
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "That area is owned by " + world->owner + "", 0, true);
			return;
		}
	}
	if (world != NULL) {
		if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::DOOR)
		{
			if (world->owner != "") {
				if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
					if (tile == 32) {
						((PlayerInfo*)(peer->data))->wrenchsession = x + (y * world->width);
						WorldItem item = world->items[x + (y * world->width)];
						string a = item.destWorld + ":" + item.destId;
						if (a == ":") a = "";
						if (item.foreground == 762 || item.foreground == 4190)
						{
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit Password Door``|left|" + to_string(item.foreground) + "|\n\nadd_text_input|dest|`oTarget World|" + a + "|100|\nadd_text_input|label|Display Label (optional)|" + item.label + "|100|\nadd_text_input|doorpw|Password|" + item.password + "|35|\nend_dialog|editpdoor|Cancel|OK|");
						}
						else {
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit Door``|left|" + to_string(item.foreground) + "|\|\n\nadd_text_input|dest|`oTarget World|" + a + "|100|\nadd_text_input|label|Display Label (optional)|" + item.label + "|100|\nadd_text_input|doorid|ID (optional)|" + item.currId + "|35|\nend_dialog|editdoor|Cancel|OK|");
						}
					}
				}
			}
		}
		if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::SIGN)
		{
			if (tile == 32) {
				((PlayerInfo*)(peer->data))->wrenchx = x;
				((PlayerInfo*)(peer->data))->wrenchy = y;
				if (((PlayerInfo*)(peer->data))->rawName == PlayerDB::getProperName(world->owner) || find(world->worldaccess.begin(), world->worldaccess.end(), ((PlayerInfo*)(peer->data))->rawName) != world->worldaccess.end()) {
					string world = ((PlayerInfo*)(peer->data))->currentWorld;
					int squaresign = ((PlayerInfo*)(peer->data))->wrenchx + (((PlayerInfo*)(peer->data))->wrenchy * 100);
					bool exist = std::experimental::filesystem::exists("signs/" + world + "X" + to_string(squaresign) + ".txt");
					if (exist)
					{
						ifstream ifs("signs/" + world + "X" + to_string(squaresign) + ".txt");
						string content = "error";
						getline(ifs, content);
						ifs.close();
						Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit Sign``|left|20|\nadd_label|small|`oWhat would you like to write on this sign?|left|4|\nadd_text_input|ch3||" + content + "|100|\nembed_data|tilex|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchx) + "\nembed_data|tiley|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchy) + "\nend_dialog|sign_edit|Cancel|OK|");
						return;
					}
					else
					{
						Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit Sign``|left|20|\nadd_label|small|`oWhat would you like to write on this sign?|left|4|\nadd_text_input|ch3|||100|\nembed_data|tilex|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchx) + "\nembed_data|tiley|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchy) + "\nend_dialog|sign_edit|Cancel|OK|");
						return;
					}
				}
			}
		}

		string name = getItemDef(world->items[x + (y * world->width)].foreground).name;
		int id = getItemDef(world->items[x + (y * world->width)].foreground).id;
		if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::GATEWAY || world->items[x + (y * world->width)].foreground == 224 || world->items[x + (y * world->width)].foreground == 5036 || world->items[x + (y * world->width)].foreground == 3126 || world->items[x + (y * world->width)].foreground == 1162 || world->items[x + (y * world->width)].foreground == 3799 || world->items[x + (y * world->width)].foreground == 3798 || world->items[x + (y * world->width)].foreground == 7066 || world->items[x + (y * world->width)].foreground == 5820 || world->items[x + (y * world->width)].foreground == 5818 || world->items[x + (y * world->width)].foreground == 686) {

			if (tile == 32) {
				if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
					((PlayerInfo*)(peer->data))->wrenchx = x;
					((PlayerInfo*)(peer->data))->wrenchy = y;

					if (world->items[x + (y * world->width)].isOpened == false) {
						Player::OnDialogRequest(peer, "add_label_with_icon|big|" + name + "|left|" + to_string(id) + "|\nadd_spacer|small|\nadd_checkbox|opentopublic|`ois Open to Public?|0|\nend_dialog|entrance||OK|\n");
					}
					else {
						Player::OnDialogRequest(peer, "add_label_with_icon|big|" + name + "|left|" + to_string(id) + "|\nadd_spacer|small|\nadd_checkbox|opentopublic|`ois Open to Public?|1|\nend_dialog|entrance||OK|\n");
					}
				}
			}
		}
	}
	if (tile == 6336)
	{
		string skillgroup = ((PlayerInfo*)(peer->data))->skill;

		string rankgroup = "";
		if (((PlayerInfo*)(peer->data))->adminLevel == 0)
		{
			rankgroup = "Newbie";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 111)
		{
			rankgroup = "Warrior";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 222)
		{
			rankgroup = "Samurai";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 333)
		{
			rankgroup = "Ninja";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 444)
		{
			rankgroup = "King";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 555)
		{
			rankgroup = "VIP";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 666)
		{
			rankgroup = "Premium";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 777)
		{
			rankgroup = "Moderator";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 888)
		{
			rankgroup = "Admin";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 998)
		{
			rankgroup = "Youtuber";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 999)
		{
			rankgroup = "Leader";
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 1000)
		{
			if (((PlayerInfo*)(peer->data))->isCreator == true)
			{
				rankgroup = "Creator";
			}
			else {
				rankgroup = "Guardian";
			}
		}
		else
		{
			rankgroup = "Unknown";
		}
		int killscount = 0;
		if (((PlayerInfo*)(peer->data))->haveGrowId == true)
		{

			ifstream fileStream213("kills/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
			fileStream213 >> killscount;
			fileStream213.close();

		}
		Player::OnDialogRequest(peer, "set_default_color|`o\nadd_label_with_icon|big|`wWelcome Back `9" + ((PlayerInfo*)(peer->data))->rawName + "`w!|left|18|\nadd_spacer|small|\nadd_label|small|`^Your current `2Skill `^Group:`w " + skillgroup + "|left|4|\nadd_button|changeskillgroup|`!Choose Skill Group|0|0|\nadd_spacer|small|\nadd_label|small|`^Your current `2Rank`^:`w " + rankgroup + "|left|4|\nadd_button|rankupmenu|`!Rankup|0|0|\nadd_spacer|small|\nadd_label|small|`^Your current `2Level`^:`w " + std::to_string(((PlayerInfo*)(peer->data))->level) + "|left|4|\nadd_button|lvluprewards|`!Level Rewards|0|0|\nadd_spacer|small|\nadd_label|small|`^Your current `2Kills `^Count:`w " + std::to_string(killscount) + "|left|4|\nadd_button|killrewards|`!Kill Rewards|0|0|\nadd_spacer|small|\nadd_label|small|`^You can upgrade digger spade to better ones! Click the button below for more information|left|4|\nadd_button|diggerupgrademenu|`!Upgrade Digger Spade|0|0|\nadd_spacer|small|\nadd_button||Continue|0|0|\nadd_quick_exit");
		return;
	}
	if (tile == 764) {
		if (((PlayerInfo*)(peer->data))->isZombie == true) return;

		if (((PlayerInfo*)(peer->data))->canWalkInBlocks == true)
		{
			((PlayerInfo*)(peer->data))->canWalkInBlocks = false;
			((PlayerInfo*)(peer->data))->skinColor = 0x8295C3FF;
			sendState(peer);
		}

		sendSound(peer, "skel.wav");
		Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`@You have been `4Infected`@, Now you can `4Infect `@Others by Punching Them.", 0, true);
		((PlayerInfo*)(peer->data))->isZombie = true;
		sendState(peer);
		RemoveInventoryItem(764, 1, peer);
		playerconfig(peer, 1150, 130, 0x14);
		return;
	}
	if (tile == 782)
	{
		if (((PlayerInfo*)(peer->data))->isZombie == false) return;

		((PlayerInfo*)(peer->data))->isZombie = false;
		sendState(peer);
		RemoveInventoryItem(782, 1, peer);
		playerconfig(peer, 1150, 300, 0x14);
		return;
	}
	if (tile == 32 || tile == 18)
	{
		if (world->items[x + (y * world->width)].foreground == 9288) {
			Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wThe Underground Trader``|left|9288|0|0|\n\nadd_spacer|small|\nadd_textbox|`oWelcome Traveler! Here you can exchange `bDark Fragments `oInto `9Powerful `oItems Or Blocks! Click `^View Offers `oTo See!|\n\nadd_spacer|small|\nadd_button|undergroundtrader|`9View Offers|0|0|\nadd_quick_exit|");
		}
	}
	if (tile == 2410)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, 2410, 200, iscontains);
		if (!iscontains)
		{
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oYou will need more `^Emerald Shards `oFor that!", 0, true);
		}
		else {
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oThe power of `^Emerald Shards `oCompressed into `2Emerald Lock`o!", 0, true);
			RemoveInventoryItem(2410, 200, peer);
			bool success = true;
			SaveItemMoreTimes(2408, 1, peer, success);
			Player::OnConsoleMessage(peer, "`o>> You received emerald lock!");
		}
	}
	if (tile == 4426)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, 4426, 200, iscontains);
		if (!iscontains)
		{
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oYou will need more `4Ruby Shards `oFor that!", 0, true);
		}
		else {
			Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oThe power of `4Ruby Shards `oCompressed into `4Ruby Lock`o!", 0, true);
			RemoveInventoryItem(4426, 200, peer);
			bool success = true;
			SaveItemMoreTimes(4428, 1, peer, success);
			Player::OnConsoleMessage(peer, "`o>> You received ruby lock!");
		}
	}
	int xx = data.punchX;
	int yy = data.punchY;
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (tile == 274 && ((PlayerInfo*)(currentPeer->data))->x / 32 == xx && ((PlayerInfo*)(currentPeer->data))->y / 32 == yy)
		{
			bool iscontainseas = false;
			SearchInventoryItem(peer, 274, 1, iscontainseas);
			if (!iscontainseas)
			{
				autoBan(peer, false, 24 * 7, "failed to find 274 item in sendtileupdate");
				break;
			}
			else {
				RemoveInventoryItem(274, 1, peer);
				((PlayerInfo*)(currentPeer->data))->isFrozen = true;
				((PlayerInfo*)(currentPeer->data))->skinColor = -37500;
				sendClothes(currentPeer);
				sendFrozenState(currentPeer);
				GamePacket pf = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`wSHUSH... pretty cold here. `!(Frozen)`w mod added."));
				ENetPacket* packetf = enet_packet_create(pf.data,
					pf.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packetf);
				delete pf.data;
			}
		}
		if (tile == 276 && ((PlayerInfo*)(currentPeer->data))->x / 32 == xx && ((PlayerInfo*)(currentPeer->data))->y / 32 == yy)
		{
			bool iscontainseas = false;
			SearchInventoryItem(peer, 276, 1, iscontainseas);
			if (!iscontainseas)
			{
				autoBan(peer, false, 24 * 7, "failed to find 276 item in sendtileupdate");
				break;
			}
			else {
				RemoveInventoryItem(276, 1, peer);
				playerRespawn(currentPeer, true);
				int hi = ((PlayerInfo*)(currentPeer->data))->x;
				int hi2 = ((PlayerInfo*)(currentPeer->data))->y;
				Player::OnParticleEffect(currentPeer, 152, hi, hi2, 0);
				Player::OnParticleEffect(currentPeer, 4, hi, hi2, 0);
			}
		}
		if (tile == 732 && ((PlayerInfo*)(currentPeer->data))->x / 32 == xx && ((PlayerInfo*)(currentPeer->data))->y / 32 == yy)
		{
			bool iscontainseas = false;
			SearchInventoryItem(peer, 732, 1, iscontainseas);
			if (!iscontainseas)
			{
				autoBan(peer, false, 24 * 7, "failed to find 732 item in sendtileupdate");
				break;
			}
			else {
				RemoveInventoryItem(732, 1, peer);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`#** `$The Ancient Ones `ohave `4banned `w" + ((PlayerInfo*)(currentPeer->data))->rawName + " `#** `o(`4/rules `oto see the rules!)"));
				ENetPeer* currentPeer2;
				time_t now = time(0);
				char* dt = ctime(&now);
				for (currentPeer2 = server->peers;
					currentPeer2 < &server->peers[server->peerCount];
					++currentPeer2)
				{
					if (currentPeer2->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (((PlayerInfo*)(currentPeer2->data))->haveGrowId == false) continue;
					if (((PlayerInfo*)(currentPeer->data))->rawName == ((PlayerInfo*)(currentPeer2->data))->rawName)
					{
						GamePacket ps2 = packetEnd(appendInt(appendString(appendString(appendString(appendString(createPacket(), "OnAddNotification"), "interface/atomic_button.rttex"), "`0Warning from `4System`0: You've been `4BANNED `0from GrowtopiaOS for 730 days"), "audio/hub_open.wav"), 0));
						ENetPacket* packet2 = enet_packet_create(ps2.data,
							ps2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer2, 0, packet2);
						GamePacket ps3 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`oWarning from `4System`o: You've been `4BANNED `ofrom GrowtopiaOS for 730 days"));
						ENetPacket* packet3 = enet_packet_create(ps3.data,
							ps3.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer2, 0, packet3);
						GamePacket pto = packetEnd(appendString(appendString(createPacket(), "OnTextOverlay"), "Applied punishment on " + ((PlayerInfo*)(currentPeer2->data))->rawName + "."));
						ENetPacket* packetto = enet_packet_create(pto.data,
							pto.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(peer, 0, packetto);
						if (((PlayerInfo*)(currentPeer2->data))->haveGrowId) {
							PlayerInfo* p = ((PlayerInfo*)(currentPeer2->data));
							p->ban = 1;
							string username = PlayerDB::getProperName(p->rawName);
							std::ifstream ifff("players/" + ((PlayerInfo*)(currentPeer2->data))->rawName + ".json");
							if (ifff.fail()) {
								ifff.close();
							}
							if (ifff.is_open()) {
							}
							json j;
							ifff >> j;
							int effect = p->effect;
							j["isBanned"] = 1;
							std::ofstream o("players/" + ((PlayerInfo*)(currentPeer2->data))->rawName + ".json"); //save
							if (!o.is_open()) {
								cout << GetLastError() << endl;
								_getch();
							}
							o << j << std::endl;
							string bannamed = ((PlayerInfo*)(currentPeer2->data))->rawName;
							std::ofstream outfile("bans/" + bannamed + ".txt");
							outfile << "user who banned this ID: " + ((PlayerInfo*)(peer->data))->rawName;
							outfile.close();
						}
						enet_peer_disconnect_later(currentPeer2, 0);
					}
					ENetPacket* packet7 = enet_packet_create(p7.data,
						p7.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer2, 0, packet7);

				}
			}
		}
		if (tile == 278 && ((PlayerInfo*)(currentPeer->data))->x / 32 == xx && ((PlayerInfo*)(currentPeer->data))->y / 32 == yy)
		{
			bool iscontainseas = false;
			SearchInventoryItem(peer, 278, 1, iscontainseas);
			if (!iscontainseas)
			{
				autoBan(peer, false, 24 * 7, "failed to find 278 item in sendtileupdate");
				break;
			}
			else {
				RemoveInventoryItem(278, 1, peer);
				string cursename = ((PlayerInfo*)(currentPeer->data))->rawName;
				bool existx = std::experimental::filesystem::exists("players/" + PlayerDB::getProperName(cursename) + ".json");
				if (!existx)
				{
					continue;
				}
				std::ofstream outfile("cursedplayers/" + cursename + ".txt");
				outfile << "caused by: " + ((PlayerInfo*)(peer->data))->rawName;
				outfile.close();
				if (((PlayerInfo*)(currentPeer->data))->haveGrowId == false && ((PlayerInfo*)(currentPeer->data))->haveGuestId == false) continue;
				Player::OnConsoleMessage(currentPeer, "`#** `$The Ancient Ones `ohave used `#Curse `oon `2" + ((PlayerInfo*)(currentPeer->data))->rawName + "`o! `#**");
				Player::OnAddNotification(currentPeer, "`0Warning from `4System`0: You've been `bCURSED `0from GrowtopiaOS.", "audio/explode.wav", "interface/hommel.rttex");
				Player::OnConsoleMessage(currentPeer, "`oWarning from `4System`o: You've been `bCursed `ofrom GrowtopiaOS by `2" + ((PlayerInfo*)(peer->data))->rawName + "`o.");
				((PlayerInfo*)(currentPeer->data))->isCursed = true;
				sendPlayerToWorld(currentPeer, (PlayerInfo*)(currentPeer->data), "HELL");
			}
		}
	}
	if (tile == 32)
	{
		if (world->items[x + (y * world->width)].foreground == 9418) {
			if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
				UpdateLocalPlayerGems(peer);
				int gem = ((PlayerInfo*)(peer->data))->plantgems;
				Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Gem Storage``|left|9418|0|0|\n\nadd_spacer|small|\nadd_textbox|`#Gem Storage `oAllows you to `9Store Gems `oIn It! You can store as many as you want! `w[`4Warning`w] `oThis `9Storage `oIs personal, Other `9Players `oIn your world `@Won't `oBe able to `@Collect/Add `9Gems`o! If you will `^Sell `oYour `9world `oYour `9Gems `4WILL BE STILL `oIn your `9Account`o!|\n\nadd_spacer|small|\nadd_textbox|`oCurrently Stored `9Gems `2" + to_string(gem) + "`o!|\n\nadd_spacer|small|\nadd_button|collectgems|`9Collect|\nadd_button|addgems|`9Add Gems|0|0|\nadd_quick_exit|");
			}
			else {
				Player::OnTextOverlay(peer, "`#You must be world owner to use `#Gem Storage`#!");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 1790)
		{
			if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
				string cQuest = "None";
				ifstream fileStream213("quests/currentquest/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
				fileStream213 >> cQuest;
				fileStream213.close();
				if (cQuest == "None")
				{
					Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Legendary Wizard``|left|1790|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Select a `^Quest `5Which you want to complete, each `^Quest `5Has `210 `5Steps, after completing all of them you will earn the `^Quest Item`5!|\n\nadd_spacer|small|\nadd_button|questkatana|`9Quest For Legendary Katana|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
				}
				else if (cQuest == "Katana")
				{
					int sQuest = 1;
					ifstream fileStream216("quests/currentqueststep/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
					fileStream216 >> sQuest;
					fileStream216.close();
					if (sQuest == 1)
					{
						int s1Quest = 0;
						ifstream fileStream216("quests/katana/step1/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fileStream216 >> s1Quest;
						fileStream216.close();
						std::ifstream ifsz("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						std::string content((std::istreambuf_iterator<char>(ifsz)),
							(std::istreambuf_iterator<char>()));
						int b = atoi(content.c_str());
						int togive = 3000000 - s1Quest;
						int cangive = b - togive;
						if (cangive >= 0)
						{
							cangive = 3000000 - s1Quest;
						}
						else {
							cangive = b;
						}
						Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 1: Welcome adventurer, your first `^Quest `5Will be to bring me `43m `9Gems`5, Hope that not too much for you`5!|\nadd_textbox|`5Progress: `^" + to_string(s1Quest) + "/3000000 `5Gems|\nadd_button|s1sgemsgive|`9Give `^" + to_string(cangive) + " `9Gems|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
					}
					else if (sQuest == 2)
					{
						int s2Quest = 0;
						ifstream fileStream216("quests/katana/step2/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fileStream216 >> s2Quest;
						fileStream216.close();
						if (s2Quest < 50000)
						{
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 2: This step will be maybe more challenging, but i want you to earn `450k `5Experience`5!|\nadd_textbox|`5Progress: `^" + to_string(s2Quest) + "/50000 `5Experience|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
						else {
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 2: This step will be maybe more challenging, but i want you to earn `450k `5Experience`5!|\nadd_textbox|`5Progress: `^50000/50000 `5Experience|\nadd_button|s2scomplete|`9Complete!|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}

					}
					else if (sQuest == 3)
					{
						int s3Quest = 0;
						ifstream fileStream216("quests/katana/step3/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fileStream216 >> s3Quest;
						fileStream216.close();
						if (s3Quest < 3)
						{
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 3: I challenge you to earn `43 `5Store Tokens, You can keep them. I'm more popular than you can imagine`5!|\nadd_textbox|`5Progress: `^" + to_string(s3Quest) + "/3 `5Store Tokens|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
						else {
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 3: I challenge you to earn `43 `5Store Tokens, You can keep them. I'm more popular than you can imagine`5!|\nadd_textbox|`5Progress: `^3/3 `5Store Tokens|\nadd_button|s3scomplete|`9Complete!|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}

					}
					else if (sQuest == 4)
					{
						int s4Quest = 0;
						ifstream fileStream216("quests/katana/step4/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fileStream216 >> s4Quest;
						fileStream216.close();
						bool iscontains = false;
						SearchInventoryItem(peer, 9430, 1, iscontains);
						if (!iscontains)
						{
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 4: I challenge you to bring me `4One `5Golden Digger Spade`5!|\nadd_textbox|`5Progress: `^" + to_string(s4Quest) + "/1 `5Golden Digger Spade|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
						else {
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 4: I challenge you to bring me `4One `5Golden Digger Spade`5!|\nadd_textbox|`5Progress: `^1/1 `5Golden Digger Spade|\nadd_button|s4scomplete|`9Complete!|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
					}
					else if (sQuest == 5)
					{
						int s5Quest = 0;
						ifstream fileStream216("quests/katana/step5/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fileStream216 >> s5Quest;
						fileStream216.close();
						bool iscontains = false;
						SearchInventoryItem(peer, 1794, 1, iscontains);
						if (!iscontains)
						{
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 5: Congratulations on Beating all of my Steps, Now bring me The Legendary Orb`5!|\nadd_textbox|`5Progress: `^" + to_string(s5Quest) + "/1 `5Legendary Orb|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
						else {
							Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`#Quest For The Katana``|left|2592|0|0|\n\nadd_spacer|small|\nadd_textbox|`5Your current step: `^" + to_string(sQuest) + "/5|\nadd_textbox|`5Step 5: Congratulations on Beating all of my Steps, Now bring me The Legendary Orb`5!|\nadd_textbox|`5Progress: `^1/1 `5Legendary Orb|\nadd_button|s5scomplete|`cDary!|\nadd_button|chc0|`9Close|0|0|\nadd_quick_exit|");
						}
					}
				}
			}
			else {
				Player::OnTextOverlay(peer, "`#You must be world owner to use `#Legendary Wizard`#!");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 9422)
		{

			if (((PlayerInfo*)(peer->data))->rawName != getPlyersWorld(peer)->owner) { return; }
			if (world->isPublic == true) { return; }
			int gemplantgems = 0;
			ifstream fileStream213("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
			fileStream213 >> gemplantgems;
			fileStream213.close();
			int gemplantstatus = 0;
			ifstream fileStream342("gemplant/status/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
			fileStream342 >> gemplantstatus;
			fileStream342.close();
			bool gemplantadmincheck = true;
			if (gemplantstatus == 1)
			{
				Player::OnDialogRequest(peer, "set_default_color|`o\nadd_label_with_icon|big|`oGEMPLANT|left|9422|\nadd_spacer|small|\nadd_label_with_icon|small|`2Gems|left|112|\nadd_label|small|The machine contains " + std::to_string(gemplantgems) + " `2Gems|left|\nadd_button|gemplantcollect|`oRetrieve gems|\nadd_label|small|Collecting mode: `5ACTIVE|left|\nadd_label|small|Use the Gems GEMPLANT to collect `2Gems `odirectly from anyone who is breaking blocks|left|\nadd_button|gemplantdisable|`oDisable Magplant|\nend_dialog|gemplantedit|Close|Update|");
			}
			else
			{
				Player::OnDialogRequest(peer, "set_default_color|`o\nadd_label_with_icon|big|`oGEMPLANT|left|9422|\nadd_spacer|small|\nadd_label_with_icon|small|`2Gems|left|112|\nadd_label|small|The machine contains " + std::to_string(gemplantgems) + " `2Gems|left|\nadd_button|gemplantcollect|`oRetrieve gems|\nadd_label|small|Collecting mode: `5DISABLED|left|\nadd_label|small|Use the Gems GEMPLANT to collect `2Gems `odirectly from anyone who is breaking blocks|left|\nadd_button|gemplantenable|`oEnable Magplant|\nend_dialog|gemplantedit|Close|Update|");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 9432) {
			if (((PlayerInfo*)(peer->data))->haveGrowId && ((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->level < 25)
				{
					Player::OnConsoleMessage(peer, "`5[GTOS] `@You Must Be Aleast `9Level `425 `@To Use `3This Machine`@!");
					return;
				}
				else
				{
					Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`5World Generation Machine``|left|9432|0|0|\n\nadd_spacer|small|\nadd_textbox|`oWelcome captain! This machine allows you to generate any world you wish, you can choose the width, height, blocks and even more! Press Start Machine to continue...|\n\nadd_spacer|small|\nadd_button|worldgenmachine|`9Start Machine|0|0|\nadd_quick_exit|");
				}
			}
			else {
				Player::OnConsoleMessage(peer, "`#You must be world owner to use this machine!");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 9170) {
			if (((PlayerInfo*)(peer->data))->haveGrowId && ((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner) {
				if (((PlayerInfo*)(peer->data))->level < 30)
				{
					Player::OnConsoleMessage(peer, "`5[GTOS] `@You Must Be Aleast `9Level `430 `@To Use `3This Machine`@!");
				}
				else {
					Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wMagic Machine``|left|9170|0|0|\n\nadd_spacer|small|\nadd_textbox|`oThis machine is stronger than you think! It has ability to convert premium blocks into crystals! `4Warning! `oYou must have at least 100 blocks! Click `9Start `oTo get started!|\n\nadd_spacer|small|\nadd_button|magicmachine|`9Start|0|0|\nadd_quick_exit|");
				}
			}
			else {
				Player::OnTextOverlay(peer, "`#You must be world owner to use this machine!");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 3898) {
			Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wTelephone`|left|3898|\n\nadd_spacer|small|\nadd_label|small|`oDial a number to call somebody in Growtopia. Phone numbers have 5 digits. Most numbers are not in service!|\nadd_spacer|small|\nadd_text_input|telephonenumber|Phone #||5|\nend_dialog|usetelephone|Hang Up|`wDial|\n");
		}
	}
	if (tile == 18)
	{
		if (world->items[x + (y * world->width)].foreground == 3)
		{
			int hi = data.punchX * 32;
			int hi2 = data.punchY * 32;
		}
		if (world->items[x + (y * world->width)].foreground == 5)
		{
			updateDoor(peer, 5, data.punchX, data.punchY, "`4na tai jo keista kam sitas cia``");
		}
		if (world->items[x + (y * world->width)].foreground == 9424 || world->items[x + (y * world->width)].foreground == 9474) {
			if (((PlayerInfo*)(peer->data))->cloth_hand == 5480)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `wRayman`@!");
				return;
			}
			else if (((PlayerInfo*)(peer->data))->cloth_hand == 9430)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `9Golden Digger's Spade`@!");
				return;
			}
			else if (((PlayerInfo*)(peer->data))->cloth_hand == 9452)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `#Rainbow `9Digger's Spade`@!");
				return;
			}
			else if (((PlayerInfo*)(peer->data))->cloth_hand == 9454)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `4Demon `9Digger's Spade`@!");
				return;
			}
			else if (((PlayerInfo*)(peer->data))->cloth_hand == 9456)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `9Golden `4Demon `9Digger's Spade`@!");
				return;
			}
			else if (((PlayerInfo*)(peer->data))->cloth_hand == 9458)
			{
				Player::OnTextOverlay(peer, "`@You can't break this `4Block `@With `1Legendary Drill Spade`@!");
				return;
			}
		}
		if (world->items[x + (y * world->width)].foreground == 1008) {
			if (((PlayerInfo*)(peer->data))->haveGrowId && ((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner || ((PlayerInfo*)(peer->data))->rawName == "sebia") {
				int valgem;
				valgem = rand() % 40;
				std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
				std::string content((std::istreambuf_iterator<char>(ifs)),
					(std::istreambuf_iterator<char>()));
				if (((PlayerInfo*)(peer->data))->level < 15)
				{
					Player::OnConsoleMessage(peer, "`5[GTOS] `@You Must Be Aleast `9Level `415 `@To Harvest `eATM Machines`@!");
				}
				else {
					using namespace std::chrono;
					if (((PlayerInfo*)(peer->data))->lastATM + 1200 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
					{
						((PlayerInfo*)(peer->data))->lastATM = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
						ofstream fd("blocks/atm/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fd << ((PlayerInfo*)(peer->data))->lastATM;
						fd.close();
					}
					else {
						int kiekDar = (((PlayerInfo*)(peer->data))->lastATM + 1200 - (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count());
						long milli = kiekDar;
						long hr = milli / 3600000;
						milli = milli - 3600000 * hr;
						long min = milli / 60000;
						milli = milli - 60000 * min;
						long sec = milli / 1000;
						Player::OnConsoleMessage(peer, "`5[GTOS] `9Cooldown `@Please Wait `9" + to_string(sec) + "s. `@To Use ATM!");
						return;
					}
					if (((PlayerInfo*)(peer->data))->chatnotifications == true)
					{
						Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2gems `^from the `eATM Machine`^!");
					}
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`^You found `9" + std::to_string(valgem) + " `2Gems`w!", 0, true);
					int gembux = atoi(content.c_str());
					int fingembux = gembux + valgem;
					ofstream myfile;
					myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
					myfile << fingembux;
					myfile.close();
					int gemcalc = gembux + valgem;
					GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
					ENetPacket* packetpp = enet_packet_create(pp.data,
						pp.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetpp);
					delete pp.data;
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 30, hi, hi2, 0);
				}
			}
			else {
				Player::OnConsoleMessage(peer, "`5[GTOS] `@You don't have access to break this `eATM Machine`@!");
			}
		}
		if (world->items[x + (y * world->width)].foreground == 1636) {
			if (((PlayerInfo*)(peer->data))->haveGrowId && ((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner) {
				if (((PlayerInfo*)(peer->data))->level < 40)
				{
					Player::OnConsoleMessage(peer, "`5[GTOS] `@You Must Be Aleast `9Level `440 `@To Harvest `#Unicorns`@!");
				}
				else {
					using namespace std::chrono;
					if (((PlayerInfo*)(peer->data))->lastATM + 3200 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
					{
						((PlayerInfo*)(peer->data))->lastATM = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
						ofstream fd("unicorn/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
						fd << ((PlayerInfo*)(peer->data))->lastATM;
						fd.close();
					}
					else {
						int kiekDar = (((PlayerInfo*)(peer->data))->lastATM + 3200 - (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count());
						long milli = kiekDar;
						long hr = milli / 3600000;
						milli = milli - 3600000 * hr;
						long min = milli / 60000;
						milli = milli - 60000 * min;
						long sec = milli / 1000;
						Player::OnConsoleMessage(peer, "`5[GTOS] `9Cooldown `@Please Wait `9" + to_string(sec) + "s. `@To Use `#Unicorn!");
						return;
					}
					string crystaluMas[26] = { "gold", "sapphire", "sapphire", "diamond", "rubble", "sapphire", "rubble", "rubble", "opal", "opal", "opal", "opal", "gold", "emerald", "amber", "sapphire", "amber", "sapphire", "amber", "amber", "amber", "emerald", "gold", "gold", "gold", "amber" };
					int crystalChance = rand() % 3;
					int randIndex = rand() % 26;
					string crystalName = crystaluMas[randIndex];
					GiveChestPrizeCrystal(peer, crystalName, crystalChance);
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 73, hi, hi2, 0);
				}
			}
			else {
				Player::OnConsoleMessage(peer, "`5[GTOS] `@You don't have access to break this `#Unicorn`@!");
			}
		}
	}
	if (world->items[x + (y * world->width)].foreground == 6)
	{
		GamePacket p2 = packetEnd(appendIntx(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`wIt's too strong to break."), 0), 1));
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
		return;
	}
	if (((PlayerInfo*)(peer->data))->isCreator != true)
	{
		if (world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 7372 || world->items[x + (y * world->width)].foreground == 3760) {
			if (((PlayerInfo*)(peer->data))->cloth_hand == 8452) {
			}
			else {
				GamePacket p2 = packetEnd(appendIntx(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`wIt's too strong to break."), 0), 1));
				ENetPacket* packet2 = enet_packet_create(p2.data,
					p2.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet2);
				delete p2.data;
				return;
			}
		}
		if (tile == 9444)
		{
			if (((PlayerInfo*)(peer->data))->cloth_hand == 2952 || ((PlayerInfo*)(peer->data))->cloth_hand == 9430 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448 || ((PlayerInfo*)(peer->data))->cloth_hand == 9452 || ((PlayerInfo*)(peer->data))->cloth_hand == 2592) {
			}
			else {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`5This stone is too strong!", 0, true);
				return;
			}
		}
		if (tile == 6 || tile == 3760 || tile == 1000 || tile == 7372 || tile == 1770 || tile == 1832 || tile == 4720)
		{
			GamePacket p2 = packetEnd(appendIntx(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`wIt's too heavy to place."), 0), 1));
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			delete p2.data;
			return;
		}
	}
	if (world->name == "ADMIN" && !((PlayerInfo*)(peer->data))->adminLevel)
	{
		return;
	}
	if (world->name == "HELL" && !((PlayerInfo*)(peer->data))->adminLevel)
	{
		return;
	}
	if (world->name != "ADMIN" || world->name != "HELL") {
		if (world->owner != "") {
		}
	}
	if (tile == 1866)
	{
		if (world->owner == "" || ((PlayerInfo*)(peer->data))->rawName == PlayerDB::getProperName(world->owner) || ((PlayerInfo*)(peer->data))->adminLevel > 1336) {
			if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
			{
				return;
			}
			world->items[x + (y * world->width)].glue = !world->items[x + (y * world->width)].glue;
			UpdateVisualsForBlock(peer, true, x, y, world);
			return;
		}
	}
	if (((PlayerInfo*)(peer->data))->cloth_hand == 3494)
	{
		if (world->owner == "" || ((PlayerInfo*)(peer->data))->rawName == PlayerDB::getProperName(world->owner) || ((PlayerInfo*)(peer->data))->adminLevel > 1336) {
			switch (tile)
			{
			case 3478:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					return;
				}
				world->items[x + (y * world->width)].red = true;
				world->items[x + (y * world->width)].green = false;
				world->items[x + (y * world->width)].blue = false;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3480:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					return;
				}
				world->items[x + (y * world->width)].red = true;
				world->items[x + (y * world->width)].green = true;
				world->items[x + (y * world->width)].blue = false;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3482:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					return;
				}
				world->items[x + (y * world->width)].red = false;
				world->items[x + (y * world->width)].green = true;
				world->items[x + (y * world->width)].blue = false;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3484:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK || world->items[x + (y * world->width)].foreground == 2946)
				{
					return;
				}
				world->items[x + (y * world->width)].red = false;
				world->items[x + (y * world->width)].green = true;
				world->items[x + (y * world->width)].blue = true;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3486:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK || world->items[x + (y * world->width)].foreground == 2946)
				{
					return;
				}
				world->items[x + (y * world->width)].red = false;
				world->items[x + (y * world->width)].green = false;
				world->items[x + (y * world->width)].blue = true;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3488:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK || world->items[x + (y * world->width)].foreground == 2946)
				{
					return;
				}
				world->items[x + (y * world->width)].red = true;
				world->items[x + (y * world->width)].green = false;
				world->items[x + (y * world->width)].blue = true;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3490:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK || world->items[x + (y * world->width)].foreground == 2946)
				{
					return;
				}
				world->items[x + (y * world->width)].red = true;
				world->items[x + (y * world->width)].green = true;
				world->items[x + (y * world->width)].blue = true;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			case 3492:
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK || world->items[x + (y * world->width)].foreground == 2946)
				{
					return;
				}
				world->items[x + (y * world->width)].red = false;
				world->items[x + (y * world->width)].green = false;
				world->items[x + (y * world->width)].blue = false;
				UpdateVisualsForBlock(peer, true, x, y, world);
				return;
			default: break;
			}
		}
	}
	if (tile == 18)
	{
		if (world->items[x + (y * world->width)].foreground == 758)
		{
			sendRoulete(peer);
		}
	}
	if (tile == 540) {
		int netid = ((PlayerInfo*)(peer->data))->netID;
		RemoveInventoryItem(540, 1, peer);
		GamePacket p3 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`2BURRRPPP...!"), 0));
		ENetPacket* packet3 = enet_packet_create(p3.data,
			p3.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet3);
		delete p3.data;
		return;
	}
	if (tile == 8428) {
		bool iscontainsss = false;
		SearchInventoryItem(peer, 8428, 1, iscontainsss);
		if (!iscontainsss)
		{
			autoBan(peer, true, 1, "he tried to punch 8428 item, but did not has it.");
		}
		else {
			Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wUranus Blast`|left|8428|\n\nadd_spacer|small|\nadd_label|small|`oThis item creates a new world! Enter a unique name for it.|\nadd_spacer|small|\nadd_text_input|uranusname|New World Name||30|\nend_dialog|useuranusblast|Cancel|`5Create!|\n");
		}
	}
	if (tile == 32)
	{
		if (world->items[x + (y * world->width)].foreground == 2978) {
			GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|big|`wVending Machine|left|2978|\nadd_textbox|`oAn Item is on display here.!|\nadd_spacer|small|\nend_dialog|dialbro|Pick it up|Leave it|"));
			ENetPacket* packet = enet_packet_create(p.data,
				p.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			delete p.data;
		}
	}
	string gay = world->items[x + (y * world->width)].text;
	int gay2 = world->items[x + (y * world->width)].foreground;
	if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::SIGN || world->items[x + (y * world->width)].foreground == 1420 || world->items[x + (y * world->width)].foreground == 6214)
	{
		if (world->owner != "") {
			if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
				if (tile == 32) {
					((PlayerInfo*)(peer->data))->wrenchx = x;
					((PlayerInfo*)(peer->data))->wrenchy = y;
					Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit " + getItemDef(world->items[x + (y * world->width)].foreground).name + "``|left|" + to_string(gay2) + "|\n\nadd_textbox|`oWhat would you like to write on this sign?|\nadd_text_input|ch3||" + gay + "|100|\nembed_data|tilex|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchx) + "\nembed_data|tiley|" + std::to_string(((PlayerInfo*)(peer->data))->wrenchy) + "\nend_dialog|sign_edit|Cancel|OK|");
				}
			}
		}
	}
	if (world->name != "ADMIN" || world->name != "HELL") {
		if (world->owner != "") {
			if (((PlayerInfo*)(peer->data))->rawName == world->owner)
			{
				if (tile == 32)
				{
					if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
					{
						std::ostringstream oss;
						if (!world->worldaccess.empty())
						{
							std::copy(world->worldaccess.begin(), world->worldaccess.end() - 1,
								std::ostream_iterator<string>(oss, ", "));
							oss << world->worldaccess.back();
						}
						else {
							string oss = "You dont have any accessed player!";
						}
						Player::OnDialogRequest(peer, "set_default_color|`o\n\nadd_label_with_icon|big|`wEdit `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "``|left|" + to_string(world->items[x + (y * world->width)].foreground) + "|\nadd_spacer|small|\nadd_label|small|Access list: " + oss.str() + "|left|\nadd_spacer|small|\nadd_button|worldPublic|`wSet world to `9PUBLIC|0|0|\nadd_button|worldPrivate|`wSet world to `4PRIVATE|0|0|\nadd_spacer|big|\nadd_player_picker|netid|`wAdd|\nadd_spacer|small|\nadd_button_with_icon|allowMod|Allow Noclip|noflags|1796||\nadd_button_with_icon|allowMod1|Disallow Noclip|noflags|242||\nadd_spacer|small|\nadd_quick_exit|\nadd_button|chc0|Close|noflags|0|0|");
					}
				}
			}
			else if (world->isPublic == true || find(world->worldaccess.begin(), world->worldaccess.end(), ((PlayerInfo*)(peer->data))->rawName) != world->worldaccess.end())
			{
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					string ownername = world->Displayowner;
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0" + ownername + "'s `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "`0. (`2Access Granted`w)", 0, true);
					return;
					string text = "action|play_sfx\nfile|audio/punch_locked.wav\ndelayMS|0\n";
					BYTE* data = new BYTE[5 + text.length()];
					BYTE zero = 0;
					int type = 3;
					memcpy(data, &type, 4);
					memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
					memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
					ENetPacket* packetsou = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetsou);
					return;
				}
			}
			else if (world->isPublic)
			{
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					string ownername = world->Displayowner;
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0" + ownername + "'s `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "`0. (`9Open to Public`w)", 0, true);
					string text = "action|play_sfx\nfile|audio/punch_locked.wav\ndelayMS|0\n";
					BYTE* data = new BYTE[5 + text.length()];
					BYTE zero = 0;
					int type = 3;
					memcpy(data, &type, 4);
					memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
					memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
					ENetPacket* packetsou = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetsou);
					return;
				}
			}
			else if (world->isEvent)
			{
				if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
				{
					string ownername = world->Displayowner;
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0" + ownername + "'s `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "`0. (`4No Access`w)", 0, true);
					string text = "action|play_sfx\nfile|audio/punch_locked.wav\ndelayMS|0\n";
					BYTE* data = new BYTE[5 + text.length()];
					BYTE zero = 0;
					int type = 3;
					memcpy(data, &type, 4);
					memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
					memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
					ENetPacket* packetsou = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetsou);
					//delete packetsou.data;
					return;
				}
				else if (world->items[x + (y * world->width)].foreground != 1000)
				{
					string text = "action|play_sfx\nfile|audio/punch_locked.wav\ndelayMS|0\n";
					BYTE* data = new BYTE[5 + text.length()];
					BYTE zero = 0;
					int type = 3;
					memcpy(data, &type, 4);
					memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
					memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
					ENetPacket* packetsou = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetsou);
					//delete packetsou.data;
					return;
				}
			}
			else {
				if (((PlayerInfo*)(peer->data))->haveGrowId == false) {
					Player::OnTextOverlay(peer, "`#Create `9Grow-ID `#First`9!");
				}
				else
				{
					string text = "action|play_sfx\nfile|audio/punch_locked.wav\ndelayMS|0\n";
					BYTE* data = new BYTE[5 + text.length()];
					BYTE zero = 0;
					int type = 3;
					memcpy(data, &type, 4);
					memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
					memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
					ENetPacket* packetsou = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packetsou);
					//delete packetsou.data;
					return;
				}
			}
			if (tile == 242 || tile == 2408 || tile == 1796 || tile == 4428 || tile == 7188 || tile == 8470 || tile == 9290 || tile == 9308 || tile == 9504 || tile == 2950 || tile == 4802 || tile == 4994 || tile == 5260 || tile == 5814 || tile == 5980) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0Only one `$World Lock `0Can be placed in a world!", 0, true);
				return;
			}
		}
		if (tile == 9422) {
			bool aryra = false;
			for (int i = 0; i < world->width * world->height; i++)
			{
				if (world->items[i].foreground == 9422)
				{
					aryra = true;
				}
			}
			if (aryra == false)
			{
				if (((PlayerInfo*)(peer->data))->rawName != world->owner) {
					Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0You need to be world owner to place `9Gemplant`0!", 0, true);
					return;
				}
				else {
				}
			}
			else
			{
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0You cant place more than one `9Gemplant`0!", 0, true);
				return;
			}
		}
		if (tile == 1790) {
			if (((PlayerInfo*)(peer->data))->rawName != world->owner) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0You need to be world owner to place `#Legendary Wizard`0!", 0, true);
				return;
			}
			else if (getPlyersWorld(peer)->isPublic == true)
			{
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`0You cannot place `#Legendary Wizard `0In public worlds`0!", 0, true);
				return;
			}
		}
	}
	// WEATHERS STARTS HERE WEATHERS STARTS HERE WEATHERS STARTS HERE WEATHERS STARTS HERE WEATHERS STARTS HERE
	if (tile == 18)
	{
		if (world->items[x + (y * world->width)].foreground == 1490)
		{
			if (world->weather == 10)
			{
				world->weather = 0;
			}
			else
			{
				world->weather = 10;
			}
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (isHere(peer, currentPeer))
				{
					GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
					ENetPacket* packet2 = enet_packet_create(p2.data,
						p2.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet2);
					delete p2.data;
					continue;
				}
			}
		}
	}
	if (tile == 18)
	{
		if (world->items[x + (y * world->width)].foreground == 934)
		{
			if (world->weather == 2)
			{
				world->weather = 0;
			}
			else
			{
				world->weather = 2;
			}
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (isHere(peer, currentPeer))
				{
					GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
					ENetPacket* packet2 = enet_packet_create(p2.data,
						p2.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet2);
					delete p2.data;
					continue;
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 946)
			{
				if (world->weather == 3)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 3;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 1490)
			{
				if (world->weather == 10)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 10;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 932)
			{
				if (world->weather == 4)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 4;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 984)
			{
				if (world->weather == 5)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 5;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 1210)
			{
				if (world->weather == 8)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 8;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 1364)
			{
				if (world->weather == 11)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 11;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 1750)
			{
				if (world->weather == 15)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 15;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 2046)
			{
				if (world->weather == 17)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 17;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 2284)
			{
				if (world->weather == 18)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 18;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 2744)
			{
				if (world->weather == 19)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 19;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 3252)
			{
				if (world->weather == 20)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 20;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 3446)
			{
				if (world->weather == 21)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 21;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 3534)
			{
				if (world->weather == 22)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 22;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 3694)
			{
				if (world->weather == 25)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 25;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 32)
		{
			if (world->items[x + (y * world->width)].foreground == 3832) { // stuff weather dialog
				if (x != 0)
				{
					((PlayerInfo*)(peer->data))->lastPunchX = x;
				}
				if (y != 0)
				{
					((PlayerInfo*)(peer->data))->lastPunchY = y;
				}
				GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|`o\n\nadd_label_with_icon|big|`wStuff Weather Machine``|left|3832|\nadd_item_picker|stuffitem|Edit Item|Choose any item you want to pick|\nadd_spacer|small|\nadd_text_input|gravity|Gravity Value||4|\nadd_spacer|small|\nadd_quick_exit|\nend_dialog|stuff|Nevermind||"));
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				delete p.data;
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 1490)
			{
				if (world->weather == 10)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 10;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 4242)
			{
				if (world->weather == 30)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 30;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 4486)
			{
				if (world->weather == 31)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 31;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 4776)
			{
				if (world->weather == 32)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 32;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 4892)
			{
				if (world->weather == 33)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 33;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 5000)
			{
				if (world->weather == 34)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 34;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 5112)
			{
				if (world->weather == 35)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 35;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 5654)
			{
				if (world->weather == 36)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 36;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 5716)
			{
				if (world->weather == 37)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 37;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 5958)
			{
				if (world->weather == 38)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 38;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 6854)
			{
				if (world->weather == 42)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 42;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	{
		if (tile == 18)
		{
			if (world->items[x + (y * world->width)].foreground == 7644)
			{
				if (world->weather == 44)
				{
					world->weather = 0;
				}
				else
				{
					world->weather = 44;
				}
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
						ENetPacket* packet2 = enet_packet_create(p2.data,
							p2.len,
							ENET_PACKET_FLAG_RELIABLE);
						enet_peer_send(currentPeer, 0, packet2);
						delete p2.data;
						continue;
					}
				}
			}
		}
	}
	if (tile == 3764) {
		if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
			GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`4Use atomic fireball on this world? Warning! This will delete all blocks placed in your world!``|left|3764|\nadd_spacer|\nadd_button|nukeyes|`4YES!|\nadd_button|`2Cancel|cancel|\nadd_quick_exit|"));
			ENetPacket* packet = enet_packet_create(p.data,
				p.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			delete p.data;
		}
		else {
			GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnTextOverlay"), "`#You must be world owner to use `4Atomic Fireball`#!"));
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			delete p2.data;
		}
	}
	if (tile == 6204) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`oAre You Sure You Want To Open `8Bronze `oChest`9?``|left|6204|\nadd_spacer|\nadd_button|openbronze|`2Open!|\nadd_quick_exit|"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	if (world->items[x + (y * world->width)].foreground == 2978) {
		// VEND UPDATE
		bool isPer = false;
		bool hasLocksInIt = true;
		TileExtra data;
		data.packetType = 0x5;
		data.characterState = 8;
		data.punchX = x;
		data.punchY = y;
		data.charStat = 13;
		data.blockid = 2978;
		data.backgroundid = world->items[x + (y * world->width)].background;
		data.visual = 0x00410000; //0x00210000
		if (hasLocksInIt == true) data.visual = 0x02410000;

		int n = 1796;
		string hex = "";
		{
			std::stringstream ss;
			ss << std::hex << n; // int decimal_value
			std::string res(ss.str());
			hex = res + "18";
		}
		int x;
		std::stringstream ss;
		ss << std::hex << hex;
		ss >> x;
		data.displayblock = x;

		int xes;
		{
			int wl = 2;
			string hex = "";
			{
				std::stringstream ss;
				ss << std::hex << wl; // int decimal_value
				std::string res(ss.str());
				hex = res + "00";
			}
			int x;
			std::stringstream ss;
			ss << std::hex << hex;
			ss >> x;

			xes = x;
		}

		BYTE* raw = NULL;
		if (isPer) {
			raw = packStuffVisual(&data, 16777215, -xes);
		}
		else
		{
			raw = packStuffVisual(&data, 0, xes);
		}
		SendPacketRaw2(192, raw, 102, 0, peer, ENET_PACKET_FLAG_RELIABLE);
		raw = NULL; // prevent memory leak
		/*Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oThis `wfeature `ois going to be available soon``", 0, true);*/
	}
	if (tile == 6202) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`oAre You Sure You Want To Open `sSilver `oChest`9?``|left|6202|\nadd_spacer|\nadd_button|opensilver|`2Open!|\nadd_quick_exit|"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	if (tile == 6200) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`oAre You Sure You Want To Open `9Gold `oChest`9?``|left|6200|\nadd_spacer|\nadd_button|opengold|`2Open!|\nadd_quick_exit|"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	if (tile == 7484) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`oAre You Sure You Want To Open `qWinter `oChest`9?``|left|7484|\nadd_spacer|\nadd_button|openwinter|`2Open!|\nadd_quick_exit|"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	if (tile == 7954) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "set_default_color|\nadd_label_with_icon|small|`9Are You Sure You Want To Open `2Spring `oChest`9?``|left|7954|\nadd_spacer|\nadd_button|openspring|`2Open!|\nadd_quick_exit|"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	if (tile == 1404) {
		if (world->width != 100 && world->height != 60) {
			Player::OnTextOverlay(peer, "`@Door Mover Cant Be Used In Mutated Worlds`@!");
			return;
		}
		if (((PlayerInfo*)(peer->data))->rawName != world->owner) {
			Player::OnTextOverlay(peer, "`@You Must Be `2World-Owner `@To Use `wDoor Mover`@!");
			return;
		}
		if (((PlayerInfo*)(peer->data))->rawName == world->owner) {
			if (world->items[x + (y * world->width)].foreground != 0) {
				Player::OnTextOverlay(peer, "`@There Is `4No `@Space For `wMain Door`@!");
				return;
			}
			else
			{
				for (int i = 0; i < world->width * world->height; i++)
				{
					if (i >= 5400) {
						world->items[i].foreground = 8;
					}
					else if (world->items[i].foreground == 6) {
						world->items[i].foreground = 0;
					}
					else if (world->items[i].foreground != 6) {
						world->items[x + (y * world->width)].foreground = 6;
					}
				}

				WorldInfo* wrld = getPlyersWorld(peer);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer))
					{
						string act = ((PlayerInfo*)(peer->data))->currentWorld;
						sendPlayerLeave(currentPeer, (PlayerInfo*)(currentPeer->data));
						joinWorld(currentPeer, act, 0, 0);

						Player::OnTextOverlay(peer, "`^You Have `2Used `wDoor Mover`^!");
					}
				}
			}
			return;
		}
	}

	if (tile == 32) {
		return;
	}
	if (tile == 822) {
		if (world->owner == "" || ((PlayerInfo*)(peer->data))->rawName == PlayerDB::getProperName(world->owner) || ((PlayerInfo*)(peer->data))->isCreator == true) {
			if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
			{
				return;
			}
			world->items[x + (y * world->width)].water = !world->items[x + (y * world->width)].water;
			UpdateVisualsForBlock(peer, true, x, y, world);
			return;
		}
	}
	if (tile == 3062)
	{
		if (world->owner == "" || ((PlayerInfo*)(peer->data))->rawName == PlayerDB::getProperName(world->owner) || ((PlayerInfo*)(peer->data))->isCreator == true) {
			if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK)
			{
				return;
			}
			world->items[x + (y * world->width)].fire = !world->items[x + (y * world->width)].fire;
			UpdateVisualsForBlock(peer, true, x, y, world);
			return;
		}
	}
	if (tile == 3062)
	{
		world->items[x + (y * world->width)].fire = !world->items[x + (y * world->width)].fire;
		return;
	}
	if (tile == 1866)
	{
		world->items[x + (y * world->width)].glue = !world->items[x + (y * world->width)].glue;
		return;
	}
	ItemDefinition def;
	try {
		def = getItemDef(tile);
		if (def.clothType != ClothTypes::NONE) return;
	}
	catch (int e) {
		def.breakHits = 5;
		if (def.blockType = BlockTypes::SEED) return;
		def.blockType = BlockTypes::UNKNOWN;
#ifdef TOTAL_LOG
		cout << "Ugh, unsupported item " << tile << endl;
#endif
	}
	int test;
	if (((PlayerInfo*)(peer->data))->cloth_hand == 2952 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448 || ((PlayerInfo*)(peer->data))->cloth_hand == 9430 || ((PlayerInfo*)(peer->data))->cloth_hand == 9452 || ((PlayerInfo*)(peer->data))->cloth_hand == 9508 || ((PlayerInfo*)(peer->data))->cloth_hand == 9456 || ((PlayerInfo*)(peer->data))->cloth_hand == 9458 || ((PlayerInfo*)(peer->data))->cloth_hand == 2592 || ((PlayerInfo*)(peer->data))->cloth_hand == 10014) {
		test = 1;
	}
	else {
		test = getItemDef(world->items[x + (y * world->width)].foreground).breakHits * 2;
	}
	bool iscontains = false;
	SearchInventoryItem(peer, tile, 1, iscontains);
	if (!iscontains)
	{
		return;
	}
	iscontains = false;
	if (getItemDef(tile).blockType == BlockTypes::CONSUMABLE) return;
	if (tile == 544 || tile == 54600 || tile == 4520 || tile == 382 || tile == 3116 || tile == 4520 || tile == 1792 || tile == 5666 || tile == 732 || tile == 2994 || tile == 4368 || tile == 274 || tile == 276 || tile == 278) return;
	if (tile == 5708 || tile == 5709 || tile == 5780 || tile == 5781 || tile == 5782 || tile == 5783 || tile == 5784 || tile == 5785 || tile == 5710 || tile == 5711 || tile == 5786 || tile == 5787 || tile == 5788 || tile == 5789 || tile == 5790 || tile == 5791 || tile == 6146 || tile == 6147 || tile == 6148 || tile == 6149 || tile == 6150 || tile == 6151 || tile == 6152 || tile == 6153 || tile == 5670 || tile == 5671 || tile == 5798 || tile == 5799 || tile == 5800 || tile == 5801 || tile == 5802 || tile == 5803 || tile == 5668 || tile == 5669 || tile == 5792 || tile == 5793 || tile == 5794 || tile == 5795 || tile == 5796 || tile == 5797 || tile == 544 || tile == 54600 || tile == 4520 || tile == 382 || tile == 3116 || tile == 1792 || tile == 5666 || tile == 2994 || tile == 4368 || tile == 6204 || tile == 6202 || tile == 6200 || tile == 7484 || tile == 7954) return;
	if (tile == 1902 || tile == 1508 || tile == 428 || tile == 3764 || tile == 8428 || tile == 3808 || tile == 5132 || tile == 7166 || tile == 5078 || tile == 5080 || tile == 5082 || tile == 5084 || tile == 5126 || tile == 5128 || tile == 5130 || tile == 5144 || tile == 5146 || tile == 5148 || tile == 5150 || tile == 5162 || tile == 5164 || tile == 5166 || tile == 5168 || tile == 5180 || tile == 5182 || tile == 5184 || tile == 5186 || tile == 7168 || tile == 7170 || tile == 7172 || tile == 7174 || tile == 2480) return;
	if (tile == 9999 || tile == 1770 || tile == 4720 || tile == 980 || tile == 4882 || tile == 6392 || tile == 3212 || tile == 1832 || tile == 4742 || tile == 3496 || tile == 3270 || tile == 4722 || tile == 9212 || tile == 5134 || tile == 5152 || tile == 5170 || tile == 5188) return;
	if (tile == 6336)
	{
		return;
	}
	if (tile == 2410)
	{
		return;
	}
	if (tile == 4426)
	{
		return;
	}
	if (tile == 18) {
		if (world->items[x + (y * world->width)].background == 6864 && world->items[x + (y * world->width)].foreground == 0) return;
		if (world->items[x + (y * world->width)].background == 0 && world->items[x + (y * world->width)].foreground == 0) return;
		data.packetType = 0x8;
		data.plantingTree = 4;
		using namespace std::chrono;
		//if (world->items[x + (y*world->width)].foreground == 0) return;
		if ((duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count() - world->items[x + (y * world->width)].breakTime >= 5000)
		{
			world->items[x + (y * world->width)].breakTime = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
			world->items[x + (y * world->width)].breakLevel = 5; // TODO
		}
		else
			if (y < world->height && world->items[x + (y * world->width)].breakLevel + 5 >= def.breakHits * test) { // TODO
				data.packetType = 0x3;// 0xC; // 0xF // World::HandlePacketTileChangeRequest
				data.netID = causedBy;
				data.plantingTree = 18;
				data.punchX = x;
				data.punchY = y;
				world->items[x + (y * world->width)].breakLevel = 0;
				int hi = data.punchX * 32;
				int hi2 = data.punchY * 32;
				if (((PlayerInfo*)(peer->data))->cloth_hand == 9456) {
					std::vector<int> lists{ 0, 0, 0, 242, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
					srand(GetTickCount());
					int indexs = rand() % lists.size();
					int values = lists[indexs];
					if (values == 242)
					{
						Player::OnConsoleMessage(peer, "`9[POWER] `8The `@Ancient `9Power `^Dropped `2World Lock`^!");
						int droplocs = rand() % 18;
						int droploc = rand() % 18;
						DropItem(peer, -1, hi + droploc, hi2 + droplocs, 242, 1, 0);
						Player::OnParticleEffect(peer, 40, hi, hi2, 0);

					}
					else {
						Player::OnParticleEffect(peer, 73, hi, hi2, 0);
					}
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 9454) {
					Player::OnParticleEffect(peer, 110, hi, hi2, 0);
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 9452) {
					Player::OnParticleEffect(peer, 45, hi, hi2, 0);
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 9448) {
					Player::OnParticleEffect(peer, 59, hi, hi2, 0);
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 1874) {
					Player::OnParticleEffect(peer, 98, hi, hi2, 0);
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 2952) {
					Player::OnParticleEffect(peer, 98, hi, hi2, 0);
				}
				if (((PlayerInfo*)(peer->data))->cloth_hand == 9430) {
					Player::OnParticleEffect(peer, 98, hi, hi2, 0);
				}
				//BLOKAI
				int crystalChange;
				if (world->items[x + (y * world->width)].foreground == 4762) {
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 293, hi, hi2, 0);
				}
				else if (world->items[x + (y * world->width)].foreground == 9470)
				{
					std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4426 };
					int index = rand() % list.size(); // pick a random index
					int value = list[index];
					if (value == 4426) {
						bool success = true;
						srand(GetTickCount());
						int droploc = rand() % 18;
						int droplocs = rand() % 18;
						DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 4426, 1, 0);
						if (((PlayerInfo*)(peer->data))->chatnotifications == true)
						{
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `4Ruby Shard`^!");
						}
						int hi = data.punchX * 32;
						int hi2 = data.punchY * 32;
						Player::OnParticleEffect(peer, 38, hi, hi2, 0);
					}
					else {
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 9460)
				{
					std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2410 };
					int index = rand() % list.size(); // pick a random index
					int value = list[index];
					if (value == 2410) {
						bool success = true;
						srand(GetTickCount());
						int droploc = rand() % 18;
						int droplocs = rand() % 18;
						DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 2410, 1, 0);
						if (((PlayerInfo*)(peer->data))->chatnotifications == true)
						{
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `2Emerald Shard`^!");
						}
						int hi = data.punchX * 32;
						int hi2 = data.punchY * 32;
						Player::OnParticleEffect(peer, 39, hi, hi2, 0);
					}
					else {
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 7382)
				{
					std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9240 };
					int index = rand() % list.size(); // pick a random index
					int value = list[index];
					if (value == 9240) {
						bool success = true;
						srand(GetTickCount());
						int droploc = rand() % 18;
						int droplocs = rand() % 18;
						DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 9240, 1, 0);
						if (((PlayerInfo*)(peer->data))->chatnotifications == true)
						{
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `#Fragment Crystal`^!");
						}
						int hi = data.punchX * 32;
						int hi2 = data.punchY * 32;
						Player::OnParticleEffect(peer, 88, hi, hi2, 0);
					}
					else {
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 9414) {
					world->items[x + (y * world->width)].foreground = 0;
					int kuriPrizaDuot = rand() % 3 + 1;
					if (kuriPrizaDuot == 1)
					{
						int gemChance = rand() % 12000;
						GiveChestPrizeGems(peer, gemChance);
					}
					if (kuriPrizaDuot == 2)
					{
						int luck = rand() % 3 + 1;
						if (luck == 1) {
							GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^Your `1Luck `^Shines Away..."), 0));
							ENetPacket* packet2 = enet_packet_create(p2.data,
								p2.len,
								ENET_PACKET_FLAG_RELIABLE);
							enet_peer_send(peer, 0, packet2);
							delete p2.data;
						}
						if (luck == 2) {
							GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^The `1Ocean `9Gods `^Didn't Want To Play With You..."), 0));
							ENetPacket* packet2 = enet_packet_create(p2.data,
								p2.len,
								ENET_PACKET_FLAG_RELIABLE);
							enet_peer_send(peer, 0, packet2);
							delete p2.data;
						}
						if (luck == 3) {
							GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You `9Starting `^To Feel `1Tired`^..."), 0));
							ENetPacket* packet2 = enet_packet_create(p2.data,
								p2.len,
								ENET_PACKET_FLAG_RELIABLE);
							enet_peer_send(peer, 0, packet2);
							delete p2.data;
						}
					}
					if (kuriPrizaDuot == 3)
					{
						int itemuMas[62] = { 9416, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 9416, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 9414, 9414, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 9414, 1796, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328, 7328 };
						int ItemChance = 1;
						int randIndex = rand() % 62;
						int itemId = itemuMas[randIndex];
						GiveOceanPrize(peer, itemId, ItemChance, 1);
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 3402) {
					world->items[x + (y * world->width)].foreground = 0;
					int kuriPrizaDuot = rand() % 3 + 1;
					if (kuriPrizaDuot == 1)
					{
						int gemChance = rand() % 2000;
						GiveChestPrizeGems(peer, gemChance);
					}
					if (kuriPrizaDuot == 2)
					{
						string crystaluMas[18] = { "gold", "sapphire", "sapphire", "sapphire","diamond", "diamond", "diamond", "diamond", "rubble", "opal", "opal", "gold", "amber", "emerald", "emerald", "emerald", "emerald", "gold" };
						int crystalChance = rand() % 3;
						int randIndex = rand() % 18;
						string crystalName = crystaluMas[randIndex];
						GiveChestPrizeCrystal(peer, crystalName, crystalChance);
					}
					if (kuriPrizaDuot == 3)
					{
						int itemuMas[62] = { 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 9408, 9408, 242, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1458, 242, 242, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };
						int ItemChance = 1;
						int randIndex = rand() % 62;
						int itemId = itemuMas[randIndex];
						GiveGBCPrize(peer, itemId, ItemChance, 1);
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 192 || world->items[x + (y * world->width)].foreground == 1004)
				{
					std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9490 };
					int index = rand() % list.size();
					int value = list[index];
					if (value == 9490) {
						bool success = true;
						srand(GetTickCount());
						int droploc = rand() % 18;
						int droplocs = rand() % 18;
						DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 9490, 1, 0);
						if (((PlayerInfo*)(peer->data))->chatnotifications == true)
						{
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `2Tree `9Block`^!");
						}
						int hi = data.punchX * 32;
						int hi2 = data.punchY * 32;
						Player::OnParticleEffect(peer, 88, hi, hi2, 0);
					}
					else {
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 2)
				{
					if (((PlayerInfo*)(peer->data))->cloth_back == 9506)
					{
						std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7382 };
						int index = rand() % list.size();
						int value = list[index];
						if (value == 7382) {
							bool success = true;
							srand(GetTickCount());
							int droploc = rand() % 18;
							int droplocs = rand() % 18;
							DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 7382, 1, 0);
							if (((PlayerInfo*)(peer->data))->chatnotifications == true)
							{
								Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `bOnyx `9Block`^!");
							}
							int hi = data.punchX * 32;
							int hi2 = data.punchY * 32;
							Player::OnParticleEffect(peer, 88, hi, hi2, 0);
						}
						else {
						}
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 7382 || world->items[x + (y * world->width)].foreground == 4762 || world->items[x + (y * world->width)].foreground == 9240 || world->items[x + (y * world->width)].foreground == 9460 || world->items[x + (y * world->width)].foreground == 9468)
				{
					std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9462 };
					int index = rand() % list.size();
					int value = list[index];
					if (value == 9462) {
						bool success = true;
						srand(GetTickCount());
						int droploc = rand() % 18;
						int droplocs = rand() % 18;
						DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 9462, 1, 0);
						if (((PlayerInfo*)(peer->data))->chatnotifications == true)
						{
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ The block dropped `eXP `9Block`^!");
						}
						int hi = data.punchX * 32;
						int hi2 = data.punchY * 32;
						Player::OnParticleEffect(peer, 88, hi, hi2, 0);
					}
					else {
					}
				}
				else if (world->items[x + (y * world->width)].foreground == 7382) {
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 118, hi, hi2, 0);
				}
				else if (((PlayerInfo*)(peer->data))->cloth_hand == 8452) {
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 151, hi, hi2, 0);
				}
				else if (((PlayerInfo*)(peer->data))->cloth_hand == 9058) {
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 264, hi, hi2, 0);
				}
				else if (((PlayerInfo*)(peer->data))->cloth_hand == 5480) {
					int hi = data.punchX * 32;
					int hi2 = data.punchY * 32;
					Player::OnParticleEffect(peer, 30, hi, hi2, 0);
				}
				if (world->items[x + (y * world->width)].foreground != 0)
				{
					if (world->items[x + (y * world->width)].foreground == 9422)
					{
						int gemplantgems = 0;
						ifstream fileStream213("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
						fileStream213 >> gemplantgems;
						fileStream213.close();
						if (gemplantgems > 0)
						{
							Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`wEmpty this Gemplant, before breaking it!", 0, true);
							return;
						}
						remove(("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt").c_str());
						Player::OnConsoleMessage(peer, "You received your gemplant back to inventory!");
						bool success = true;
						SaveItemMoreTimes(9422, 1, peer, success);
					}
					bool aryra = false;
					for (int i = 0; i < world->width * world->height; i++)
					{
						if (world->items[i].foreground == 9422)
						{
							int gemplantstatus = 0;
							ifstream fileStream213("gemplant/status/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
							fileStream213 >> gemplantstatus;
							fileStream213.close();
							if (gemplantstatus == 1)
							{
								aryra = true;
							}
						}
					}
					if (aryra == true)
					{
						int current = 0;
						ifstream fileStream213("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
						fileStream213 >> current;
						fileStream213.close();
						int maxdropgem = 10;
						int val = rand() % maxdropgem;
						int randomsudailol = val + current;
						std::ofstream outfile("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
						outfile << randomsudailol;
						outfile.close();
					}
					else
					{
						int iditem = ((PlayerInfo*)(peer->data))->cloth_ances;
						int valgem;
						if (world->items[x + (y * world->width)].foreground == 9424)
						{
							srand(GetTickCount());
							int droploc = rand() % 18;
							int droplocs = rand() % 18;
							int itemid = rand() % maxItems;
							string name = getItemDef(itemid).name;
							if (itemid % 2 == 0) {
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "The power of the dark stone dropped " + name + "!", 0, true);
								DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, itemid, 1, 0);
								int hi = data.punchX * 32;
								int hi2 = data.punchY * 32;
								ENetPeer* currentPeer;
								for (currentPeer = server->peers;
									currentPeer < &server->peers[server->peerCount];
									++currentPeer)
								{
									if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
										continue;
									if (isHere(peer, currentPeer)) {
										Player::OnParticleEffect(currentPeer, 184, hi, hi2, 0);
									}
								}
							}
							else {
								itemid += 1;
								string name321 = getItemDef(itemid).name;
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "The power of the dark stone dropped " + name321 + "!", 0, true);
								DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, itemid, 1, 0);
								int hi = data.punchX * 32;
								int hi2 = data.punchY * 32;
								ENetPeer* currentPeer;
								for (currentPeer = server->peers;
									currentPeer < &server->peers[server->peerCount];
									++currentPeer)
								{
									if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
										continue;
									if (isHere(peer, currentPeer)) {
										Player::OnParticleEffect(currentPeer, 184, hi, hi2, 0);
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 4762) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 300;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
								givequestkatanastep2xp(peer, 2);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Amethyst `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 200;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
								givequestkatanastep2xp(peer, 2);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Amethyst `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							if (((PlayerInfo*)(peer->data))->guild != "")
							{
								int currentgpoints = 0;
								ifstream guildstream1("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
								guildstream1 >> currentgpoints;
								guildstream1.close();
								if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
								{
									int newgpoints = currentgpoints + 2;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								else {
									int newgpoints = currentgpoints + 1;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								// M CONTRIBUTION
								int currentplayercontribution = 0;
								namespace fs = std::experimental::filesystem;
								if (!fs::is_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild) || !fs::exists("guildrewards / contribution / " + ((PlayerInfo*)(peer->data))->guild)) {
									fs::create_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild);
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 2;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 1;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								else {
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 2;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 1;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@2 `^Guild Points!");
									}
									else {
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@1 `^Guild Points!");
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 7382) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 400;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
								givequestkatanastep2xp(peer, 2);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `bOnyx `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 300;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
								givequestkatanastep2xp(peer, 2);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `bOnyx `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							if (((PlayerInfo*)(peer->data))->guild != "")
							{
								int currentgpoints = 0;
								ifstream guildstream1("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
								guildstream1 >> currentgpoints;
								guildstream1.close();
								if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
								{
									int newgpoints = currentgpoints + 4;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								else {
									int newgpoints = currentgpoints + 2;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								// M CONTRIBUTION
								int currentplayercontribution = 0;
								namespace fs = std::experimental::filesystem;
								if (!fs::is_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild) || !fs::exists("guildrewards / contribution / " + ((PlayerInfo*)(peer->data))->guild)) {
									fs::create_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild);
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 4;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 2;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								else {
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 4;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 2;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@4 `^Guild Points!");
									}
									else {
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@2 `^Guild Points!");
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9474) {
							std::vector<int> list{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9476 };
							int index = rand() % list.size();
							int value = list[index];
							if (value == 9476) {
								bool success = true;
								srand(GetTickCount());
								int droploc = rand() % 18;
								int droplocs = rand() % 18;
								DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 9476, 1, 0);
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`wThe `oMystery Box `wDropped `4Hell Wings`w!", 0, true);
								int hi = data.punchX * 32;
								int hi2 = data.punchY * 32;
								Player::OnParticleEffect(peer, 88, hi, hi2, 0);
							}
							else {
								valgem = rand() % 900000;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 30;
								givequestkatanastep2xp(peer, 30);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `8Mystery Box`^!");
								}
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`^You found `9" + std::to_string(valgem) + " `2Gems`w!", 0, true);
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9468) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 1300;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
								givequestkatanastep2xp(peer, 10);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `1Diamond `9Stone`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 1100;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
								givequestkatanastep2xp(peer, 10);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `1Diamond `9Stone`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							if (((PlayerInfo*)(peer->data))->guild != "")
							{
								int currentgpoints = 0;
								ifstream guildstream1("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
								guildstream1 >> currentgpoints;
								guildstream1.close();
								if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
								{
									int newgpoints = currentgpoints + 10;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								else {
									int newgpoints = currentgpoints + 5;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								// M CONTRIBUTION
								int currentplayercontribution = 0;
								namespace fs = std::experimental::filesystem;
								if (!fs::is_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild) || !fs::exists("guildrewards / contribution / " + ((PlayerInfo*)(peer->data))->guild)) {
									fs::create_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild);
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 10;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 5;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								else {
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 10;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 5;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@10 `^Guild Points!");
									}
									else {
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@5 `^Guild Points!");
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9470) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 2400;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
								givequestkatanastep2xp(peer, 10);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Pink Diamond`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 2200;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
								givequestkatanastep2xp(peer, 10);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Pink Diamond`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							if (((PlayerInfo*)(peer->data))->guild != "")
							{
								int currentgpoints = 0;
								ifstream guildstream1("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
								guildstream1 >> currentgpoints;
								guildstream1.close();
								if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
								{
									int newgpoints = currentgpoints + 14;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								else {
									int newgpoints = currentgpoints + 7;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								// M CONTRIBUTION
								int currentplayercontribution = 0;
								namespace fs = std::experimental::filesystem;
								if (!fs::is_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild) || !fs::exists("guildrewards / contribution / " + ((PlayerInfo*)(peer->data))->guild)) {
									fs::create_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild);
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 14;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 7;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								else {
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 14;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 7;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@14 `^Guild Points!");
									}
									else {
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@7 `^Guild Points!");
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9460) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 800;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
								givequestkatanastep2xp(peer, 5);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `2Smaraged `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 600;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
								givequestkatanastep2xp(peer, 5);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `2Smaraged `9Block`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							if (((PlayerInfo*)(peer->data))->guild != "")
							{
								int currentgpoints = 0;
								ifstream guildstream1("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
								guildstream1 >> currentgpoints;
								guildstream1.close();
								if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
								{
									int newgpoints = currentgpoints + 6;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								else {
									int newgpoints = currentgpoints + 3;
									ofstream guildstream3("guildrewards/guildpoints/" + ((PlayerInfo*)(peer->data))->guild + ".txt");
									guildstream3 << newgpoints;
									guildstream3.close();
								}
								// M CONTRIBUTION
								int currentplayercontribution = 0;
								namespace fs = std::experimental::filesystem;
								if (!fs::is_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild) || !fs::exists("guildrewards / contribution / " + ((PlayerInfo*)(peer->data))->guild)) {
									fs::create_directory("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild);
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 6;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 3;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								else {
									ifstream mcontr("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
									mcontr >> currentplayercontribution;
									mcontr.close();
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										int newcontr = currentplayercontribution + 6;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
									else {
										int newcontr = currentplayercontribution + 3;
										ofstream savecon("guildrewards/contribution/" + ((PlayerInfo*)(peer->data))->guild + "/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
										savecon << newcontr;
										savecon.close();
									}
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									if (((PlayerInfo*)(peer->data))->cloth_hand == 9508)
									{
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@6 `^Guild Points!");
									}
									else {
										Player::OnConsoleMessage(peer, "`8[GPOINTS] `^You have obtained `@3 `^Guild Points!");
									}
								}
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 7628) {
							std::vector<int> lists{ 1, 2, 3, 4 };
							srand(GetTickCount());
							int indexs = rand() % lists.size();
							int values = lists[indexs];
							if (values == 1)
							{
								std::vector<int> lists{ 3, 3, 3, 6, 6, 6, 5, 5, 5 };
								srand(GetTickCount());
								int indexs = rand() % lists.size();
								int droplocs = rand() % 18;
								int droploc = rand() % 18;
								int values = lists[indexs];
								DropItem(peer, -1, hi + droploc, hi2 + droplocs, 9426, values, 0);
							}
							if (values == 2)
							{
								std::vector<int> lists{ 30, 30, 30, 60, 60, 60, 50, 50, 50 };
								srand(GetTickCount());
								int indexs = rand() % lists.size();
								int droplocs = rand() % 18;
								int droploc = rand() % 18;
								int values = lists[indexs];
								DropItem(peer, -1, hi + droploc, hi2 + droplocs, 242, values, 0);
							}
							if (values == 3)
							{
								srand(GetTickCount());
								int droplocs = rand() % 18;
								int droploc = rand() % 18;
								DropItem(peer, -1, hi + droploc, hi2 + droplocs, 1796, 1, 0);
							}
							if (values == 4)
							{
								std::vector<int> lists{ 30, 30, 30, 60, 60, 60, 50, 50, 50 };
								srand(GetTickCount());
								int indexs = rand() % lists.size();
								int droplocs = rand() % 18;
								int droploc = rand() % 18;
								int values = lists[indexs];
								DropItem(peer, -1, hi + droploc, hi2 + droplocs, 9440, values, 0);
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9442) {
							string crystaluMas[26] = { "gold", "sapphire", "sapphire", "diamond", "rubble", "sapphire", "rubble", "rubble", "opal", "opal", "opal", "opal", "gold", "emerald", "amber", "sapphire", "amber", "sapphire", "amber", "amber", "amber", "emerald", "gold", "gold", "gold", "amber" };
							int crystalChance = rand() % 3;
							int randIndex = rand() % 26;
							string crystalName = crystaluMas[randIndex];
							GiveChestPrizeCrystal(peer, crystalName, crystalChance);
							int hi = data.punchX * 32;
							int hi2 = data.punchY * 32;
							Player::OnParticleEffect(peer, 73, hi, hi2, 0);
						}
						else if (world->items[x + (y * world->width)].foreground == 7960) {
							valgem = rand() % 9;
							if (valgem > 0) {
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 8;
									givequestkatanastep2xp(peer, 8);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 12;
									givequestkatanastep2xp(peer, 12);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
									givequestkatanastep2xp(peer, 4);
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `@" + std::to_string(valgem) + " `4Fire `9Fragments`^!");
								}
								AddPlayerFragmentFire(peer, valgem);
							}
							else
							{
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`^Your `2Luck `^Shines away...", 0, true);
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9440) {
							std::vector<int> list{ 112 };
							std::vector<int> lists{ 10, 50, 50, 50, 50, 10, 100, 100, 50, 100, 10 };
							srand(GetTickCount());
							int indexs = rand() % lists.size();
							int droplocs = rand() % 18;
							int droploc = rand() % 18;
							int droplocs1 = rand() % 18;
							int droploc1 = rand() % 18;
							int droplocs3 = rand() % 18;
							int droploc3 = rand() % 18;
							int values = lists[indexs];
							std::vector<int> lists1{ 10, 50, 50, 50, 50, 10, 100, 100, 50, 100, 10 };
							int indexs1 = rand() % lists1.size();
							int values1 = lists[indexs1];
							std::vector<int> lists3{ 10, 50, 50, 50, 50, 10, 100, 100, 50, 100, 10 };
							int indexs3 = rand() % lists3.size();
							int values3 = lists[indexs3];
							DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
							DropItem(peer, -1, hi + droploc1, hi2 + droplocs1, 112, values1, 0);
							DropItem(peer, -1, hi + droploc3, hi2 + droplocs3, 112, values3, 0);
						}
						else if (world->items[x + (y * world->width)].foreground == 9240) {
							world->items[x + (y * world->width)].foreground = 0;
							if (((PlayerInfo*)(peer->data))->skill == "Farmer")
							{
								valgem = rand() % 1500;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
								givequestkatanastep2xp(peer, 3);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Boosted The `4Gems`^!");
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Fragment Crystal`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
							else {
								valgem = rand() % 1200;
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
								givequestkatanastep2xp(peer, 3);
								std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								std::string content((std::istreambuf_iterator<char>(ifs)),
									(std::istreambuf_iterator<char>()));
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `9" + std::to_string(valgem) + " `2Gems `^from the `#Fragment Crystal`^!");
								}
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`^You found `9" + std::to_string(valgem) + " `2Gems`w!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packet3);
								delete p3.data;
								int gembux = atoi(content.c_str());
								int fingembux = gembux + valgem;
								ofstream myfile;
								myfile.open("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
								myfile << fingembux;
								myfile.close();
								int gemcalc = gembux + valgem;
								GamePacket pp = packetEnd(appendInt(appendString(createPacket(), "OnSetBux"), gemcalc));
								ENetPacket* packetpp = enet_packet_create(pp.data,
									pp.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(peer, 0, packetpp);
								delete pp.data;
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 9462) {
							world->items[x + (y * world->width)].foreground = 0;
							std::vector<int> list{ 112 };
							std::vector<int> lists{ 50, 100, 50, 100, 50, 100, 50, 100 };
							srand(GetTickCount());
							int indexs = rand() % lists.size();
							int droploc = rand() % 18; // pick a random index
							int droplocs = rand() % 18;
							int values = lists[indexs];
							DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 112, values, 0);
							std::vector<int> listsss{ 5, 10, 15, 50, 40, 25, 30, 20 };
							srand(GetTickCount());
							int indexsss = rand() % listsss.size();
							int xpvalue = listsss[indexsss];
							Player::OnConsoleMessage(peer, "`9[LOOT] `^You have obtained `@" + std::to_string(xpvalue) + " `!Experience`^!");
							((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + xpvalue;
							givequestkatanastep2xp(peer, xpvalue);
						}
						else if (world->items[x + (y * world->width)].foreground == 8) {
							world->items[x + (y * world->width)].foreground = 0;
							valgem = rand() % 6;
							if (valgem > 0) {
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[LOGS]`^ You found `@" + std::to_string(valgem) + " `bDark `9Fragments`^!");
								}
								AddPlayerFragmentDark(peer, valgem);
							}
						}
						else if (world->items[x + (y * world->width)].foreground == 758) {}
						else if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::LOCK) {
							for (int i = 0; i < world->width * world->height; i++)
							{
								if (world->items[i].foreground == 1790) {
									Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "`oTake all `cUntradeable `oBlocks, before breaking The `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "`o!", 0, true);
									return;
								}
							}
							updateworldremove(peer);
							bool success = true;
							WorldInfo* world = getPlyersWorld(peer);
							string nameworld = world->name;
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + " `^Back to your `#Inventory`^!");
							SaveItemMoreTimes(world->items[x + (y * world->width)].foreground, 1, peer, success);
							ENetPeer* currentPeer;
							for (currentPeer = server->peers;
								currentPeer < &server->peers[server->peerCount];
								++currentPeer)
							{
								if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
									continue;
								if (isHere(peer, currentPeer))
								{
									Player::OnConsoleMessage(currentPeer, "`5[`w" + nameworld + " `ohas had its `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + " `oremoved!`5]");
									string text = "action|play_sfx\nfile|audio/fireball.wav\ndelayMS|0\n";
									BYTE* data = new BYTE[5 + text.length()];
									BYTE zero = 0;
									int type = 3;
									memcpy(data, &type, 4);
									memcpy(data + 4, text.c_str(), text.length());
									memcpy(data + 4 + text.length(), &zero, 1);
									ENetPacket* packet2 = enet_packet_create(data,
										5 + text.length(),
										ENET_PACKET_FLAG_RELIABLE);
									enet_peer_send(currentPeer, 0, packet2);
									delete data;
								}
							}
							world->owner = "";
							world->Displayowner = "";
							world->worldaccess.clear();
							world->pIsVip = false;
							world->pIsMod = false;
							world->pIsDev = false;
							world->pIsPlay = false;
							world->isPublic = false;
							((PlayerInfo*)(peer->data))->worldsowned.erase(std::remove(((PlayerInfo*)(peer->data))->worldsowned.begin(), ((PlayerInfo*)(peer->data))->worldsowned.end(), nameworld), ((PlayerInfo*)(peer->data))->worldsowned.end());
							world->items[x + (y * world->width)].foreground = 0;
						}
						else if (world->items[x + (y * world->width)].foreground == 9488) {
							bool success = true;
							SaveItemMoreTimes(9488, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `9WOTW Trophy `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 4428) {
							bool success = true;
							SaveItemMoreTimes(4428, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `4Ruby Lock `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 2408) {
							bool success = true;
							SaveItemMoreTimes(2408, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `2Emerald Lock `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 9504) {
							bool success = true;
							SaveItemMoreTimes(9504, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `4Ban Lock `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 9432) {
							bool success = true;
							SaveItemMoreTimes(9432, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `5WGM `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 9170) {
							bool success = true;
							SaveItemMoreTimes(9170, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `9Magic Machine `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 9418) {
							bool success = true;
							SaveItemMoreTimes(9418, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `#Gem Storage `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 1008) {
							bool success = true;
							SaveItemMoreTimes(1008, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `eATM Machine `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 1636) {
							bool success = true;
							SaveItemMoreTimes(1636, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `#Unicorn `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 1790) {
							bool success = true;
							SaveItemMoreTimes(1790, 1, peer, success);
							Player::OnConsoleMessage(peer, "`9[LOGS]`^ You have received your `#Legendary Wizard `^Back to your `#Inventory`^!");
						}
						else if (world->items[x + (y * world->width)].foreground == 2946)
						{
							if (((PlayerInfo*)(peer->data))->rawName == world->owner || world->owner == "")
							{
								string world = ((PlayerInfo*)(peer->data))->currentWorld;
								((PlayerInfo*)(peer->data))->blockx = x;
								((PlayerInfo*)(peer->data))->blocky = y;
								int squaresign = ((PlayerInfo*)(peer->data))->blockx + (((PlayerInfo*)(peer->data))->blocky * 100);
								string currentworld = world + "X" + std::to_string(squaresign);
								bool displayexist = std::experimental::filesystem::exists("display/" + currentworld + ".txt");
								if (displayexist) {
									int item;
									ifstream getdisplay("display/" + currentworld + ".txt");
									getdisplay >> item;
									getdisplay.close();
									bool success = true;
									SaveItemMoreTimes(item, 1, peer, success);
									Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You picked up 1 " + getItemDef(item).name + ".", 0, true);
									remove(("display/" + currentworld + ".txt").c_str());
								}
							}
							else {
								Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "Only the block's owner can break it!", 0, true);
								return;
							}
						}
						else if (getItemDef(world->items[x + (y * world->width)].foreground).blockType == BlockTypes::SIGN)
						{
							string world = ((PlayerInfo*)(peer->data))->currentWorld;

							if (std::experimental::filesystem::exists("signs/" + world + "X" + to_string(y) + to_string(x) + ".txt"))
							{
								const int result = remove(("signs/" + world + "X" + to_string(y) + to_string(x) + ".txt").c_str());
								if (result != 0) {
									cout << "error removing sign " << world + to_string(x) + to_string(y) << endl;
								}
							}
						}
						else if (getItemDef(world->items[x + (y * world->width)].foreground).rarity != 999)
						{
							if (((PlayerInfo*)(peer->data))->cloth_feet == 8834) {
								if (iditem == 7166 || iditem == 5078 || iditem == 5080 || iditem == 5082 || iditem == 5084 || iditem == 5134 || iditem == 5126 || iditem == 5128 || iditem == 5130 || iditem == 5132 || iditem == 5152 || iditem == 5144 || iditem == 5146 || iditem == 5148 || iditem == 5150 || iditem == 5170 || iditem == 5162 || iditem == 5164 || iditem == 5166 || iditem == 5168 || iditem == 5188 || iditem == 5180 || iditem == 5182 || iditem == 5184 || iditem == 5186 || iditem == 9212 || iditem == 7168 || iditem == 7170 || iditem == 7172 || iditem == 7174)
								{
									if (((PlayerInfo*)(peer->data))->skill == "Farmer")
									{
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 50, 10, 50, 10, 50, 10, 10, 50, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");
											Player::OnConsoleMessage(peer, "`2[BONUS] `#TK69 `^And `@Ancestral `^Dropped `2More `4Gems`^!");
										}
									}
									else {
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 5, 10, 10, 10, 50, 10, 10, 10, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `#TK69 `^And `@Ancestral `^Dropped `2More `4Gems`^!");
										}
									}
								}
								else {
									if (((PlayerInfo*)(peer->data))->skill == "Farmer")
									{
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 10, 5, 10, 5, 10, 5, 10, 50, 10, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");

											Player::OnConsoleMessage(peer, "`2[BONUS] `#TK69 `^Dropped `2More `4Gems`^!");
										}
									}
									else {
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 1, 5, 5, 5, 5, 10, 10, 10, 5, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `#TK69 `^Dropped `2More `4Gems`^!");
										}
									}
								}
							}
							else if (((PlayerInfo*)(peer->data))->cloth_hand == 7912) {
								if (iditem == 7166 || iditem == 5078 || iditem == 5080 || iditem == 5082 || iditem == 5084 || iditem == 5134 || iditem == 5126 || iditem == 5128 || iditem == 5130 || iditem == 5132 || iditem == 5152 || iditem == 5144 || iditem == 5146 || iditem == 5148 || iditem == 5150 || iditem == 5170 || iditem == 5162 || iditem == 5164 || iditem == 5166 || iditem == 5168 || iditem == 5188 || iditem == 5180 || iditem == 5182 || iditem == 5184 || iditem == 5186 || iditem == 9212 || iditem == 7168 || iditem == 7170 || iditem == 7172 || iditem == 7174)
								{
									if (((PlayerInfo*)(peer->data))->skill == "Farmer")
									{
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 50, 10, 10, 10, 5, 10, 10, 10, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");

											Player::OnConsoleMessage(peer, "`2[BONUS] `!War Hammers `^And `@Ancestral `^Dropped `2More `4Gems`^!");
										}
									}
									else {
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 5, 10, 5, 10, 5, 10, 10, 10, 10, 10 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `!War Hammers `^And `@Ancestral `^Dropped `2More `4Gems`^!");
										}
									}
								}
								else {
									if (((PlayerInfo*)(peer->data))->skill == "Farmer")
									{
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 10, 1, 10, 5, 10, 10, 10, 5, 10, 5 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");

											Player::OnConsoleMessage(peer, "`2[BONUS] `!War Hammers `^Dropped `2More `4Gems`^!");
										}
									}
									else {
										std::vector<int> list{ 112 };
										std::vector<int> lists{ 1, 1, 1, 5, 5, 10, 10, 5, 10, 5 };
										srand(GetTickCount());
										int indexs = rand() % lists.size(); // pick a random index
										int droplocs = rand() % 18;
										int droploc = rand() % 18;
										int values = lists[indexs];
										DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
										if (values == 10 || values == 50)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `!War Hammers `^Dropped `2More `4Gems`^!");
										}
									}
								}
							}
							else if (iditem == 7166 || iditem == 5078 || iditem == 5080 || iditem == 5082 || iditem == 5084 || iditem == 5134 || iditem == 5126 || iditem == 5128 || iditem == 5130 || iditem == 5132 || iditem == 5152 || iditem == 5144 || iditem == 5146 || iditem == 5148 || iditem == 5150 || iditem == 5170 || iditem == 5162 || iditem == 5164 || iditem == 5166 || iditem == 5168 || iditem == 5188 || iditem == 5180 || iditem == 5182 || iditem == 5184 || iditem == 5186 || iditem == 9212 || iditem == 7168 || iditem == 7170 || iditem == 7172 || iditem == 7174)
							{
								if (((PlayerInfo*)(peer->data))->skill == "Farmer")
								{
									std::vector<int> list{ 112 };
									std::vector<int> lists{ 5, 10, 50, 10, 10, 10, 10, 10, 10, 10 };
									srand(GetTickCount());
									int indexs = rand() % lists.size(); // pick a random index
									int droplocs = rand() % 18;
									int droploc = rand() % 18;
									int values = lists[indexs];
									DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
									if (values == 10 || values == 50)
									{
										Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");

										Player::OnConsoleMessage(peer, "`2[BONUS] `@Ancestral `^Dropped `2More `4Gems`^!");
									}
								}
								else {
									std::vector<int> list{ 112 };
									std::vector<int> lists{ 5, 5, 5, 10, 5, 10, 10, 10, 10, 10 };
									srand(GetTickCount());
									int indexs = rand() % lists.size(); // pick a random index
									int droplocs = rand() % 18;
									int droploc = rand() % 18;
									int values = lists[indexs];
									DropItem(peer, -1, hi + droploc, hi2 + droplocs, 112, values, 0);
									if (values == 10 || values == 50)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `@Ancestral `^Dropped `2More `4Gems`^!");
									}
								}
							}
							else {
								if (((PlayerInfo*)(peer->data))->skill == "Farmer")
								{
									std::vector<int> list{ 112 };
									std::vector<int> lists{ 5, 5, 5, 5, 5, 10, 10, 10 };
									srand(GetTickCount());
									int indexs = rand() % lists.size(); // pick a random index
									int droplocs = rand() % 18;
									int droploc = rand() % 18;
									int values = lists[indexs];
									DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 112, values, 0);
									if (values == 10)
									{
										Player::OnConsoleMessage(peer, "`9[SKILL] `#Farmer Skill `^Dropped `2More `4Gems`^!");
									}
								}
								else {
									std::vector<int> list{ 112 };
									std::vector<int> lists{ 5, 5, 5, 5, 5, 1, 1, 1 };
									srand(GetTickCount());
									int indexs = rand() % lists.size(); // pick a random index
									int droplocs = rand() % 18;
									int droploc = rand() % 18;
									int values = lists[indexs];
									DropItem(peer, -1, x * 32 + droploc, y * 32 + droplocs, 112, values, 0);
								}
							}
						}
					}
					ItemDefinition yologay;
					yologay = getItemDef(world->items[x + (y * world->width)].foreground);
					if (yologay.MultiFacing == "MultiFacing")
					{
						world->items[x + (y * world->width)].rotatedLeft = false;
					}
					// buvo cia
					int valgem;
					int crystalChange;
					if (((PlayerInfo*)(peer->data))->cloth_hand == 7912) {
						if (world->items[x + (y * world->width)].foreground == 7382 || world->items[x + (y * world->width)].foreground == 4762 || world->items[x + (y * world->width)].foreground == 9240 || world->items[x + (y * world->width)].foreground == 9460 || world->items[x + (y * world->width)].foreground == 9468 || world->items[x + (y * world->width)].foreground == 9462 || world->items[x + (y * world->width)].foreground == 1008 || world->items[x + (y * world->width)].foreground == 1636 || world->items[x + (y * world->width)].foreground == 1796 || world->items[x + (y * world->width)].foreground == 242 || world->items[x + (y * world->width)].foreground == 9290 || world->items[x + (y * world->width)].foreground == 8470 || world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 9308) {
							world->items[x + (y * world->width)].foreground = 0;
						}
						else {
							if (world->items[x + (y * world->width)].foreground == 2) {
								world->items[x + (y * world->width)].foreground = 0;
								srand(GetTickCount());
								valgem = rand() % 10;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
								AddPlayerFragmentEarth(peer, valgem);
							}
							else {
								world->items[x + (y * world->width)].foreground = 0;
								srand(GetTickCount());
								valgem = rand() % 10;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
							}
						}
					}
					else if (((PlayerInfo*)(peer->data))->cloth_ances == 7166) {
						if (world->items[x + (y * world->width)].foreground == 7382 || world->items[x + (y * world->width)].foreground == 4762 || world->items[x + (y * world->width)].foreground == 9240 || world->items[x + (y * world->width)].foreground == 9460 || world->items[x + (y * world->width)].foreground == 9468 || world->items[x + (y * world->width)].foreground == 9462 || world->items[x + (y * world->width)].foreground == 1008 || world->items[x + (y * world->width)].foreground == 1636 || world->items[x + (y * world->width)].foreground == 1796 || world->items[x + (y * world->width)].foreground == 242 || world->items[x + (y * world->width)].foreground == 9290 || world->items[x + (y * world->width)].foreground == 8470 || world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 9308) {
							world->items[x + (y * world->width)].foreground = 0;
						}
						else {
							if (world->items[x + (y * world->width)].foreground == 2) {
								world->items[x + (y * world->width)].foreground = 0;
								srand(GetTickCount());
								valgem = rand() % 10;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 942 || ((PlayerInfo*)(peer->data))->cloth_hand == 94488)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
								AddPlayerFragmentEarth(peer, valgem);
							}
							else {
								world->items[x + (y * world->width)].foreground = 0;
								valgem = rand() % 20;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
							}
						}
					}
					else if (((PlayerInfo*)(peer->data))->cloth_feet == 8834) {
						if (world->items[x + (y * world->width)].foreground == 7382 || world->items[x + (y * world->width)].foreground == 4762 || world->items[x + (y * world->width)].foreground == 9240 || world->items[x + (y * world->width)].foreground == 9460 || world->items[x + (y * world->width)].foreground == 9468 || world->items[x + (y * world->width)].foreground == 9462 || world->items[x + (y * world->width)].foreground == 1008 || world->items[x + (y * world->width)].foreground == 1636 || world->items[x + (y * world->width)].foreground == 1796 || world->items[x + (y * world->width)].foreground == 242 || world->items[x + (y * world->width)].foreground == 9290 || world->items[x + (y * world->width)].foreground == 8470 || world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 9308) {
							world->items[x + (y * world->width)].foreground = 0;
						}
						else {
							if (world->items[x + (y * world->width)].foreground == 2) {
								world->items[x + (y * world->width)].foreground = 0;
								srand(GetTickCount());
								valgem = rand() % 10;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
								AddPlayerFragmentEarth(peer, valgem);
							}
							else {
								world->items[x + (y * world->width)].foreground = 0;
								valgem = rand() % 13;
								if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
									givequestkatanastep2xp(peer, 2);
								}
								else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
									}
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
									givequestkatanastep2xp(peer, 3);
								}
								else {
									((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
									givequestkatanastep2xp(peer, 1);
								}
							}
						}
					}
					else {
						if (world->items[x + (y * world->width)].foreground == 2) {
							world->items[x + (y * world->width)].foreground = 0;
							srand(GetTickCount());
							if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
							{
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
								}
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
								givequestkatanastep2xp(peer, 2);
							}
							else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
							{
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
								}
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
								givequestkatanastep2xp(peer, 3);
							}
							else {
								((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
								givequestkatanastep2xp(peer, 1);
							}
							valgem = rand() % 10;
							AddPlayerFragmentEarth(peer, valgem);
						}
						else {
							valgem = rand() % 5;
							world->items[x + (y * world->width)].foreground = 0;
						}
					}
#pragma region crystals
					if (world->items[x + (y * world->width)].foreground == 1008 || world->items[x + (y * world->width)].foreground == 1636 || world->items[x + (y * world->width)].foreground == 1796 || world->items[x + (y * world->width)].foreground == 242 || world->items[x + (y * world->width)].foreground == 9290 || world->items[x + (y * world->width)].foreground == 8470 || world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 9308) {
						world->items[x + (y * world->width)].foreground = 0;
					}
					else {
						if (((PlayerInfo*)(peer->data))->skill == "Miner")
						{
							int valshouldfind = rand() % 100 + 1;
							if (valshouldfind < 15)
							{
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Miner Skill `^Boosted The `4Crystals`^!");
								}
								vector<Crystal> crystals;
								crystals.push_back(Crystal("emerald", 30));
								crystals.push_back(Crystal("diamond", 60));
								crystals.push_back(Crystal("sapphire", 90));
								crystals.push_back(Crystal("ruby", 120));
								crystals.push_back(Crystal("gold", 150));
								crystals.push_back(Crystal("opal", 250));
								crystals.push_back(Crystal("amber", 330));
								string foundcrystalname = "";
								int val2 = rand() % 1000 + 1;
								for (int i = 0; foundcrystalname == ""; i++)
								{
									if (val2 < crystals[i].probability) foundcrystalname = crystals[i].name;
									val2 -= crystals[i].probability;
								}
								if (foundcrystalname == "emerald")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `2Emerald`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->emerald += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
										givequestkatanastep2xp(peer, 10);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 15;
										givequestkatanastep2xp(peer, 15);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
										givequestkatanastep2xp(peer, 5);
									}
								}
								else if (foundcrystalname == "diamond")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `3Diamond`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->diamond += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 8;
										givequestkatanastep2xp(peer, 8);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 12;
										givequestkatanastep2xp(peer, 12);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
								}
								else if (foundcrystalname == "sapphire")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `bSapphire`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->sapphire += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 6;
										givequestkatanastep2xp(peer, 6);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
								}
								else if (foundcrystalname == "ruby")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `4Ruby`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->rubble += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "gold")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `9Gold`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->gold += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "opal")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `1Opal`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->opal += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "amber")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `8Amber`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->amber += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								crystals.clear();
							}
						}
						else {
							int valshouldfind = rand() % 100 + 1;
							if (valshouldfind < 9)
							{
								vector<Crystal> crystals;
								crystals.push_back(Crystal("emerald", 30));
								crystals.push_back(Crystal("diamond", 60));
								crystals.push_back(Crystal("sapphire", 90));
								crystals.push_back(Crystal("ruby", 120));
								crystals.push_back(Crystal("gold", 150));
								crystals.push_back(Crystal("opal", 250));
								crystals.push_back(Crystal("amber", 330));
								string foundcrystalname = "";
								int val2 = rand() % 1000 + 1;
								for (int i = 0; foundcrystalname == ""; i++)
								{
									if (val2 < crystals[i].probability) foundcrystalname = crystals[i].name;
									val2 -= crystals[i].probability;
								}
								if (foundcrystalname == "emerald")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `2Emerald`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->emerald += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
										givequestkatanastep2xp(peer, 10);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 15;
										givequestkatanastep2xp(peer, 15);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
										givequestkatanastep2xp(peer, 5);
									}
								}
								else if (foundcrystalname == "diamond")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `3Diamond`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->diamond += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 8;
										givequestkatanastep2xp(peer, 8);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 12;
										givequestkatanastep2xp(peer, 12);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
								}
								else if (foundcrystalname == "sapphire")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `bSapphire`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->sapphire += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 6;
										givequestkatanastep2xp(peer, 6);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
								}
								else if (foundcrystalname == "ruby")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `4Ruby`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->rubble += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "gold")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `9Gold`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->gold += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "opal")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `1Opal`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->opal += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "amber")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `8Amber`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->amber += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								crystals.clear();

							}

						}
					}

#pragma endregion
					if (((PlayerInfo*)(peer->data))->xp >= (((PlayerInfo*)(peer->data))->level * 1500)) {
						((PlayerInfo*)(peer->data))->xp = 0;
						((PlayerInfo*)(peer->data))->level = ((PlayerInfo*)(peer->data))->level + 1;
						ENetPeer* currentPeer;
						for (currentPeer = server->peers;
							currentPeer < &server->peers[server->peerCount];
							++currentPeer)
						{
							if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
								continue;
							if (isHere(peer, currentPeer)) {
								string name = ((PlayerInfo*)(peer->data))->displayName;
								GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), name + " `wis now level " + std::to_string(((PlayerInfo*)(peer->data))->level) + "!"));
								string text = "action|play_sfx\nfile|audio/levelup2.wav\ndelayMS|0\n";
								BYTE* data = new BYTE[5 + text.length()];
								BYTE zero = 0;
								int type = 3;
								memcpy(data, &type, 4);
								memcpy(data + 4, text.c_str(), text.length());
								memcpy(data + 4 + text.length(), &zero, 1);
								ENetPacket* packet = enet_packet_create(p.data,
									p.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet);
								ENetPacket* packet2 = enet_packet_create(data,
									5 + text.length(),
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet2);
								delete data;
								delete p.data;
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), name + " `wis now level " + std::to_string(((PlayerInfo*)(peer->data))->level) + "!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet3);
							}
						}
					}
				}
				else {
					world->items[x + (y * world->width)].background = 6864;
					int valgem = rand() % 5;
					if (world->items[x + (y * world->width)].foreground == 1008 || world->items[x + (y * world->width)].foreground == 1636 || world->items[x + (y * world->width)].foreground == 1796 || world->items[x + (y * world->width)].foreground == 242 || world->items[x + (y * world->width)].foreground == 9290 || world->items[x + (y * world->width)].foreground == 8470 || world->items[x + (y * world->width)].foreground == 8 || world->items[x + (y * world->width)].foreground == 9308) {
						world->items[x + (y * world->width)].foreground = 0;
					}
					else {
						if (((PlayerInfo*)(peer->data))->skill == "Miner")
						{
							int valshouldfind = rand() % 100 + 1;
							if (valshouldfind < 30)
							{
								if (((PlayerInfo*)(peer->data))->chatnotifications == true)
								{
									Player::OnConsoleMessage(peer, "`9[SKILL] `#Miner Skill `^Boosted The `4Crystals`^!");
								}
								vector<Crystal> crystals;
								crystals.push_back(Crystal("emerald", 30));
								crystals.push_back(Crystal("diamond", 60));
								crystals.push_back(Crystal("sapphire", 90));
								crystals.push_back(Crystal("ruby", 120));
								crystals.push_back(Crystal("gold", 150));
								crystals.push_back(Crystal("opal", 250));
								crystals.push_back(Crystal("amber", 330));
								string foundcrystalname = "";
								int val2 = rand() % 1000 + 1;
								for (int i = 0; foundcrystalname == ""; i++)
								{
									if (val2 < crystals[i].probability) foundcrystalname = crystals[i].name;
									val2 -= crystals[i].probability;
								}
								if (foundcrystalname == "emerald")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `2Emerald`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->emerald += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
										givequestkatanastep2xp(peer, 10);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 15;
										givequestkatanastep2xp(peer, 15);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
										givequestkatanastep2xp(peer, 5);
									}
								}
								else if (foundcrystalname == "diamond")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `3Diamond`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->diamond += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 8;
										givequestkatanastep2xp(peer, 8);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 12;
										givequestkatanastep2xp(peer, 12);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
								}
								else if (foundcrystalname == "sapphire")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `bSapphire`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->sapphire += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 6;
										givequestkatanastep2xp(peer, 6);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
								}
								else if (foundcrystalname == "ruby")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `4Ruby`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->rubble += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "gold")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `9Gold`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->gold += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "opal")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `1Opal`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->opal += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "amber")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `8Amber`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->amber += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								crystals.clear();
							}
						}
						else {
							int valshouldfind = rand() % 100 + 1;
							if (valshouldfind < 9)
							{
								vector<Crystal> crystals;
								crystals.push_back(Crystal("emerald", 30));
								crystals.push_back(Crystal("diamond", 60));
								crystals.push_back(Crystal("sapphire", 90));
								crystals.push_back(Crystal("ruby", 120));
								crystals.push_back(Crystal("gold", 150));
								crystals.push_back(Crystal("opal", 250));
								crystals.push_back(Crystal("amber", 330));
								string foundcrystalname = "";
								int val2 = rand() % 1000 + 1; // 0 - 1000
								for (int i = 0; foundcrystalname == ""; i++)
								{
									if (val2 < crystals[i].probability) foundcrystalname = crystals[i].name;
									val2 -= crystals[i].probability;
								}
								if (foundcrystalname == "emerald")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `2Emerald`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->emerald += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 10;
										givequestkatanastep2xp(peer, 10);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 15;
										givequestkatanastep2xp(peer, 15);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 5;
										givequestkatanastep2xp(peer, 5);
									}
								}
								else if (foundcrystalname == "diamond")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `3Diamond`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->diamond += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 8;
										givequestkatanastep2xp(peer, 8);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 12;
										givequestkatanastep2xp(peer, 12);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
								}
								else if (foundcrystalname == "sapphire")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `bSapphire`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->sapphire += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 4;
										givequestkatanastep2xp(peer, 4);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 6;
										givequestkatanastep2xp(peer, 6);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
								}
								else if (foundcrystalname == "ruby")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `4Ruby`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->rubble += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "gold")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `9Gold`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->gold += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "opal")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `1Opal`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->opal += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								else if (foundcrystalname == "amber")
								{
									if (((PlayerInfo*)(peer->data))->chatnotifications == true)
									{
										GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOGS]`^ You found `8Amber`^!"));
										ENetPacket* packet = enet_packet_create(p2.data,
											p2.len,
											ENET_PACKET_FLAG_RELIABLE);
										enet_peer_send(peer, 0, packet);
										delete p2.data;
									}
									((PlayerInfo*)(peer->data))->amber += 1;
									if (((PlayerInfo*)(peer->data))->cloth_necklace == 9428 || ((PlayerInfo*)(peer->data))->cloth_hand == 9448)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Double XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 2;
										givequestkatanastep2xp(peer, 2);
									}
									else if (((PlayerInfo*)(peer->data))->cloth_back == 9466)
									{
										if (((PlayerInfo*)(peer->data))->chatnotifications == true)
										{
											Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `2Triple XP`^!");
										}
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 3;
										givequestkatanastep2xp(peer, 3);
									}
									else {
										((PlayerInfo*)(peer->data))->xp = ((PlayerInfo*)(peer->data))->xp + 1;
										givequestkatanastep2xp(peer, 1);
									}
								}
								crystals.clear();

							}
						}
					}
					if (((PlayerInfo*)(peer->data))->xp >= (((PlayerInfo*)(peer->data))->level * 1500)) {
						((PlayerInfo*)(peer->data))->xp = 0;
						((PlayerInfo*)(peer->data))->level = ((PlayerInfo*)(peer->data))->level + 1;
						ENetPeer* currentPeer;
						for (currentPeer = server->peers;
							currentPeer < &server->peers[server->peerCount];
							++currentPeer)
						{
							if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
								continue;
							if (isHere(peer, currentPeer)) {
								string name = ((PlayerInfo*)(peer->data))->displayName;
								GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), name + " `wis now level " + std::to_string(((PlayerInfo*)(peer->data))->level) + "!"));
								string text = "action|play_sfx\nfile|audio/levelup2.wav\ndelayMS|0\n";
								BYTE* data = new BYTE[5 + text.length()];
								BYTE zero = 0;
								int type = 3;
								memcpy(data, &type, 4);
								memcpy(data + 4, text.c_str(), text.length());
								memcpy(data + 4 + text.length(), &zero, 1);
								ENetPacket* packet = enet_packet_create(p.data,
									p.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet);
								ENetPacket* packet2 = enet_packet_create(data,
									5 + text.length(),
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet2);
								delete data;
								delete p.data;
								GamePacket p3 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), name + " `wis now level " + std::to_string(((PlayerInfo*)(peer->data))->level) + "!"));
								ENetPacket* packet3 = enet_packet_create(p3.data,
									p3.len,
									ENET_PACKET_FLAG_RELIABLE);
								enet_peer_send(currentPeer, 0, packet3);
							}
							data.plantingTree = tile;
						}
					}
				}
				if (((PlayerInfo*)(peer->data))->haveGrowId) {
					std::ifstream ifff("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json");
					PlayerInfo* p = ((PlayerInfo*)(peer->data));
					string username = PlayerDB::getProperName(p->rawName);
					if (ifff.fail()) {
						ifff.close();
					}
					if (ifff.is_open()) {
					}
					json j;
					ifff >> j; //load
					j["level"] = p->level;
					j["xp"] = p->xp;
					j["rubblexp"] = p->rubblexp;
					j["rubble"] = p->rubble;
					j["amberxp"] = p->amberxp;
					j["amber"] = p->amber;
					j["opalxp"] = p->opalxp;
					j["opal"] = p->opal;
					j["goldxp"] = p->goldxp;
					j["gold"] = p->gold;
					j["sapphirexp"] = p->sapphirexp;
					j["sapphire"] = p->sapphire;
					j["diamondxp"] = p->diamondxp;
					j["diamond"] = p->diamond;
					j["emeraldxp"] = p->emeraldxp;
					j["emerald"] = p->emerald;
					std::ofstream o("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json"); //save
					if (!o.is_open()) {
						cout << GetLastError() << endl;
						_getch();
					}
					o << j << std::endl;
				}
			}
			else
				if (y < world->height)
				{
					world->items[x + (y * world->width)].breakTime = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
					world->items[x + (y * world->width)].breakLevel += 6; // TODO
				}
	}
	else {
		for (int i = 0; i < ((PlayerInfo*)(peer->data))->inventory.items.size(); i++)
		{
			if (((PlayerInfo*)(peer->data))->inventory.items.at(i).itemID == tile)
			{
				if ((unsigned int)((PlayerInfo*)(peer->data))->inventory.items.at(i).itemCount > 1)
				{
					((PlayerInfo*)(peer->data))->inventory.items.at(i).itemCount--;
					SaveInventoryWhenBuildingBlock(peer);
				}
				else {
					((PlayerInfo*)(peer->data))->inventory.items.erase(((PlayerInfo*)(peer->data))->inventory.items.begin() + i);
					SaveInventoryWhenBuildingBlock(peer);
				}
			}
		}
		if (world->areLogsEnabled == true)
		{
			ofstream savelogs("worldlogs/" + world->name + ".txt", std::ios_base::app);
			savelogs << ((PlayerInfo*)(peer->data))->rawName << " placed " << getItemDef(tile).name << "(" << tile << ")" << endl;
		}
		ItemDefinition yologay;
		if (def.blockType == BlockTypes::BACKGROUND)
		{
			world->items[x + (y * world->width)].background = tile;
			data.plantingTree = tile;
		}
		else {
			if (world->items[x + (y * world->width)].foreground != 0) return;

			if (tile == 9422)
			{
				std::ofstream outfile("gemplant/gems/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
				outfile << 0;
				outfile.close();
				std::ofstream outfile3("gemplant/status/" + ((PlayerInfo*)(peer->data))->currentWorld + ".txt");
				outfile3 << 1;
				outfile3.close();
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "Activated the Gemplant!", 0, true);
			}
			if (getItemDef(tile).blockType == BlockTypes::LOCK) {
				world->items[x + (y * world->width)].foreground = tile;
				world->owner = ((PlayerInfo*)(peer->data))->rawName;
				world->Displayowner = ((PlayerInfo*)(peer->data))->displayName;
				world->isPublic = false;
				((PlayerInfo*)(peer->data))->worldsowned.push_back(world->name);
				std::ifstream ifff("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json");
				if (ifff.fail()) {
					ifff.close();
				}
				if (ifff.is_open()) {
				}
				json j;
				ifff >> j; //load
				j["worldsowned"] = ((PlayerInfo*)(peer->data))->worldsowned; //edit
				std::ofstream o("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json"); //save
				if (!o.is_open()) {
					cout << GetLastError() << endl;
					_getch();
				}
				o << j << std::endl;
				if (((PlayerInfo*)(peer->data))->haveGrowId)
				{
					if (((PlayerInfo*)(peer->data))->isNicked == false)
					{
						GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`2" + ((PlayerInfo*)(peer->data))->displayName));
						memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
						ENetPacket* packet7 = enet_packet_create(p7.data,
							p7.len,
							ENET_PACKET_FLAG_RELIABLE);
						delete p7.data;
						for (currentPeer = server->peers;
							currentPeer < &server->peers[server->peerCount];
							++currentPeer)
						{
							if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
								continue;
							if (isHere(peer, currentPeer)) {
								if (((PlayerInfo*)(peer->data))->adminLevel >= 0) {
									enet_peer_send(currentPeer, 0, packet7);
								}
							}
						}
					}
				}
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 1000 && ((PlayerInfo*)(peer->data))->isCreator != true) {
							world->pIsDev = true;
						}
						else if (((PlayerInfo*)(peer->data))->isCreator == true && ((PlayerInfo*)(peer->data))->adminLevel == 1000)
						{
							world->pIsPlay = true;
						}
						else if (((PlayerInfo*)(peer->data))->isCreator == true && ((PlayerInfo*)(peer->data))->adminLevel == 999)
						{
							world->pIsPlay = true;
						}
						else if (((PlayerInfo*)(peer->data))->adminLevel == 999 && ((PlayerInfo*)(peer->data))->isCreator != true) {
							world->pIsDev = true;
						}
						else if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
							world->pIsMod = true;
						}
						else if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
							world->pIsVip = true;
						}
						else if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
							world->pIsAdmin = true;
						}
						else if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
							world->pIsKing = true;
						}
						else
						{
							world->pIsPlay = false;
							world->pIsDev = false;
							world->pIsMod = false;
							world->pIsVip = false;
							world->pIsAdmin = false;
							world->pIsKing = false;
						}
						if (((PlayerInfo*)(peer->data))->adminLevel >= 0)
						{
							//isLock = true;
							string text = "action|play_sfx\nfile|audio/use_lock.wav\ndelayMS|0\n";
							BYTE* data = new BYTE[5 + text.length()];
							BYTE zero = 0;
							int type = 3;
							memcpy(data, &type, 4);
							memcpy(data + 4, text.c_str(), text.length()); // change memcpy here
							memcpy(data + 4 + text.length(), &zero, 1); // change memcpy here, revert to 4
							ENetPacket* packetsou = enet_packet_create(data,
								5 + text.length(),
								ENET_PACKET_FLAG_RELIABLE);
							enet_peer_send(currentPeer, 0, packetsou);
							Player::OnConsoleMessage(currentPeer, "`3[`w" + world->name + " `ohas been `$" + getItemDef(world->items[x + (y * world->width)].foreground).name + "ed `oBy `w" + ((PlayerInfo*)(peer->data))->displayName + "`3]");
						}
					}
				}
			}
			world->items[x + (y * world->width)].foreground = tile;
			yologay = getItemDef(tile);
			if (yologay.MultiFacing == "MultiFacing") {
				if (((PlayerInfo*)(peer->data))->RotatedLeft == true) {
					((PlayerInfo*)(peer->data))->wrenchx = x;
					((PlayerInfo*)(peer->data))->wrenchy = y;
					int squaresign = x + (y * 100);
					//world->items[x + (y * world->width)].rotatedLeft = true;
					world->items[squaresign].rotatedLeft = true;
				}
				else {
					world->items[x + (y * world->width)].rotatedLeft = false;
				}
			}
			else {
				world->items[x + (y * world->width)].foreground = tile;
			}
		}
		world->items[x + (y * world->width)].breakLevel = 0;
	}
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer))
			SendPacketRaw(4, packPlayerMoving(&data), 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		ItemDefinition retard;
		retard = getItemDef(tile);
		if (retard.MultiFacing == "MultiFacing") {
			if (((PlayerInfo*)(peer->data))->RotatedLeft == true) {
				int squaresign = x + (y * 100);
				world->items[squaresign].rotatedLeft = true;
				updateRotatedItem(peer, world->items[squaresign].foreground, squaresign % world->width, squaresign / world->width, "", world->items[squaresign].background);
			}
		}
	}
}