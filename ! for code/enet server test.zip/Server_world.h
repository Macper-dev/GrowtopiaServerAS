#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include "enet/enet.h"
#include <cmath>
#include <string>
#include <windows.h>
#include <vector>
#include <ctime>
#include <time.h>
#include <sstream>
#include <chrono>
#include <fstream>
#include "psapi.h"
#include "json.hpp"
#include <conio.h>
#include <thread>
#include <experimental/filesystem>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <regex>
#include <filesystem>
#include <wininet.h>
#include <cstring>
#include <locale>
#include <stdexcept>

struct Crystal
{
	string name;
	int probability;
	Crystal(string s, int p) :name(s), probability(p) {}
};
struct WorldItem {
	__int16 foreground = 0;
	__int16 background = 0;
	int displayblock = 0;
	int breakLevel = 0;
	long long int breakTime = 0;
	bool sign = false;
	bool water = false;
	bool rotatedLeft = false;
	bool fire = false;
	bool glue = false;
	bool red = false;
	bool green = false;
	bool flipped = false;
	bool blue = false;
	int displayBlock = 0;
	int gravity = 100;
	int intdata = 0;
	bool isInverted = false;
	bool isRotating = false;
	string label = "";
	string destWorld = "";
	string destId = "";
	string currId = "";
	string password = "";
	string text = "";
	vector<string> mailbox;
	bool isOpened = false;
};
struct InfoDropedItems {
	int itemid = 0;
	int quantity = 0;
	int positionx = 0;
	int positiony = 0;
};
struct DroppedItem { // TODO
	int id = 0;
	int uid = -1;
	int count = 0;
	int x = -1, y = -1;
};
vector<InfoDropedItems> dropedItems;
struct WorldInfo {
	int width = 100;
	int height = 60;
	bool nuked = false;
	string name = "TEST";
	int ownerID = 0;
	bool areLogsEnabled = false;
	WorldItem* items;
	int droppedCount = 0;
	string owner = "";
	string Displayowner = "";
	vector<DroppedItem> droppedItems;
	int droppedItemUid = 0;
	int geigerX = 0;
	int geigerY = 0;
	bool isPublic = false;
	bool allowMod = false;
	bool pIsVip = false;
	bool pIsMod = false;
	bool pIsDev = false;
	bool pIsPlay = false;
	bool pIsAdmin = false;
	bool pIsKing = false;
	bool isEvent = true;
	bool noclip = false;
	int ghostalr = 0;
	int invisalr = 0;
	int weather = 0;
	vector<string> worldaccess;
};
struct AWorld {
	WorldInfo* ptr;
	WorldInfo info;
	int id;
};
struct TileExtra {
	int packetType;
	int characterState;
	float objectSpeedX;
	int punchX;
	int punchY;
	int charStat;
	int blockid;
	int visual;
	int signs;
	int backgroundid;
	int displayblock;
	int time;
	int netID;
	int weatherspeed;
	int bpm;
};
struct BlockVisual {
	int packetType;
	int characterState;
	int punchX;
	int punchY;
	float x;
	float y;
	int plantingTree;
	float XSpeed;
	float YSpeed;
	int charStat;
	int blockid;
	int visual;
	int signs;
	int backgroundid;
	int displayblock;
	int time;
	int netID;
};
enum BlockTypes {
	FOREGROUND,
	BACKGROUND,
	CONSUMABLE,
	SEED,
	PAIN_BLOCK,
	BEDROCK,
	MAIN_DOOR,
	SIGN,
	DOOR,
	CLOTHING,
	FIST,
	WRENCH,
	CHECKPOINT,
	LOCK,
	GATEWAY,
	TREASURE,
	WEATHER,
	TRAMPOLINE,
	TOGGLE_FOREGROUND,
	SWITCH_BLOCK,
	SFX_FOREGROUND,
	RANDOM_BLOCK,
	PORTAL,
	PLATFORM,
	MAILBOX,
	MAGIC_EGG,
	CRYSTAL,
	GEMS,
	DEADLY,
	CHEST,
	FACTION,
	BULLETIN_BOARD,
	BOUNCY,
	ANIM_FOREGROUND,
	COMPONENT,
	UNKNOWN
};
#define Property_Zero 0
#define Property_NoSeed 1
#define Property_Dropless 2
#define Property_Beta 4
#define Property_Mod 8
#define Property_Untradable 16
#define Property_Wrenchable 32
#define Property_MultiFacing 64
#define Property_Permanent 128
#define Property_AutoPickup 256
#define Property_WorldLock 512
#define Property_NoSelf 1024
#define Property_RandomGrow 2048
#define Property_Public 4096
class WorldDB {
public:
	WorldInfo get(string name);
	AWorld get2(string name);
	void flush(WorldInfo info);
	void flush2(AWorld info);
	void save(AWorld info);
	void saveAll();
	void saveRedundant();
	void remove(string name);
	vector<WorldInfo> getRandomWorlds();
	WorldDB();
private:
	vector<WorldInfo> worlds;
};
namespace packet {
	void storerequest(ENetPeer* peer, string message) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnStoreRequest"), message));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	void hubrequest(ENetPeer* peer, string message) {
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnCommunityHubRequest"), message));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
}
WorldDB::WorldDB() {
}
WorldInfo generateCleanWorld(string name, int width, int height)
{
	WorldInfo world;
	world.name = name;
	world.nuked = false;
	world.width = width;
	world.height = height;
	world.items = new WorldItem[world.width * world.height];
	for (int i = 0; i < world.width * world.height; i++)
	{
		if (i >= 3800 && i < 5400 && !(rand() % 50)) { world.items[i].foreground = 0; }
		else if (i >= 3700 && i < 5400) {
			if (i > 5000) {
				if (i % 7 == 0) { world.items[i].foreground = 0; }
				else { world.items[i].foreground = 0; }
			}
			else { world.items[i].foreground = 0; }
		}
		else if (i >= 5400) { world.items[i].foreground = 8; }
		if (i >= 3700)
			world.items[i].background = 14;
		if (i == 3650)
			world.items[i].foreground = 6; //BALTOS DURYS
		else if (i >= 3600 && i < 3700)
			world.items[i].foreground = 0; //TUSCIA DURU LYGIS
		if (i == 3750)
			world.items[i].foreground = 8; //BEDROCK
	}
	return world;
}
void GenerateRegularWorld(WorldInfo* world, int width, int height, int dirtType = 2, int lavaType = 4, int mainDoorType = 6, int bedrockType = 8, int rockType = 10, int caveBackgroundType = 14, int machineId = 0)
{
	world->weather = machineId;
	int mainDoorX = (rand() % (world->width - 4)) + 2;
	for (int i = 0; i < world->width * world->height; i++)
	{
		world->items[i].foreground = 0;
	}
	for (int i = 0; i < world->width * world->height; i++)
	{
		if (i >= 3800 && i < 5400 && !(rand() % 50)) { world->items[i].foreground = rockType; }
		else if (i >= 3700 && i < 5400) {
			if (i > 5000) {
				int m = rand() % 8;
				if (m < 3) { world->items[i].foreground = lavaType; }
				else { world->items[i].foreground = dirtType; }
			}
			else { world->items[i].foreground = dirtType; }
		}
		else if (i >= 5400) { world->items[i].foreground = bedrockType; }
		if (i == 3600 + mainDoorX)
			world->items[i].foreground = mainDoorType;
		if (i == 3700 + mainDoorX)
			world->items[i].foreground = bedrockType;
		if (i >= 3700)
			world->items[i].background = caveBackgroundType;
	}
}
WorldInfo generateUranusWorld(string name, int width, int height)
{
	WorldInfo world;
	world.name = name;
	world.nuked = false;
	world.width = width;
	world.height = height;
	int mainDoorX = (rand() % (world.width - 4)) + 2;
	world.items = new WorldItem[world.width * world.height];
	int treasure = (rand() % 4400);
	for (int i = 0; i < world.width * world.height; i++)
	{
		if (i >= 100 && i < 4470 && !(rand() % 99)) { world.items[i].foreground = 9440; }
		else if (i == treasure) { world.items[i].foreground = 7628; }
		else if (i > 1200 && i < 4470 && !(rand() % 99)) { world.items[i].foreground = 9442; }
		else if (i > 2500 && i < 4470 && !(rand() % 99)) { world.items[i].foreground = 7960; }
		else if (i >= 0 && i < 4500) {
			world.items[i].foreground = 1132;
		}
		if (i >= 0 && i <= 29)
			world.items[i].foreground = 8;
		if (i >= 0)
			world.items[i].background = 9438;
		if (i == 550 + mainDoorX) {
			world.items[i].foreground = 6;
		}
		if (i >= 1000 && i <= 1030)
			world.items[i].foreground = 9444;
		if (i >= 4470)
			world.items[i].foreground = 8;
	}
	return world;
}
WorldInfo MakeWorldFromScratch(string name, int width, int height, int dirtType = 2, int lavaType = 4, int mainDoorType = 6, int bedrockType = 8, int rockType = 10, int caveBackgroundType = 14)
{
	if (usedgenworld == true)
	{
		usedgenworld = false;
		int width3 = genwidth;
		int height3 = genheight;
		int dirttype3 = genforeground;
		int bedrocktype3 = genbedrock;
		int cavebackgroundtype3 = genbackground;
		WorldInfo world;
		world.name = name;
		world.width = width;
		world.height = height;
		world.items = new WorldItem[world.width * world.height];
		GenerateRegularWorld(&world, width3, height3, dirttype3, lavaType, mainDoorType, bedrocktype3, rockType, cavebackgroundtype3);
		genwidth = 0;
		genheight = 0;
		genforeground = 0;
		genbedrock = 0;
		genbackground = 0;
		return world;
	}
	else {
		WorldInfo world;
		world.name = name;
		world.width = width;
		world.height = height;
		world.items = new WorldItem[world.width * world.height];
		GenerateRegularWorld(&world, width, height, dirtType, lavaType, mainDoorType, bedrockType, rockType, caveBackgroundType);
		return world;
	}

}
WorldInfo generateMarsWorld(string name, int width, int height)
{
	WorldInfo world;
	world.name = name;
	world.nuked = false;
	world.width = width;
	world.height = height;
	world.items = new WorldItem[world.width * world.height];
	for (int i = 0; i < world.width * world.height; i++)
	{
		if (i >= 3800 && i < 5400 && !(rand() % 50)) { world.items[i].foreground = 150; }
		else if (i >= 3700 && i < 5400) {
			if (i > 5000) {
				if (i % 7 == 0) { world.items[i].foreground = 45; }
				else { world.items[i].foreground = 25; }
			}
			else { world.items[i].foreground = 52; }
		}
		else if (i >= 5400) { world.items[i].foreground = 82; }
		if (i >= 3700)
			world.items[i].background = 114;
		if (i == 3650)
			world.items[i].foreground = 63;
		else if (i >= 3600 && i < 3700)
			world.items[i].foreground = 03; //fixed the grass in the world!
		if (i == 3750)
			world.items[i].foreground = 84;
	}
	return world;
}
WorldInfo ClearWorld(string name, int width, int height)
{
	WorldInfo world;
	world.name = name;
	world.nuked = false;
	world.width = width;
	world.height = height;
	world.items = new WorldItem[world.width * world.height];
	for (int i = 0; i < world.width * world.height; i++)
	{
		if (i >= 3800 && i < 5400 && !(rand() % 50)) { world.items[i].foreground = 0; }
		else if (i >= 3700 && i < 5400) {
			if (i > 5000) {
				if (i % 7 == 0) { world.items[i].foreground = 0; }
				else { world.items[i].foreground = 0; }
			}
			else { world.items[i].foreground = 2; }
		}
		else if (i >= 5400) { world.items[i].foreground = 8; }
		if (i >= 3700)
			world.items[i].background = 0;
		if (i == 3650)
			world.items[i].foreground = 6;
		else if (i >= 3600 && i < 3700)
			world.items[i].foreground = 0; //fixed the grass in the world!
		if (i == 3750)
			world.items[i].foreground = 8;
	}
	return world;
}
int PlayerDB::guildRegister(ENetPeer* peer, string guildName, string guildStatement, string guildFlagfg, string guildFlagbg) {
	string uname = guildName;
	if (guildName.find(" ") != string::npos || guildName.find(".") != string::npos || guildName.find(",") != string::npos || guildName.find("?") != string::npos || guildName.find("@") != string::npos || guildName.find("[") != string::npos || guildName.find("]") != string::npos || guildName.find("#") != string::npos || guildName.find("<") != string::npos || guildName.find(">") != string::npos || guildName.find(":") != string::npos || guildName.find("{") != string::npos || guildName.find("}") != string::npos || guildName.find("|") != string::npos || guildName.find("+") != string::npos || guildName.find("_") != string::npos || guildName.find("~") != string::npos || guildName.find("-") != string::npos || guildName.find("!") != string::npos || guildName.find("$") != string::npos || guildName.find("%") != string::npos || guildName.find("^") != string::npos || guildName.find("&") != string::npos || guildName.find("`") != string::npos || guildName.find("*") != string::npos || guildName.find("(") != string::npos || guildName.find(")") != string::npos || guildName.find("=") != string::npos || guildName.find("'") != string::npos || guildName.find(";") != string::npos || guildName.find("/") != string::npos) {
		return -1;
	}
	toUpperCase(uname);
	if (guildName.length() < 3) {
		return -2;
	}
	if (uname == "CON" || uname == "NUL" || uname == "PRN" || uname == "AUX" || uname == "CLOCK$" || uname == "COM0" || uname == "COM1" || uname == "COM2" || uname == "COM3" || uname == "COM4" || uname == "COM5" || uname == "COM6" || uname == "COM7" || uname == "COM8" || uname == "COM9" || uname == "LPT0" || uname == "LPT1" || uname == "LPT2" || uname == "LPT3" || uname == "LPT4" || uname == "LPT5" || uname == "LPT6" || uname == "LPT7" || uname == "LPT8" || uname == "LPT9")
	{
		return -1;
	}
	if (guildName.length() > 15) {
		return -3;
	}
	int fg;
	int bg;
	try {
		fg = stoi(guildFlagfg);
	}
	catch (std::invalid_argument& e) {
		return -6;
	}
	try {
		bg = stoi(guildFlagbg);
	}
	catch (std::invalid_argument& e) {
		return -5;
	}
	if (guildFlagbg.length() > 4) {
		return -7;
	}
	if (guildFlagfg.length() > 4) {
		return -8;
	}
	string fixedguildName = PlayerDB::getProperName(guildName);
	std::ifstream ifs("guilds/" + fixedguildName + ".json");
	if (ifs.is_open()) {
		return -4;
	}
	return 1;
}
void WorldDB::remove(string name) {
	try {
		for (int i = 0; i < worlds.size(); i++)
		{
			WorldInfo w = worlds.at(i);
			if (getStrLower(name) == getStrLower(w.name))
			{
				worlds.erase(worlds.begin() + i);
			}
		}
		std::remove(("worlds/" + name + ".json").c_str());
	}
	catch (std::exception& e)
	{
		std::cerr << e.what() << std::endl;
	}
	catch (const std::out_of_range& e) {
		cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
	}
	catch (...) {
		cout << "reading file violation" << endl;
	}
}

AWorld WorldDB::get2(string name) {
	if (worlds.size() > 200) {
#ifdef TOTAL_LOG
		cout << "Saving redundant worlds!" << endl;
#endif
		saveRedundant();
#ifdef TOTAL_LOG
		cout << "Redundant worlds are saved!" << endl;
#endif
	}
	AWorld ret;
	name = getStrUpper(name);
	if (name.length() < 1) throw 1; // too short name
	for (char c : name) {
		if ((c < 'A' || c>'Z') && (c < '0' || c>'9'))
			throw 3; // wrong name
	}
	if (name == "EXIT") {
		throw 3;
	}
	if (name.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") != string::npos) {
		throw 3;
	}
	if (name == "CON" || name == "PRN" || name == "AUX" || name == "NUL" || name == "COM1" || name == "COM2" || name == "COM3" || name == "COM4" || name == "COM5" || name == "COM6" || name == "COM7" || name == "COM8" || name == "COM9" || name == "LPT1" || name == "LPT2" || name == "LPT3" || name == "LPT4" || name == "LPT5" || name == "LPT6" || name == "LPT7" || name == "LPT8" || name == "LPT9") throw 3;
	for (int i = 0; i < worlds.size(); i++) {
		if (worlds.at(i).name == name)
		{
			ret.id = i;
			ret.info = worlds.at(i);
			ret.ptr = &worlds.at(i);
			return ret;
		}
	}
	try {
		std::ifstream ifs("worlds/" + name + ".json");
		if (ifs.is_open()) {
			json j;
			ifs >> j;
			WorldInfo info;
			info.name = j["name"].get<string>();
			info.width = j["width"];
			info.nuked = j["nuked"];
			info.height = j["height"];
			info.owner = j["owner"].get<string>();
			vector <string>frns;
			if (j.count("access") == 1) {
				for (int i = 0; i < j["access"].size(); i++) {
					frns.push_back(j["access"][i]);
				}
			}
			else {
				frns = {};
			}
			info.worldaccess = frns;
			info.Displayowner = j["Displayowner"].get<string>();
			info.isPublic = j["isPublic"];
			info.allowMod = j["allowMod"];
			info.pIsVip = j["isVip"];
			info.pIsMod = j["isMod"];
			info.weather = j["weather"];
			info.pIsDev = j["isDev"];
			info.pIsPlay = j["isPlay"];
			json tiles = j["tiles"];
			int square = info.width * info.height;
			info.items = new WorldItem[square];
			for (int i = 0; i < square; i++) {
				info.items[i].foreground = tiles[i]["fg"];
				info.items[i].background = tiles[i]["bg"];
			}
			worlds.push_back(info);
			ret.id = worlds.size() - 1;
			ret.info = info;
			ret.ptr = &worlds.at(worlds.size() - 1);
			ifs.close();
			return ret;
		}
		else {
			if (useduranusblast == true)
			{
				useduranusblast = false;
				WorldInfo info = generateUranusWorld(name, 30, 150);
				worlds.push_back(info);
				ret.id = worlds.size() - 1;
				ret.info = info;
				ret.ptr = &worlds.at(worlds.size() - 1);
				return ret;
			}
			else {
				WorldInfo info = MakeWorldFromScratch(name, 100, 60);
				worlds.push_back(info);
				ret.id = worlds.size() - 1;
				ret.info = info;
				ret.ptr = &worlds.at(worlds.size() - 1);
				return ret;
			}
		}
	}
	catch (std::exception& e)
	{
		std::cerr << e.what() << std::endl;
	}
	catch (const std::out_of_range& e) {
		cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
	}
	catch (...) {
		cout << "reading file violation" << endl;
	}
	throw 1;
}
WorldInfo WorldDB::get(string name) {
	return this->get2(name).info;
}
void WorldDB::flush(WorldInfo info)
{
	try {
		std::ofstream o("worlds/" + info.name + ".json");
		if (!o.is_open()) {
			cout << GetLastError() << endl;
		}
		json j;
		j["name"] = info.name;
		j["width"] = info.width;
		j["height"] = info.height;
		j["nuked"] = info.nuked;
		j["owner"] = info.owner;
		j["weather"] = info.weather;
		j["access"] = info.worldaccess;
		j["Displayowner"] = info.Displayowner;
		j["allowMod"] = info.allowMod;
		j["isVip"] = info.pIsVip;
		j["isMod"] = info.pIsMod;
		j["isDev"] = info.pIsDev;
		j["isPlay"] = info.pIsPlay;
		j["isPublic"] = info.isPublic;
		j["weather"] = info.weather;
		json tiles = json::array();
		int square = info.width * info.height;
		for (int i = 0; i < square; i++)
		{
			json tile;
			tile["fg"] = info.items[i].foreground;
			tile["bg"] = info.items[i].background;
			tiles.push_back(tile);
		}
		j["tiles"] = tiles;
		o << j << std::endl;
	}
	catch (std::exception& e)
	{
		std::cerr << e.what() << std::endl;
	}
	catch (const std::out_of_range& e) {
		cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
	}
	catch (...) {
		cout << "reading file violation" << endl;
	}
	try {
		if (info.items != nullptr)
		{
			delete[] info.items;
		}
	}
	catch (const std::exception& ex)
	{
		std::cout << ex.what() << std::endl;
	}
}
void WorldDB::flush2(AWorld info)
{
	this->flush(info.info);
}
void WorldDB::save(AWorld info)
{
	flush2(info);
	//delete info.info.items;
	worlds.erase(worlds.begin() + info.id);
}
void WorldDB::saveAll()
{
	for (int i = 0; i < worlds.size(); i++) {
		flush(worlds.at(i));
		//delete worlds.at(i).items;
	}
	worlds.clear();
}

vector<WorldInfo> WorldDB::getRandomWorlds() {
	vector<WorldInfo> ret;
	for (int i = 0; i < ((worlds.size() < 10) ? worlds.size() : 10); i++)
	{ // load first four worlds, it is excepted that they are special
		ret.push_back(worlds.at(i));
	}
	// and lets get up to 6 random
	if (worlds.size() > 4) {
		for (int j = 0; j < 6; j++)
		{
			bool isPossible = true;
			WorldInfo world = worlds.at(rand() % (worlds.size() - 4));
			for (int i = 0; i < ret.size(); i++)
			{
				if (world.name == ret.at(i).name || world.name == "EXIT")
				{
					isPossible = false;
				}
			}
			if (isPossible)
				ret.push_back(world);
		}
	}
	return ret;
}
BYTE* packBlockVisual222(TileExtra* dataStruct)
{

	BYTE* data = new BYTE[104]; // 96
	for (int i = 0; i < 100; i++)
	{
		data[i] = 0;
	}
	memcpy(data, &dataStruct->packetType, 4);
	memcpy(data + 8, &dataStruct->netID, 4);
	memcpy(data + 12, &dataStruct->characterState, 4);
	memcpy(data + 16, &dataStruct->objectSpeedX, 4);
	//memcpy(data + 40, &dataStruct->bpm, 4);
	memcpy(data + 44, &dataStruct->punchX, 4);
	memcpy(data + 48, &dataStruct->punchY, 4);
	memcpy(data + 52, &dataStruct->charStat, 4);
	memcpy(data + 56, &dataStruct->blockid, 2);
	memcpy(data + 58, &dataStruct->backgroundid, 2);
	memcpy(data + 60, &dataStruct->visual, 4);
	memcpy(data + 64, &dataStruct->displayblock, 4);


	return data;
}
void WorldDB::saveRedundant()
{
	for (int i = 4; i < worlds.size(); i++) {
		bool canBeFree = true;
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (((PlayerInfo*)(currentPeer->data))->currentWorld == worlds.at(i).name)
				canBeFree = false;
		}
		if (canBeFree)
		{
			flush(worlds.at(i));
			delete worlds.at(i).items;
			worlds.erase(worlds.begin() + i);
			i--;
		}
	}
}
WorldDB worldDB;
bool isHereSave(ENetPeer* peer, ENetPeer* peer2)
{
	return ((PlayerInfo*)(peer->data))->currentWorld == ((PlayerInfo*)(peer2->data))->currentWorld;
}
int getPlayersCountInWorldSave(string name)
{
	int count = 0;
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (((PlayerInfo*)(currentPeer->data))->isinv == false)
		{
			if (((PlayerInfo*)(currentPeer->data))->currentWorld == name)
				count++;
		}
	}
	return count;
}
void sendPlayerLeaveSave(ENetPeer* peer, PlayerInfo* player)
{
	ENetPeer* currentPeer;
	GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnRemove"), "netID|" + std::to_string(player->netID) + "\n"));
	GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`5<`w" + ((PlayerInfo*)(peer->data))->displayName + "`` `5left, `w" + std::to_string(getPlayersCountInWorldSave(player->currentWorld)) + "`` `5others here>```w"));
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (((PlayerInfo*)(currentPeer->data))->currentWorld == "EXIT")
			continue;
		if (((PlayerInfo*)(currentPeer->data))->isIn == false)
			continue;
		if (isHereSave(peer, currentPeer)) {
			{
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				{
					ENetPacket* packet = enet_packet_create(p.data,
						p.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet);
				}
			}
			{
			}
		}
	}
	delete p.data;
	delete p2.data;
}
void saveAllWorlds()
{
	serverIsFrozen = true;
	worldDB.saveAll();
	Sleep(5000);
	ENetPeer* currentPeerz;
	for (currentPeerz = server->peers;
		currentPeerz < &server->peers[server->peerCount];
		++currentPeerz)
	{
		if (currentPeerz->state != ENET_PEER_STATE_CONNECTED)
			continue;
		Player::OnConsoleMessage(currentPeerz, "`w[`4SYSTEM`w] `5Worlds Saved`o!");
		Player::OnConsoleMessage(currentPeerz, "`w[`4SYSTEM`w] `5Dropped Items Cleared`o!");
	}
	serverIsFrozen = false;
}
WorldInfo* getPlyersWorld(ENetPeer* peer)
{ 
	try {
		return worldDB.get2(((PlayerInfo*)(peer->data))->currentWorld).ptr;
	}
	catch (int e) {
		return NULL;
	}
}

void saveMyWorld(ENetPeer* peer)
{
	AWorld info = worldDB.get2(((PlayerInfo*)(peer->data))->currentWorld);
	worldDB.save(info);
	cout << "[INFO] Player " + ((PlayerInfo*)(peer->data))->rawName << " saved his " << ((PlayerInfo*)(peer->data))->currentWorld << " world" << endl;
	Player::OnConsoleMessage(peer, "`w[`4SYSTEM`w] `5World Saved`o!");
	Player::OnConsoleMessage(peer, "`w[`4SYSTEM`w] `5Dropped Items Cleared`o!");
}
struct ItemDefinition {
	int id;
	string name;
	int rarity;
	int breakHits;
	int growTime;
	ClothTypes clothType;
	BlockTypes blockType;
	string description = "This item has no description.";
	string MultiFacing = "This item can be placed in both directions.";
	int properties;
};
vector<ItemDefinition> itemDefs;
vector<DroppedItem> droppedItems;
ItemDefinition getItemDef(int id)
{
	if (id < itemDefs.size() && id > -1)
		return itemDefs.at(id);
	throw 0;
	return itemDefs.at(0);
}
void craftItemDescriptions() {
	int current = -1;
	std::ifstream infile("Descriptions.txt");
	for (std::string line; getline(infile, line);)
	{
		if (line.length() > 3 && line[0] != '/' && line[1] != '/')
		{
			vector<string> ex = explode("|", line);
			ItemDefinition def;
			if (atoi(ex[0].c_str()) + 1 < itemDefs.size())
			{
				itemDefs.at(atoi(ex[0].c_str())).description = ex[1];
				if (!(atoi(ex[0].c_str()) % 2))
					itemDefs.at(atoi(ex[0].c_str()) + 1).description = "This is a tree.";
			}
		}
	}
}
void buildItemsDatabase()
{
	int current = -1;
	std::ifstream infile("CoreData.txt");
	for (std::string line; getline(infile, line);)
	{
		if (line.length() > 8 && line[0] != '/' && line[1] != '/')
		{
			vector<string> ex = explode("|", line);
			ItemDefinition def;
			def.id = atoi(ex[0].c_str());
			def.name = ex[1];
			def.rarity = atoi(ex[2].c_str());
			def.breakHits = atoi(ex[7].c_str());
			vector<string> properties = explode(", ", ex[3]);
			def.properties = Property_Zero;
			for (auto &prop : properties)
			{
				if (prop == "NoSeed")
					def.properties += Property_NoSeed;
				if (prop == "Dropless")
					def.properties += Property_Dropless;
				if (prop == "Beta")
					def.properties += Property_Beta;
				if (prop == "Mod")
					def.properties += Property_Mod;
				if (prop == "Untradable")
					def.properties += Property_Untradable;
				if (prop == "Wrenchable")
					def.properties += Property_Wrenchable;
				if (prop == "MultiFacing")
					def.properties += Property_MultiFacing;
				if (prop == "Permanent")
					def.properties += Property_Permanent;
				if (prop == "AutoPickup")
					def.properties += Property_AutoPickup;
				if (prop == "WorldLock")
					def.properties += Property_WorldLock;
				if (prop == "NoSelf")
					def.properties += Property_NoSelf;
				if (prop == "RandomGrow")
					def.properties += Property_RandomGrow;
				if (prop == "Public")
					def.properties += Property_Public;
			}
			string bt = ex[4];
			if (bt == "Foreground_Block") {
				def.blockType = BlockTypes::FOREGROUND;
			}
			else if (bt == "Seed") {
				def.blockType = BlockTypes::SEED;
			}
			else if (bt == "Consummable") {
				def.blockType = BlockTypes::CONSUMABLE;
			}
			else if (bt == "Pain_Block") {
				def.blockType = BlockTypes::PAIN_BLOCK;
			}
			else if (bt == "Main_Door") {
				def.blockType = BlockTypes::MAIN_DOOR;
			}
			else if (bt == "Bedrock") {
				def.blockType = BlockTypes::BEDROCK;
			}
			else if (bt == "Door") {
				def.blockType = BlockTypes::DOOR;
			}
			else if (bt == "Fist") {
				def.blockType = BlockTypes::FIST;
			}
			else if (bt == "Sign") {
				def.blockType = BlockTypes::SIGN;
			}
			else if (bt == "Background_Block") {
				def.blockType = BlockTypes::BACKGROUND;
			}
			else if (bt == "Sheet_Music") {
				def.blockType = BlockTypes::BACKGROUND;
			}
			else if (bt == "Wrench") {
				def.blockType = BlockTypes::WRENCH;
			}
			else if (bt == "Checkpoint") {
				def.blockType = BlockTypes::CHECKPOINT;
			}
			else if (bt == "Lock") {
				def.blockType = BlockTypes::LOCK;
			}
			else if (bt == "Gateway") {
				def.blockType = BlockTypes::GATEWAY;
			}
			else if (bt == "Clothing") {
				def.blockType = BlockTypes::CLOTHING;
			}
			else if (bt == "Platform") {
				def.blockType = BlockTypes::PLATFORM;
			}
			else if (bt == "SFX_Foreground") {
				def.blockType = BlockTypes::SFX_FOREGROUND;
			}
			else if (bt == "Gems") {
				def.blockType = BlockTypes::GEMS;
			}
			else if (bt == "Toggleable_Foreground") {
				def.blockType = BlockTypes::TOGGLE_FOREGROUND;
			}
			else if (bt == "Treasure") {
				def.blockType = BlockTypes::TREASURE;
			}
			else if (bt == "Deadly_Block") {
				def.blockType = BlockTypes::DEADLY;
			}
			else if (bt == "Trampoline_Block") {
				def.blockType = BlockTypes::TRAMPOLINE;
			}
			else if (bt == "Animated_Foreground_Block") {
				def.blockType = BlockTypes::ANIM_FOREGROUND;
			}
			else if (bt == "Portal") {
				def.blockType = BlockTypes::PORTAL;
			}
			else if (bt == "Random_Block") {
				def.blockType = BlockTypes::RANDOM_BLOCK;
			}
			else if (bt == "Bouncy") {
				def.blockType = BlockTypes::BOUNCY;
			}
			else if (bt == "Chest") {
				def.blockType = BlockTypes::CHEST;
			}
			else if (bt == "Switch_Block") {
				def.blockType = BlockTypes::SWITCH_BLOCK;
			}
			else if (bt == "Magic_Egg") {
				def.blockType = BlockTypes::MAGIC_EGG;
			}
			else if (bt == "Crystal") {
				def.blockType = BlockTypes::CRYSTAL;
			}
			else if (bt == "Mailbox") {
				def.blockType = BlockTypes::MAILBOX;
			}
			else if (bt == "Bulletin_Board") {
				def.blockType = BlockTypes::BULLETIN_BOARD;
			}
			else if (bt == "Faction") {
				def.blockType = BlockTypes::FACTION;
			}
			else if (bt == "Component") {
				def.blockType = BlockTypes::COMPONENT;
			}
			else if (bt == "Weather_Machine") {
				def.blockType = BlockTypes::WEATHER;
			}
			else {
				//cout << "[!] Unknown property for ID: " << def.id << " which wants property " << bt << endl;
				def.blockType = BlockTypes::UNKNOWN;
			}
			def.breakHits = atoi(ex[7].c_str());
			def.growTime = atoi(ex[8].c_str());
			string cl = ex[9];
			if (def.blockType == BlockTypes::CLOTHING)
			{
				if (cl == "None") {
					def.clothType = ClothTypes::NONE;
				}
				else if (cl == "Hat") {
					def.clothType = ClothTypes::HAIR;
				}
				else if (cl == "Shirt") {
					def.clothType = ClothTypes::SHIRT;
				}
				else if (cl == "Pants") {
					def.clothType = ClothTypes::PANTS;
				}
				else if (cl == "Feet") {
					def.clothType = ClothTypes::FEET;
				}
				else if (cl == "Face") {
					def.clothType = ClothTypes::FACE;
				}
				else if (cl == "Hand") {
					def.clothType = ClothTypes::HAND;
				}
				else if (cl == "Back") {
					def.clothType = ClothTypes::BACK;
				}
				else if (cl == "Hair") {
					def.clothType = ClothTypes::MASK;
				}
				else if (cl == "Chest") {
					def.clothType = ClothTypes::NECKLACE;
				}
				else {
					def.clothType = ClothTypes::NONE;
				}
			}
			else
			{
				def.clothType = ClothTypes::NONE;
			}

			if (++current != def.id)
			{
				cout << "[!] Critical error! Unordered database at item " << std::to_string(current) << "/" << std::to_string(def.id) << "!" << endl;
			}
			maxItems = def.id;
			itemDefs.push_back(def);
		}
	}
	craftItemDescriptions();
}
BYTE* packBlockVisual(BlockVisual* dataStruct)
{
	BYTE* data = new BYTE[72];
	for (int i = 0; i < 72; i++)
	{
		data[i] = 0;
	}
	memcpy(data, &dataStruct->packetType, 4);
	memcpy(data + 8, &dataStruct->netID, 4);
	memcpy(data + 12, &dataStruct->characterState, 4);
	memcpy(data + 44, &dataStruct->punchX, 4);
	memcpy(data + 48, &dataStruct->punchY, 4);
	memcpy(data + 52, &dataStruct->charStat, 4);
	memcpy(data + 56, &dataStruct->blockid, 4);
	memcpy(data + 60, &dataStruct->visual, 4);
	memcpy(data + 64, &dataStruct->displayblock, 4);
	return data;
}
BYTE* packStuffVisual(TileExtra* dataStruct, int options, int gravity)
{
	BYTE* data = new BYTE[102];
	for (int i = 0; i < 102; i++)
	{
		data[i] = 0;
	}
	memcpy(data, &dataStruct->packetType, 4);
	memcpy(data + 8, &dataStruct->netID, 4);
	memcpy(data + 12, &dataStruct->characterState, 4);
	//memcpy(data + 40, &dataStruct->bpm, 4);
	memcpy(data + 44, &dataStruct->punchX, 4);
	memcpy(data + 48, &dataStruct->punchY, 4);
	memcpy(data + 52, &dataStruct->charStat, 4);
	memcpy(data + 56, &dataStruct->blockid, 2);
	memcpy(data + 58, &dataStruct->backgroundid, 2);
	memcpy(data + 60, &dataStruct->visual, 4);
	memcpy(data + 64, &dataStruct->displayblock, 4);
	memcpy(data + 68, &gravity, 4);
	memcpy(data + 70, &options, 4);
	return data;
}
void SendPacketRaw(int a1, void* packetData, size_t packetDataSize, void* a4, ENetPeer* peer, int packetFlag)
{
	ENetPacket* p;
	if (peer)
	{
		if (a1 == 4 && *((BYTE*)packetData + 12) & 8)
		{
			p = enet_packet_create(0, packetDataSize + *((DWORD*)packetData + 13) + 5, packetFlag);
			int four = 4;
			memcpy(p->data, &four, 4);
			memcpy((char*)p->data + 4, packetData, packetDataSize);
			memcpy((char*)p->data + packetDataSize + 4, a4, *((DWORD*)packetData + 13));
			enet_peer_send(peer, 0, p);
		}
		else
		{
			if (a1 == 192) {
				a1 = 4;
				p = enet_packet_create(0, packetDataSize + 5, packetFlag);
				memcpy(p->data, &a1, 4);
				memcpy((char*)p->data + 4, packetData, packetDataSize);
				enet_peer_send(peer, 0, p);
			}
			else {
				p = enet_packet_create(0, packetDataSize + 5, packetFlag);
				memcpy(p->data, &a1, 4);
				memcpy((char*)p->data + 4, packetData, packetDataSize);
				enet_peer_send(peer, 0, p);
			}
		}
	}
	delete packetData;
}
void SendPacketRaw2(int a1, void* packetData, size_t packetDataSize, void* a4, ENetPeer* peer, int packetFlag)
{
	ENetPacket* p;

	if (peer) // check if we have it setup
	{
		p = enet_packet_create(0, packetDataSize + 5, packetFlag);
		memcpy(p->data, &a1, 4);
		memcpy((char*)p->data + 4, packetData, packetDataSize);
		enet_peer_send(peer, 0, p);
	}
	delete (char*)packetData;
}
void updatetile(ENetPeer* peer, int netID, int x, int y)
{
	BlockVisual data3;
	data3.packetType = 0x5;
	data3.characterState = 8;
	data3.charStat = 8;
	data3.blockid = 2;
	data3.backgroundid = 2;
	data3.visual = 0x03000000; //replace this with active blockstate.(Im on phone cant remember rn) 
	data3.punchX = x;
	data3.punchY = y;
	data3.netID = netID;
	SendPacketRaw2(192, packBlockVisual(&data3), 100, 0, peer, ENET_PACKET_FLAG_RELIABLE);
}
void updateRotatedItem(ENetPeer* peer, int foreground, int x, int y, string text, int background)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8, wot = text.length(), lol = 0x00200000, wut = 5;
	int yeh = hmm + 3 + 1, idk = 15 + wot, lmao = -1, yey = 2; //idk = text_len + 15, wut = type(?), wot = text_len, yey = len of text_len
	int ok = 52 + idk;
	int kek = ok + 4, yup = ok - 8 - idk;
	int thonk = 4, magic = 56, wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, thonk);
	memcpy(data + yeh, &hmm, thonk); //read discord
	memcpy(data + yup, &x, 4);
	memcpy(data + yup + 4, &y, 4);
	memcpy(data + 4 + yup + 4, &idk, thonk);
	memcpy(data + magic, &foreground, yey);
	memcpy(data + magic + 2, &background, yey); // gai?
	memcpy(data + thonk + magic, &lol, thonk);
	memcpy(data + magic + 4 + thonk, &yey, 1);
	memcpy(data + wow, &wot, yey); //data + wow = text_len
	memcpy(data + yey + wow, text.c_str(), wot); //data + text_len_len + text_len_offs = text
	memcpy(data + ok, &lmao, thonk); //end ?
	memcpy(p->data, &thonk, thonk);
	memcpy((char*)p->data + thonk, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void updateEntrance(ENetPeer* peer, int foreground, int x, int y, bool open, int bg) {
	BYTE* data = new BYTE[69];// memset(data, 0, 69);
	for (int i = 0; i < 69; i++) data[i] = 0;
	int four = 4; int five = 5; int eight = 8;
	int huhed = (65536 * bg) + foreground; int loled = 128;

	memcpy(data, &four, 4);
	memcpy(data + 4, &five, 4);
	memcpy(data + 16, &eight, 4);
	memcpy(data + 48, &x, 4);
	memcpy(data + 52, &y, 4);
	memcpy(data + 56, &eight, 4);
	memcpy(data + 60, &foreground, 4);
	memcpy(data + 62, &bg, 4);

	if (open) {
		int state = 0;
		memcpy(data + 66, &loled, 4);
		memcpy(data + 68, &state, 4);
	}
	else {
		int state = 100;
		int yeetus = 25600;
		memcpy(data + 67, &yeetus, 5);
		memcpy(data + 68, &state, 4);
	}
	ENetPacket* p = enet_packet_create(data, 69, ENET_PACKET_FLAG_RELIABLE);

	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void updateSign(ENetPeer* peer, int foreground, int x, int y, string text, int background) // kazkas su mailbox
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8, wot = text.length(), lol = 0, wut = 5;
	int yeh = hmm + 3 + 1, idk = 15 + wot, lmao = -1, yey = 2; //idk = text_len + 15, wut = type(?), wot = text_len, yey = len of text_len
	int ok = 52 + idk;
	int kek = ok + 4, yup = ok - 8 - idk;
	int thonk = 4, magic = 56, wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, thonk);
	memcpy(data + yeh, &hmm, thonk); //read discord
	memcpy(data + yup, &x, 4);
	memcpy(data + yup + 4, &y, 4);
	memcpy(data + 4 + yup + 4, &idk, thonk);
	memcpy(data + magic, &foreground, yey);
	memcpy(data + magic + 2, &background, yey); //p100 fix by the one and only lapada
	memcpy(data + thonk + magic, &lol, thonk);
	memcpy(data + magic + 4 + thonk, &yey, 1);
	memcpy(data + wow, &wot, yey); //data + wow = text_len
	memcpy(data + yey + wow, text.c_str(), wot); //data + text_len_len + text_len_offs = text
	memcpy(data + ok, &lmao, thonk); //end ?
	memcpy(p->data, &thonk, thonk);
	memcpy((char*)p->data + thonk, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void playerconfig(ENetPeer* peer, int yspeed, int xspeed, int packettype)
{
	PlayerInfo* info = ((PlayerInfo*)(peer->data));
	int netID = info->netID;
	ENetPeer* currentPeer;
	int state = getState(info);
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			PlayerMoving data;
			float water = 125.0f;
			data.packetType = packettype;
			data.characterState = ((PlayerInfo*)(peer->data))->characterState; // animation
			data.x = 1000;
			if (((PlayerInfo*)(peer->data))->cloth_hand == 366) {
				data.y = -400; // - is hbow
			}
			else {
				data.y = 400;
			}
			data.punchX = 0;
			data.punchY = 0;
			data.XSpeed = xspeed;
			data.YSpeed = yspeed;
			data.netID = netID;
			data.plantingTree = state;
			BYTE* raw = packPlayerMoving(&data);
			int var = 0x818100; // placing and breking 0x808040 
			memcpy(raw + 1, &var, 3);
			memcpy(raw + 16, &water, 4);
			SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		}
	}
}
void updateGuild(ENetPeer* peer) {
	string guildname = PlayerDB::getProperName(((PlayerInfo*)(peer->data))->guild);
	if (guildname != "") {
		try {
			std::ifstream ifff("guilds/" + guildname + ".json");
			if (ifff.fail()) {
				ifff.close();
				cout << "Failed loading guilds/" + guildname + ".json! From " + ((PlayerInfo*)(peer->data))->displayName + "." << endl;
				((PlayerInfo*)(peer->data))->guild = "";
				updateGuild;
			}
			json j;
			ifff >> j;
			int gfbg, gffg;
			string gstatement, gleader;
			vector<string> gmembers;
			int glevel;
			gfbg = j["backgroundflag"];
			gffg = j["foregroundflag"];
			gstatement = j["GuildStatement"];
			gleader = j["Leader"];
			glevel = j["GuildLevel"];
			for (int i = 0; i < j["Member"].size(); i++) {
				gmembers.push_back(j["Member"][i]);
			}
			if (find(gmembers.begin(), gmembers.end(), ((PlayerInfo*)(peer->data))->rawName) == gmembers.end()) {
				((PlayerInfo*)(peer->data))->guild = "";
			}
			else {
				((PlayerInfo*)(peer->data))->guildBg = gfbg;
				((PlayerInfo*)(peer->data))->guildFg = gffg;
				((PlayerInfo*)(peer->data))->guildStatement = gstatement;
				((PlayerInfo*)(peer->data))->guildLeader = gleader;
				((PlayerInfo*)(peer->data))->guildMembers = gmembers;
				((PlayerInfo*)(peer->data))->guildlevel = glevel;
			}
			ifff.close();
		}
		catch (std::exception& e)
		{
			std::cerr << e.what() << std::endl;
		}
		catch (const std::out_of_range& e) {
			cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
		}
		catch (...) {
			cout << "reading file violation" << endl;
		}
	}
}
void RestartForUpdate()
{
	if (restartForUpdate)
	{
		ofstream ofrest("restartedmaintenance.txt");
		ofrest << 1;
		ofrest.close();
		GamePacket p;
		ENetPacket* packet;
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `415 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(10000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `45 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(1000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `44 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(1000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `43 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(1000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `42 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(1000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update in `41 `6seconds"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(1000);
		p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Global System Message : `6 Restarting server for update! See you later!"));
		packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete p.data;
		Sleep(2000);
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			enet_peer_disconnect_now(currentPeer, 0);
		}
		saveAllWorlds();
		restartForUpdate = false;
	}
}
void sendPuncheffectpeer(ENetPeer* peer, int punch) {
	PlayerInfo* info = ((PlayerInfo*)(peer->data));
	int netID = info->netID;
	int state = getState(info);
	PlayerMoving data;
	float water = 125.0f;
	data.packetType = 0x14;
	data.characterState = ((PlayerInfo*)(peer->data))->characterState; // animation
	data.x = 1000;
	//data.y = 100;
	if (((PlayerInfo*)(peer->data))->cloth_hand == 366) {
		data.y = -400; // - is hbow
	}
	else {
		data.y = 400;
	}
	data.punchX = -1;
	data.punchY = -1;
	data.XSpeed = 300;
	if (((PlayerInfo*)(peer->data))->cloth_back == 9472) {
		data.YSpeed = 600;
	}
	else {
		data.YSpeed = 1150;
	}
	data.netID = netID;
	data.plantingTree = state;
	BYTE* raw = packPlayerMoving(&data);
	int var = punch;
	memcpy(raw + 1, &var, 3);
	memcpy(raw + 16, &water, 4);
	SendPacketRaw(4, raw, 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	if (((PlayerInfo*)(peer->data))->isZombie == true)
	{
		playerconfig(peer, 1150, 130, 0x14);
	}
}
void sendPuncheffect(ENetPeer* peer, int punch) {
	PlayerInfo* info = ((PlayerInfo*)(peer->data));
	int netID = info->netID;
	ENetPeer* currentPeer;
	int state = getState(info);
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			if (peer != currentPeer) {
				PlayerMoving data;
				data.packetType = 0x14;
				data.characterState = ((PlayerInfo*)(peer->data))->characterState; // animation
				data.x = 1000;
				data.y = 100;
				data.x = 1000;
				data.y = 1000;
				data.punchX = 0;
				data.punchY = 0;
				data.XSpeed = 300;
				data.YSpeed = 600;
				data.netID = netID;
				data.plantingTree = state;
				BYTE* raw = packPlayerMoving(&data);
				int var = punch;
				memcpy(raw + 1, &var, 3);
				SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
			}
			if (((PlayerInfo*)(peer->data))->haveGrowId && ((PlayerInfo*)(peer->data))->isIn == true && ((PlayerInfo*)(peer->data))->currentWorld != "EXIT") {
				try {
					std::ifstream ifff("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json");
					PlayerInfo* p = ((PlayerInfo*)(peer->data));
					string username = PlayerDB::getProperName(p->rawName);
					if (ifff.fail()) {
						ifff.close();
					}
					if (ifff.is_open()) {
					}
					json j;
					ifff >> j;
					int effect = p->effect;
					j["effect"] = p->effect;
					std::ofstream o("players/" + ((PlayerInfo*)(peer->data))->rawName + ".json"); //save
					if (!o.is_open()) {
						cout << GetLastError() << endl;
						_getch();
					}
					o << j << std::endl;
				}
				catch (std::exception& e)
				{
					std::cerr << e.what() << std::endl;
				}
				catch (const std::out_of_range& e) {
					cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
				}
				catch (...) {
					cout << "reading file violation" << endl;
				}
			}
		}
	}
	if (((PlayerInfo*)(peer->data))->isZombie == true)
	{
		playerconfig(peer, 1150, 130, 0x14);
	}
}
void updatepeffect(ENetPeer* peer)
{
	if (((PlayerInfo*)(peer->data))->haveGrowId) {
		PlayerInfo* p = ((PlayerInfo*)(peer->data));
		std::ifstream ifff("players/" + PlayerDB::getProperName(p->rawName) + ".json");
		json j;
		ifff >> j;
		((PlayerInfo*)(peer->data))->effect = j["effect"];
		ifff.close();
		sendPuncheffectpeer(peer, ((PlayerInfo*)(peer->data))->effect);
	}
}
void changetile(ENetPeer* peer, int x, int y)
{
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			BlockVisual data3;
			data3.packetType = 0x5;
			data3.characterState = 8;
			data3.charStat = 8;
			data3.blockid = 260;
			data3.backgroundid = 260;
			data3.visual = 0x00400000;
			data3.punchX = x;
			data3.punchY = y;
			data3.netID = ((PlayerInfo*)(peer->data))->netID;
			SendPacketRaw2(192, packBlockVisual(&data3), 100, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		}
	}
}
int getPlayersCountInWorld(string name)
{
	int count = 0;
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (((PlayerInfo*)(currentPeer->data))->isinv == false)
		{
			if (((PlayerInfo*)(currentPeer->data))->currentWorld == name)
				count++;
		}
	}
	return count;
}
void sendPData(ENetPeer* peer, PlayerMoving* data)
{
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (peer != currentPeer)
		{
			if (isHere(peer, currentPeer))
			{
				data->netID = ((PlayerInfo*)(peer->data))->netID;
				SendPacketRaw(4, packPlayerMoving(data), 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
			}
		}
	}
}
void tradestatus(ENetPeer* peer, int netid, string s2, string offername, string box)
{
	try
	{
		GamePacket p2t = packetEnd(appendString(appendString(appendString(appendInt(appendString(createPacket(), "OnTradeStatus"), netid), s2), offername + "`o's offer."), box));
		ENetPacket* packet4 = enet_packet_create(p2t.data,
			p2t.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet4);
		delete p2t.data;
	}
	catch (const std::runtime_error &ex)
	{
		std::wcout << L"[ERROR]: Failure at tradestatus " << ex.what() << std::endl;
	}
}
void updateStuffWeather(ENetPeer* peer, int x, int y, int tile, int bg, int gravity, bool isInverted, bool isSpinning) {
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			//cout << "bruh" << endl;
			TileExtra data;
			data.packetType = 0x5;
			data.characterState = 8;
			data.punchX = x;
			data.punchY = y;
			data.charStat = 18; // 13
			data.blockid = 3832;
			data.backgroundid = bg; // 2946
								   //data.netID = ((PlayerInfo)(peer->data))->netID;
								   //dataxx.backgroundid = 65536;
			data.visual = 0; //0x00210000
										//world->items[x + (yworld->width)].displayblock = tile;
			int n = tile;
			string hex = "";
			{
				std::stringstream ss;
				ss << std::hex << n; // int decimal_value
				std::string res(ss.str());
				hex = res + "31";
			}
			int gravi = gravity;
			string hexg = "";
			{
				int temp = gravi;
				if (gravi < 0) temp = -gravi;
				std::stringstream ss;
				ss << std::hex << temp; // int decimal_value
				std::string res(ss.str());
				hexg = res + "00";
			}
			int xx = 0;
			std::stringstream ss;
			ss << std::hex << hex;
			if (!ss.fail()) {
				ss >> xx;
			}
			//cout << xx << endl;
			data.displayblock = xx;
			int xxs = 0;
			std::stringstream sss;
			sss << std::hex << hexg;
			if (!sss.fail()) {
				sss >> xxs;
			}
			if (gravi < 0) xxs = -xxs;
			//cout << to_string(xxs) << endl;
			if (gravi < 0) {
				SendPacketRaw2(192, packStuffVisual(&data, 0x03FFFFFF, xxs), 102, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
			}
			else
			{
				SendPacketRaw2(192, packStuffVisual(&data, 0x02000000, xxs), 102, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
			}
			GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), 29));
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(currentPeer, 0, packet2);
			delete p2.data;
		}
	}
}
void sendPlayerLeave(ENetPeer* peer, PlayerInfo* player)
{
	//((PlayerInfo*)(peer->data))->cpX = 3040;
	//((PlayerInfo*)(peer->data))->cpY = 736;
	((PlayerInfo*)(peer->data))->cpY = 0;
	((PlayerInfo*)(peer->data))->cpY = 0;
	((PlayerInfo*)(peer->data))->usedCP = false;
	ENetPeer* currentPeer;
	if (find(((PlayerInfo*)(peer->data))->lastworlds.begin(), ((PlayerInfo*)(peer->data))->lastworlds.end(), player->currentWorld) != ((PlayerInfo*)(peer->data))->lastworlds.end()) {
	}
	else {
		((PlayerInfo*)(peer->data))->lastworlds.push_back(player->currentWorld);
	}
	((PlayerInfo*)(peer->data))->ischeck = false;
	GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnRemove"), "netID|" + std::to_string(player->netID) + "\n")); // ((PlayerInfo*)(server->peers[i].data))->tankIDName
	GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`5<`w" + ((PlayerInfo*)(peer->data))->displayName + "`` `5left, `w" + std::to_string(getPlayersCountInWorld(player->currentWorld) - 1) + "`` `5others here>```w"));
	string name = ((PlayerInfo*)(peer->data))->displayName;
	string text = "action|play_sfx\nfile|audio/door_shut.wav\ndelayMS|0\n";
	BYTE* data = new BYTE[5 + text.length()];
	BYTE zero = 0;
	int type = 3;
	memcpy(data, &type, 4);
	memcpy(data + 4, text.c_str(), text.length());
	memcpy(data + 4 + text.length(), &zero, 1);
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (((PlayerInfo*)(currentPeer->data))->currentWorld == "EXIT")
			continue;
		if (((PlayerInfo*)(currentPeer->data))->isIn == false)
			continue;
		if (isHere(peer, currentPeer)) {
			{
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				{
					ENetPacket* packet = enet_packet_create(p.data,
						p.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet);
					ENetPacket* packet3 = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet3);
				}
				if (((PlayerInfo*)(peer->data))->isinv == false)
				{
					ENetPacket* packet2 = enet_packet_create(p2.data,
						p2.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet2);
					GamePacket p4 = packetEnd(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`5<`w" + ((PlayerInfo*)(peer->data))->displayName + "`` `5left, `w" + std::to_string(getPlayersCountInWorld(player->currentWorld) - 1) + "`` `5others here>```w"));
					ENetPacket* packet4 = enet_packet_create(p4.data,
						p4.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet4);
					delete p4.data;
				}
			}
			{
			}
		}
	}
	delete p.data;
	delete p2.data;
	delete[] data;
}
void sendRoulete(ENetPeer* peer)
{
	using namespace std::chrono;
	if (((PlayerInfo*)(peer->data))->lastSPIN + 1500 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
	{
		((PlayerInfo*)(peer->data))->lastSPIN = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
	}
	else {
		return;
	}
	ENetPeer* currentPeer;
	int val = rand() % 36;

	if (((PlayerInfo*)(peer->data))->isSpinSetByCreator == true)
	{
		val = ((PlayerInfo*)(peer->data))->spinSetByCreatorValue;
		((PlayerInfo*)(peer->data))->isSpinSetByCreator = false;
	}

	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer))
		{
			string name = ((PlayerInfo*)(peer->data))->displayName;

			if (val == 1 || val == 3 || val == 5 || val == 7 || val == 9 || val == 12 || val == 14 || val == 16 || val == 18 || val == 19 || val == 21 || val == 23 || val == 25 || val == 27 || val == 30 || val == 32 || val == 34 || val == 36) {
				GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`w[" + name + " `wspun the wheel and got `4" + std::to_string(val) + "`w!]"), 0));
				int respawnTimeout = 2000;
				int deathFlag = 0x19;
				memcpy(p2.data + 24, &respawnTimeout, 4);
				memcpy(p2.data + 56, &deathFlag, 4);
				ENetPacket* packet2 = enet_packet_create(p2.data,
					p2.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2);
				delete p2.data;
				GamePacket p2s = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`7[`w" + name + " `ospun the wheel and got `4" + std::to_string(val) + "`o!`7]"));
				memcpy(p2s.data + 24, &respawnTimeout, 4);
				memcpy(p2s.data + 56, &deathFlag, 4);
				ENetPacket* packet2s = enet_packet_create(p2s.data,
					p2s.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2s);
				delete p2s.data;

			}
			else if (val == 2 || val == 4 || val == 6 || val == 8 || val == 10 || val == 11 || val == 13 || val == 15 || val == 17 || val == 20 || val == 22 || val == 24 || val == 26 || val == 28 || val == 29 || val == 31 || val == 33 || val == 35) {

				GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`w[" + name + " `wspun the wheel and got `b" + std::to_string(val) + "`w!]"), 0));
				int respawnTimeout = 2000;
				int deathFlag = 0x19;
				memcpy(p2.data + 24, &respawnTimeout, 4);
				memcpy(p2.data + 56, &deathFlag, 4);
				ENetPacket* packet2 = enet_packet_create(p2.data,
					p2.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2);
				delete p2.data;
				GamePacket p2s = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`7[`w" + name + " `ospun the wheel and got `b" + std::to_string(val) + "`o!`7]"));
				memcpy(p2s.data + 24, &respawnTimeout, 4);
				memcpy(p2s.data + 56, &deathFlag, 4);
				ENetPacket* packet2s = enet_packet_create(p2s.data,
					p2s.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2s);
				delete p2s.data;

			}
			else if (val == 0 || val == 37) {
				GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`w[" + name + " `wspun the wheel and got `20`w!]"), 0));
				int respawnTimeout = 2000;
				int deathFlag = 0x19;
				memcpy(p2.data + 24, &respawnTimeout, 4);
				memcpy(p2.data + 56, &deathFlag, 4);
				ENetPacket* packet2 = enet_packet_create(p2.data,
					p2.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2);
				delete p2.data;
				GamePacket p2s = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`7[`w" + name + " `ospun the wheel and got `20`o!`7]"));
				memcpy(p2s.data + 24, &respawnTimeout, 4);
				memcpy(p2s.data + 56, &deathFlag, 4);
				ENetPacket* packet2s = enet_packet_create(p2s.data,
					p2s.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2s);
				delete p2s.data;
			}
		}
	}
}
void onSignBubble(ENetPeer* peer, int foreground, int x, int y, string text, int background)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8, wot = text.length(), lol = 0, wut = 5;
	int yeh = hmm + 3 + 1, idk = 15 + wot, lmao = -1, yey = 2; //idk = text_len + 15, wut = type(?), wot = text_len, yey = len of text_len
	int ok = 52 + idk;
	int kek = ok + 4, yup = ok - 8 - idk;
	int thonk = 4, magic = 56, wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, thonk);
	memcpy(data + yeh, &hmm, thonk); //read discord
	memcpy(data + yup, &x, 4);
	memcpy(data + yup + 4, &y, 4);
	memcpy(data + 4 + yup + 4, &idk, thonk);
	memcpy(data + magic, &foreground, yey);
	memcpy(data + magic + 2, &background, yey); //p100 fix by the one and only Secret3
	memcpy(data + thonk + magic, &lol, thonk);
	memcpy(data + magic + 4 + thonk, &yey, 1);
	memcpy(data + wow, &wot, yey); //data + wow = text_len
	memcpy(data + yey + wow, text.c_str(), wot); //data + text_len_len + text_len_offs = text
	memcpy(data + ok, &lmao, thonk); //end ?
	memcpy(p->data, &thonk, thonk);
	memcpy((char*)p->data + thonk, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void updateSeedText(ENetPeer* peer, int foreground, int x, int y, string text)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8;
	int text_len = text.length();
	int lol = 0;
	int wut = 5;
	int yeh = hmm + 3 + 1;
	int idk = 15 + text_len;
	int is_locked = 0;
	int bubble_type = 1;
	int ok = 52 + idk;
	int kek = ok + 4;
	int yup = ok - 8 - idk;
	int four = 4;
	int magic = 56;
	int wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, four); //4
	memcpy(data + yeh, &hmm, four); //8
	memcpy(data + yup, &x, 4); //12
	memcpy(data + yup + 4, &y, 4); //16
	memcpy(data + 4 + yup + 4, &idk, four); //20
	memcpy(data + magic, &foreground, 2); //22
	memcpy(data + four + magic, &lol, four); //26
	memcpy(data + magic + 4 + four, &bubble_type, 1); //27
	memcpy(data + wow, &text_len, 2); //data + wow = text_len, pos 29
	memcpy(data + 2 + wow, text.c_str(), text_len); //data + text_len_len + text_len_offs = text, pos 94
	memcpy(data + ok, &is_locked, four); //98
	memcpy(p->data, &four, four); //4
	memcpy((char*)p->data + four, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	enet_peer_send(peer, 0, p);
	delete data;
}
void updateDoor(ENetPeer* peer, int foreground, int x, int y, string text)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8;
	int text_len = text.length();
	int lol = 0;
	int wut = 5;
	int yeh = hmm + 3 + 1;
	int idk = 15 + text_len;
	int is_locked = 0;
	int bubble_type = 1;
	int ok = 52 + idk;
	int kek = ok + 4;
	int yup = ok - 8 - idk;
	int four = 4;
	int magic = 56;
	int wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, four); //4
	memcpy(data + yeh, &hmm, four); //8
	memcpy(data + yup, &x, 4); //12
	memcpy(data + yup + 4, &y, 4); //16
	memcpy(data + 4 + yup + 4, &idk, four); //20
	memcpy(data + magic, &foreground, 2); //22
	memcpy(data + four + magic, &lol, four); //26
	memcpy(data + magic + 4 + four, &bubble_type, 1); //27
	memcpy(data + wow, &text_len, 2); //data + wow = text_len, pos 29
	memcpy(data + 2 + wow, text.c_str(), text_len); //data + text_len_len + text_len_offs = text, pos 94
	memcpy(data + ok, &is_locked, four); //98
	memcpy(p->data, &four, four); //4
	memcpy((char*)p->data + four, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	enet_peer_send(peer, 0, p);
	delete data;
}

#include "packet_initialize/display_block.h"
void UpdateDisplayVisuals(ENetPeer* peer, int foreground, int x, int y, int background, int itemid, bool sendPacketToEveryone = true)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = 0x56;
	sign.y = 0x15;
	sign.punchX = 0x56;
	sign.punchY = 0x15;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = 0x0b82;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int plength = 73;
	BYTE* raw = new BYTE[plength];
	memset(raw, 0, plength);
	InitializePacketWithDisplayBlock(raw);
	memcpy(raw + 44, &x, sizeof(int));
	memcpy(raw + 48, &y, sizeof(int));
	memcpy(raw + 56, &foreground, sizeof(short));
	memcpy(raw + 58, &background, sizeof(short));
	memcpy(raw + 65, &itemid, sizeof(int));
	ENetPacket* p = enet_packet_create(0, plength + 4, ENET_PACKET_FLAG_RELIABLE);
	int four = 4;
	memcpy(p->data, &four, sizeof(int));
	memcpy((char*)p->data + 4, raw, plength);
	if (sendPacketToEveryone)
	{
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				enet_peer_send(currentPeer, 0, p);
			}
		}
		delete raw;
	}
	else
	{
		enet_peer_send(peer, 0, p);
		delete raw;
	}
}
void UpdateTreeVisuals(ENetPeer* peer, int foreground, int x, int y, int background, int fruitCount) {
	//int val = 1 + rand() % 4;
	string text = "tree";
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8;
	int text_len = 4;
	int zero = 0;
	int packetType = 5;
	int yeh = hmm + 3 + 1;
	int idk = 15 + text_len;
	int blockState = 0;
	int bubble_type = 4;
	int ok = 52 + idk;
	int packetSize = ok + 4;
	int yup = ok - 8 - idk;
	int four = 4;
	int magic = 56;
	int wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	short a = (short)fruitCount;
	int treedata = 0x0002000a;
	BYTE* data = new BYTE[packetSize];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	memset(data, 0, packetSize);
	memcpy(data, &packetType, sizeof(int));
	memcpy(data + yeh, &hmm, sizeof(int));
	memcpy(data + yup, &x, sizeof(int));
	memcpy(data + yup + 4, &y, sizeof(int));
	memcpy(data + 4 + yup + 4, &idk, sizeof(int));
	memcpy(data + magic, &foreground, sizeof(short));
	memcpy(data + four + magic, &background, sizeof(int));
	memcpy(data + magic + 4 + four, &bubble_type, sizeof(byte));
	memcpy(data + wow, &text_len, sizeof(short));
	memcpy(data + 2 + wow, &treedata, text_len);
	memcpy(data + ok, &blockState, sizeof(int));
	memcpy(p->data, &four, four);
	memcpy((char*)p->data + four, data, packetSize);
	enet_peer_send(peer, 0, p);
	delete data;
}
void UpdateMessageVisuals(ENetPeer* peer, int foreground, int x, int y, string text, int background, int bubbleType_ = 2, bool sendPacketToEveryone = true, int blockState = 0)
{
	if (text.size() > 100) return;
	// setting tile packet
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	// hopefully the magic :/
	int hmm = 8, textLen = text.size(), PacketType = 5;
	int yeh = hmm + 3 + 1, idk = 15 + textLen, endMarker = -1, sizeofshort = 2;
	int bubbleType = bubbleType_;
	int ok = 52 + idk;
	int kek = ok + 4, yup = ok - 8 - idk;
	int sizeofint = 4, magic = 56, wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	//MEMCPY DESTINATION					SOURCE			SIZE
	memcpy(data, &PacketType, sizeof(int));
	memcpy(data + yeh, &hmm, sizeof(int));
	memcpy(data + yup, &x, sizeof(int));
	memcpy(data + yup + 4, &y, sizeof(int));
	memcpy(data + 4 + yup + 4, &idk, sizeof(int));
	memcpy(data + magic, &foreground, sizeof(short));
	memcpy(data + magic + 2, &background, sizeof(short));
	memcpy(data + sizeofint + magic, &blockState, sizeof(int));
	memcpy(data + magic + 4 + sizeofint, &bubbleType, sizeof(byte));
	memcpy(data + wow, &textLen, sizeof(short));
	memcpy(data + sizeofshort + wow, text.c_str(), textLen);
	memcpy(data + ok, &endMarker, sizeof(int));
	memcpy(p->data, &sizeofint, sizeof(int));
	memcpy((char*)p->data + sizeofint, data, kek);
	if (sendPacketToEveryone)
	{
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				enet_peer_send(currentPeer, 0, p);
			}
		}
		delete data;
	}
	else
	{
		enet_peer_send(peer, 0, p);
		delete data;
	}
}
void UpdateUnlockedDoorVisuals(ENetPeer* peer, int foreground, int x, int y, int background, string text, bool sendPacketToEveryone = true, int visuals = 0)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = 0x56;
	sign.y = 0x15;
	sign.punchX = 0x56;
	sign.punchY = 0x15;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = 0x0b82;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	BYTE a = 0x00; // 0x08 for locked
	BYTE b = 0xeb; // 0x98 for locked
	uint32_t c = 0xfdfdfdfd;
	short textLen = (short)text.size();
	int plength = 73 + textLen;
	BYTE* raw = new BYTE[plength];
	memset(raw, 0, plength);
	InitializePacketWithUnlockedDoor(raw);
	memcpy(raw + 44, &x, sizeof(int));
	memcpy(raw + 48, &y, sizeof(int));
	memcpy(raw + 56, &foreground, sizeof(short));
	memcpy(raw + 58, &background, sizeof(short));
	memcpy(raw + 60, &visuals, sizeof(int));
	memcpy(raw + 65, &textLen, sizeof(short));
	memcpy(raw + 67, text.c_str(), textLen);
	memcpy(raw + 67 + textLen, &a, 1);
	memcpy(raw + 68 + textLen, &b, 1);
	memcpy(raw + 69 + textLen, &c, 4);
	ENetPacket* p = enet_packet_create(0, plength + 4, ENET_PACKET_FLAG_RELIABLE);
	int four = 4;
	memcpy(p->data, &four, sizeof(int));
	memcpy((char*)p->data + 4, raw, plength);
	if (sendPacketToEveryone)
	{
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				enet_peer_send(currentPeer, 0, p);
			}
		}
		delete raw;
	}
	else
	{
		enet_peer_send(peer, 0, p);
		delete raw;
	}
}
void sendblockstate(ENetPeer* peer, int x, int y, int state)
{
	BlockVisual data;
	data.packetType = 0x5;
	data.characterState = 8;
	data.charStat = 8;
	data.blockid = 0;
	data.backgroundid = 0;
	data.visual = state;
	data.punchX = x;
	data.punchY = y;
	data.netID = ((PlayerInfo*)(peer->data))->netID;
	SendPacketRaw2(192, packBlockVisual(&data), 100, 0, peer, ENET_PACKET_FLAG_RELIABLE);
}

void UpdateVisualsForBlock(ENetPeer* peer, bool forEveryone, int x, int y, WorldInfo* worldInfo, bool useLockId = true)
{
	if (!worldInfo) return;
	int i = y * worldInfo->width + x;
	int blockStateFlags = 0;
	if (worldInfo->items[i].flipped)
		blockStateFlags |= 0x00200000;
	if (worldInfo->items[i].water)
		blockStateFlags |= 0x04000000;
	if (worldInfo->items[i].glue)
		blockStateFlags |= 0x08000000;
	if (worldInfo->items[i].fire)
		blockStateFlags |= 0x10000000;
	if (worldInfo->items[i].red)
		blockStateFlags |= 0x20000000;
	if (worldInfo->items[i].green)
		blockStateFlags |= 0x40000000;
	if (worldInfo->items[i].blue)
		blockStateFlags |= 0x80000000;
	else if (getItemDef(worldInfo->items[i].foreground).blockType == BlockTypes::MAIN_DOOR)
	{
		UpdateUnlockedDoorVisuals(peer, worldInfo->items[i].foreground, x, y, worldInfo->items[i].background, "EXIT", forEveryone, blockStateFlags);
	}
	else if (worldInfo->items[i].foreground == 2946) // display block
	{
		UpdateDisplayVisuals(peer, worldInfo->items[i].foreground, x, y, worldInfo->items[i].background, worldInfo->items[i].intdata);
	}
	else if (worldInfo->items[i].foreground % 2 == 1)
	{
		UpdateTreeVisuals(peer, worldInfo->items[i].foreground, x, y, worldInfo->items[i].background, 3);
	}
	else if (blockStateFlags != 0)
	{
		UpdateMessageVisuals(peer, worldInfo->items[i].foreground, x, y, "", worldInfo->items[i].background, 0, forEveryone, blockStateFlags);
	}
}
void doorlocked(ENetPeer* peer, int foreground, int x, int y, string text)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8;
	int text_len = text.length();
	int lol = 0;
	int wut = 5;
	int yeh = hmm + 3 + 1;
	int idk = 15 + text_len;
	int is_locked = -1;
	int bubble_type = 1;
	int ok = 52 + idk;
	int kek = ok + 4;
	int yup = ok - 8 - idk;
	int four = 4;
	int magic = 56;
	int wew = ok + 5 + 4;
	int wow = magic + 4 + 5;
	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, four); //4
	memcpy(data + yeh, &hmm, four); //8
	memcpy(data + yup, &x, 4); //12
	memcpy(data + yup + 4, &y, 4); //16
	memcpy(data + 4 + yup + 4, &idk, four); //20
	memcpy(data + magic, &foreground, 2); //22
	memcpy(data + four + magic, &lol, four); //26
	memcpy(data + magic + 4 + four, &bubble_type, 1); //27
	memcpy(data + wow, &text_len, 2); //data + wow = text_len, pos 29
	memcpy(data + 2 + wow, text.c_str(), text_len); //data + text_len_len + text_len_offs = text, pos 94
	memcpy(data + ok, &is_locked, four); //98
	memcpy(p->data, &four, four); //4
	memcpy((char*)p->data + four, data, kek); //kek = data_len
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void SendDropSingle(ENetPeer* peer, int netID, int x, int y, int item, int count, BYTE specialEffect)
{
	if (item >= maxItems) return;
	if (item < 0) return;
	PlayerMoving data;
	data.packetType = 14;
	data.x = x;
	data.y = y;
	data.netID = netID;
	data.plantingTree = item;
	float val = count; // item count
	BYTE val2 = specialEffect;
	BYTE* raw = packPlayerMoving(&data);
	memcpy(raw + 16, &val, 4);
	memcpy(raw + 1, &val2, 1);
	SendPacketRaw(4, raw, 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
}
void updateVendMsg(ENetPeer* peer, int foreground, int x, int y, string text)
{
	PlayerMoving sign;
	sign.packetType = 0x3;
	sign.characterState = 0x0;
	sign.x = x;
	sign.y = y;
	sign.punchX = x;
	sign.punchY = y;
	sign.XSpeed = 0;
	sign.YSpeed = 0;
	sign.netID = -1;
	sign.plantingTree = foreground;
	SendPacketRaw(4, packPlayerMoving(&sign), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
	int hmm = 8;
	int text_len = text.length();
	int lol = 0;
	int wut = 5;
	int yeh = hmm + 3 + 1;
	int idk = 15 + text_len;
	int is_locked = 0;
	int bubble_type = 21;
	int ok = 52 + idk;
	int kek = ok + 4;
	int yup = ok - 8 - idk;
	int four = 4;
	int magic = 56;
	int wew = ok + 5 + 4;
	int wow = magic + 4 + 5;

	BYTE* data = new BYTE[kek];
	ENetPacket* p = enet_packet_create(0, wew, ENET_PACKET_FLAG_RELIABLE);
	for (int i = 0; i < kek; i++) data[i] = 0;
	memcpy(data, &wut, four);
	memcpy(data + yeh, &hmm, four);
	memcpy(data + yup, &x, 4);
	memcpy(data + yup + 4, &y, 4);
	memcpy(data + 4 + yup + 4, &idk, four);
	memcpy(data + magic, &foreground, 2);
	memcpy(data + four + magic, &lol, four);
	memcpy(data + magic + 4 + four, &bubble_type, 1);
	memcpy(data + wow, &text_len, 2);
	memcpy(data + 2 + wow, text.c_str(), text_len);
	memcpy(data + ok, &is_locked, four);
	memcpy(p->data, &four, four);
	memcpy((char*)p->data + four, data, kek);
	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			enet_peer_send(currentPeer, 0, p);
		}
	}
	delete data;
}
void UpdateBlockState(ENetPeer* peer, int x, int y, bool forEveryone, WorldInfo* worldInfo) {
	if (!worldInfo) return;
	int i = y * worldInfo->width + x;
	int blockStateFlags = 0;
	if (worldInfo->items[i].water)
		blockStateFlags |= 0x04000000;
	if (worldInfo->items[i].glue)
		blockStateFlags |= 0x08000000;
	if (worldInfo->items[i].fire)
		blockStateFlags |= 0x10000000;
	if (worldInfo->items[i].red)
		blockStateFlags |= 0x20000000;
	if (worldInfo->items[i].green)
		blockStateFlags |= 0x40000000;
	if (worldInfo->items[i].blue)
		blockStateFlags |= 0x80000000;
}
void restoreplayernick(ENetPeer* peer)
{
	if (((PlayerInfo*)(peer->data))->isNicked == false)
	{
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr." + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`2" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`#@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`#@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`#@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`#@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`q@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`q@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`q@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`q@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`@@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`@@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`@@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`@@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`4@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`4@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`4@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`4@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId) {
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else if (((PlayerInfo*)(peer->data))->isCreator == true) {
						((PlayerInfo*)(peer->data))->displayName = "`c@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`9@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
					//if (((PlayerInfo*)(peer->data))->rawName == "btw") {
						//((PlayerInfo*)(peer->data))->displayName = "`w[`#MOMO`w] " + ((PlayerInfo*)(peer->data))->tankIDName;
					//}
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						if (((PlayerInfo*)(peer->data))->isCreator == true) {
							((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
						}
						else
						{
							((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
						}
					}
					else if (((PlayerInfo*)(peer->data))->isCreator == true) {
						((PlayerInfo*)(peer->data))->displayName = "`c@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`9@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
		else
		{
			if (((PlayerInfo*)(peer->data))->rawName == getPlyersWorld(peer)->owner)
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else if (((PlayerInfo*)(peer->data))->isCreator == true) {
						((PlayerInfo*)(peer->data))->displayName = "`c@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`9@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
					if (((PlayerInfo*)(peer->data))->cloth_back == 8552) {
						if (((PlayerInfo*)(peer->data))->isCreator == true) {
							((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
						}
						else
						{
							((PlayerInfo*)(peer->data))->displayName = "`4@Dr. " + ((PlayerInfo*)(peer->data))->tankIDName;
						}
					}
					else if (((PlayerInfo*)(peer->data))->isCreator == true) {
						((PlayerInfo*)(peer->data))->displayName = "`c@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
					else {
						((PlayerInfo*)(peer->data))->displayName = "`9@" + ((PlayerInfo*)(peer->data))->tankIDName;
					}
				}
			}
		}
	}
}
void updateplayer(ENetPeer* peer) {
	int item = ((PlayerInfo*)(peer->data))->cloth_back;
	if (item == 8552)
	{
		((PlayerInfo*)(peer->data))->isDr = true;
		((PlayerInfo*)(peer->data))->canDoubleJump = true;
	}
	else if (item == 1784 || item == 1674 || item == 9434 || item == 10012 || item == 9466 || item == 10016 || item == 5136 || item == 9760 || item == 9478 || item == 9506 || item == 9476 || item == 1970 || item == 8286 || item == 156 || item == 9434 || item == 8552 || item == 362 || item == 678 || item == 736 || item == 7734 || item == 7762 || item == 818 || item == 1206 || item == 1460 || item == 1550 || item == 1574 || item == 1668 || item == 1672 || item == 1824 || item == 1936 || item == 1938 || item == 2254 || item == 2256 || item == 2258 || item == 2260 || item == 2262 || item == 2264 || item == 2390 || item == 2392 || item == 3120 || item == 3308 || item == 3512 || item == 4534 || item == 4986 || item == 5754 || item == 6144 || item == 6334 || item == 6694 || item == 6818 || item == 6842 || item == 1934 || item == 3134 || item == 6004 || item == 1780 || item == 2158 || item == 2160 || item == 2162 || item == 2164 || item == 2166 || item == 2168 || item == 2438 || item == 2538 || item == 2778 || item == 3858 || item == 350 || item == 998 || item == 1738 || item == 2642 || item == 2982 || item == 3104 || item == 3144 || item == 5738 || item == 3112 || item == 2722 || item == 3114 || item == 4970 || item == 4972 || item == 5020 || item == 6284 || item == 4184 || item == 4628 || item == 5322 || item == 4112 || item == 4114 || item == 3442 || item == 9466 || item == 5136 || item == 9416 || item == 9356)
	{
		((PlayerInfo*)(peer->data))->canDoubleJump = true;
	}
	updatepeffect(peer);
}
void sendState(ENetPeer* peer) {
	if (((PlayerInfo*)(peer->data))->currentWorld == "EXIT")
	{
		return;
	}
	PlayerInfo* info = ((PlayerInfo*)(peer->data));
	int netID = info->netID;
	ENetPeer* currentPeer;
	int state = getState(info);
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			PlayerMoving data;
			float water = 125.0f;
			data.packetType = 0x14;
			data.characterState = ((PlayerInfo*)(peer->data))->characterState; // animation
			data.x = 1000;
			if (((PlayerInfo*)(peer->data))->cloth_hand == 366) {
				data.y = -400; // - is hbow
			}
			else {
				data.y = 400;
			}
			data.punchX = 0;
			data.punchY = 0;
			data.XSpeed = 300;
			if (((PlayerInfo*)(peer->data))->cloth_back == 9472) {
				data.YSpeed = 600;
			}
			else {
				data.YSpeed = 1150;
			}
			data.netID = netID;
			data.plantingTree = state;
			BYTE* raw = packPlayerMoving(&data);
			int var = 0x818100;
			memcpy(raw + 1, &var, 3);
			memcpy(raw + 16, &water, 4);
			SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		}
	}
	restoreplayernick(peer);

	Player::OnNameChanged(peer, ((PlayerInfo*)(peer->data))->netID, ((PlayerInfo*)(peer->data))->displayName);

	if (((PlayerInfo*)(peer->data))->cloth_back == 8552)
	{
		GamePacket p2 = packetEnd(appendIntx(appendIntx(appendIntx(appendIntx(appendString(createPacket(), "OnGuildDataChanged"), 1), 2), 7068), 0));
		memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
		ENetPacket* packet3 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
			{
				enet_peer_send(currentPeer, 0, packet3);
			}
		}
		delete p2.data;
	}
	if (((PlayerInfo*)(peer->data))->skill == "Farmer")
	{
		GamePacket p2 = packetEnd(appendIntx(appendIntx(appendIntx(appendIntx(appendString(createPacket(), "OnGuildDataChanged"), 1), 2), 7064), 0));
		memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
		ENetPacket* packet3 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
			{
				enet_peer_send(currentPeer, 0, packet3);
			}
		}
		delete p2.data;
	}
	if (((PlayerInfo*)(peer->data))->skill == "Miner")
	{
		GamePacket p2 = packetEnd(appendIntx(appendIntx(appendIntx(appendIntx(appendString(createPacket(), "OnGuildDataChanged"), 1), 2), 98), 0));
		memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
		ENetPacket* packet3 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
			{
				enet_peer_send(currentPeer, 0, packet3);
			}
		}
		delete p2.data;
	}
	updateplayer(peer);
	if (((PlayerInfo*)(peer->data))->isZombie == true)
	{
		playerconfig(peer, 1150, 130, 0x14);
	}
}
void SendDisplayBlock(ENetPeer* peer, int16_t fg, int16_t bg, int32_t x, int32_t y, int32_t item) {

	int8_t* ExtendedData = new int8_t[13];
	int32_t extendedLen = 13;

	PlayerMoving pmov;
	pmov.packetType = 0x5;
	pmov.characterState = 0x8;
	pmov.punchX = x;
	pmov.punchY = y;

	int8_t* raw = new int8_t[69];

	memcpy(raw, packPlayerMoving(&pmov), 56);
	*(int32_t*)(raw + 52) = extendedLen;

	*(int16_t*)(ExtendedData + 0) = fg;
	*(int16_t*)(ExtendedData + 2) = bg;
	*(int32_t*)(ExtendedData + 4) = 0x0010000;
	ExtendedData[8] = 0x17;
	*(int32_t*)(ExtendedData + 9) = item;

	memcpy(raw + 56, ExtendedData, extendedLen);

	ENetPacket* p = enet_packet_create(0, 74, 1);
	*(int32_t*)(p->data) = 4;
	memcpy(p->data + 4, raw, 69);
	enet_peer_send(peer, 0, p);

}
void sendWorld(ENetPeer* peer, WorldInfo* worldInfo)
{
		int zero = 0;
		((PlayerInfo*)(peer->data))->droppeditemcount = 0;
#ifdef TOTAL_LOG
		cout << "[!] Entering a world..." << endl;
#endif
		if (serverIsFrozen == false)
		{
			((PlayerInfo*)(peer->data))->joinClothesUpdated = false;
			string asdf = "0400000004A7379237BB2509E8E0EC04F8720B050000000000000000FBBB0000010000007D920100FDFDFDFD04000000040000000000000000000000070000000000"; // 0400000004A7379237BB2509E8E0EC04F8720B050000000000000000FBBB0000010000007D920100FDFDFDFD04000000040000000000000000000000080000000000000000000000000000000000000000000000000000000000000048133A0500000000BEBB0000070000000000
			string worldName = worldInfo->name;
			int xSize = worldInfo->width;
			int ySize = worldInfo->height;
			int square = xSize * ySize;
			__int16 nameLen = (__int16)worldName.length();
			int payloadLen = asdf.length() / 2;
			int dataLen = payloadLen + 2 + nameLen + 12 + (square * 8) + 4 + 100;
			int offsetData = dataLen - 100;
			int allocMem = payloadLen + 2 + nameLen + 12 + (square * 8) + 4 + 16000 + 100 + (worldInfo->droppedCount * 20);
			BYTE* data = new BYTE[allocMem];
			memset(data, 0, allocMem);
			for (int i = 0; i < asdf.length(); i += 2)
			{
				char x = ch2n(asdf[i]);
				x = x << 4;
				x += ch2n(asdf[i + 1]);
				memcpy(data + (i / 2), &x, 1);
			}
			__int16 item = 0;
			int smth = 0;
			for (int i = 0; i < square * 8; i += 4) memcpy(data + payloadLen + i + 14 + nameLen, &zero, 4);
			for (int i = 0; i < square * 8; i += 8) memcpy(data + payloadLen + i + 14 + nameLen, &item, 2);
			memcpy(data + payloadLen, &nameLen, 2);
			memcpy(data + payloadLen + 2, worldName.c_str(), nameLen);
			memcpy(data + payloadLen + 2 + nameLen, &xSize, 4);
			memcpy(data + payloadLen + 6 + nameLen, &ySize, 4);
			memcpy(data + payloadLen + 10 + nameLen, &square, 4);
			BYTE* blockPtr = data + payloadLen + 14 + nameLen;
			int sizeofblockstruct = 8;
			for (int i = 0; i < square; i++) {
				int tile = worldInfo->items[i].foreground;
				sizeofblockstruct = 8;

				if (getItemDef(tile).blockType == BlockTypes::SIGN || tile == 1420 || tile == 6124) {
					int type = 0x00010000;
					memcpy(blockPtr, &worldInfo->items[i].foreground, 2);
					memcpy(blockPtr + 4, &type, 4);
					BYTE btype = 2;
					memcpy(blockPtr + 8, &btype, 1);
					string signText = worldInfo->items[i].text;
					const char* signTextChars = signText.c_str();
					short length = (short)signText.size();
					memcpy(blockPtr + 9, &length, 2);
					memcpy(blockPtr + 11, signTextChars, length);
					int minus1 = -1;
					memcpy(blockPtr + 11 + length, &minus1, 4);
					sizeofblockstruct += 3 + length + 4;
					dataLen += 3 + length + 4; // it's already 8.
				}
				else if ((worldInfo->items[i].foreground == 0) || (worldInfo->items[i].foreground == 2) || (worldInfo->items[i].foreground == 8) || (worldInfo->items[i].foreground == 100) || (worldInfo->items[i].foreground == 4))
				{
					memcpy(blockPtr, &worldInfo->items[i].foreground, 2);
					int type = 0x00000000;
					// type 1 = locked
					if (worldInfo->items[i].water)
						type |= 0x04000000;
					if (worldInfo->items[i].glue)
						type |= 0x08000000;
					if (worldInfo->items[i].fire)
						type |= 0x10000000;
					if (worldInfo->items[i].red)
						type |= 0x20000000;
					if (worldInfo->items[i].green)
						type |= 0x40000000;
					if (worldInfo->items[i].blue)
						type |= 0x80000000;
					memcpy(blockPtr + 4, &type, 4);
				}
				else
				{
					memcpy(blockPtr, &zero, 2);
				}
				memcpy(blockPtr + 2, &worldInfo->items[i].background, 2);
				blockPtr += sizeofblockstruct;
			}
			offsetData = dataLen - 100;
			string asdf2 = "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
			BYTE* data2 = new BYTE[101];
			memcpy(data2 + 0, &zero, 4);
			for (int i = 0; i < asdf2.length(); i += 2)
			{
				char x = ch2n(asdf2[i]);
				x = x << 4;
				x += ch2n(asdf2[i + 1]);
				memcpy(data2 + (i / 2), &x, 1);
			}
			int weather = worldInfo->weather;
			memcpy(data2 + 4, &weather, 4);
			memcpy(data + offsetData, data2, 100);
			memcpy(data + dataLen - 4, &smth, 4);
			ENetPacket* packet2 = enet_packet_create(data,
				dataLen,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			for (int i = 0; i < square; i++) {
				ItemDefinition pro;
				pro = getItemDef(worldInfo->items[i].foreground);
				if ((worldInfo->items[i].foreground == 0) || (getItemDef(worldInfo->items[i].foreground).blockType) == BlockTypes::SIGN || worldInfo->items[i].foreground == 1420 || worldInfo->items[i].foreground == 6214 || (worldInfo->items[i].foreground == 3832) || (worldInfo->items[i].foreground == 4) || (worldInfo->items[i].foreground == 2) || (worldInfo->items[i].foreground == 8) || (worldInfo->items[i].foreground == 100))
					;
				else if (worldInfo->items[i].foreground == 6) updateDoor(peer, worldInfo->items[i].foreground, i % worldInfo->width, i / worldInfo->width, "`wLEAVE``");
				else
				{
					PlayerMoving data;
					data.packetType = 0x3;
					data.characterState = 0x0;
					data.x = i % worldInfo->width;
					data.y = i / worldInfo->height;
					data.punchX = i % worldInfo->width;
					data.punchY = i / worldInfo->width;
					data.XSpeed = 0;
					data.YSpeed = 0;
					data.netID = -1;
					data.plantingTree = worldInfo->items[i].foreground;
					SendPacketRaw(4, packPlayerMoving(&data), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
					int x = i % xSize, y = i / xSize;
					UpdateBlockState(peer, x, y, true, worldInfo);
				}
			}
			int idx = 0;
			for (int i = 0; i < worldInfo->droppedItemUid; i++)
			{
				bool found = false;
				for (int j = 0; j < worldInfo->droppedItems.size(); j++)
				{
					if (worldInfo->droppedItems.at(j).uid == i)
					{
						SendDropSingle(peer, -1, worldInfo->droppedItems.at(j).x, worldInfo->droppedItems.at(j).y, worldInfo->droppedItems.at(j).id, worldInfo->droppedItems.at(j).count, 0);
						found = true;
						break;
					}
				}
				if (!found) SendDropSingle(peer, -1, -1000, -1000, 0, 1, 0);
			}
			((PlayerInfo*)(peer->data))->currentWorld = worldInfo->name;
			for (int i = 0; i < xSize; i++) {
				for (int j = 0; j < ySize; j++) {
					int squaresign = i + (j * 100);
					if (worldInfo->items[squaresign].foreground == 2946)
					{
						bool displayexist = std::experimental::filesystem::exists("display/" + worldInfo->name + "X" + std::to_string(squaresign) + ".txt");
						if (displayexist) {
							int x = squaresign % worldInfo->width;
							int y = squaresign / worldInfo->width;
							WorldInfo* world = getPlyersWorld(peer);
							int realid;
							string currentworld = worldInfo->name + "X" + std::to_string(squaresign);
							ifstream getdisplay("display/" + currentworld + ".txt");
							getdisplay >> realid;
							getdisplay.close();
							SendDisplayBlock(peer, world->items[x + (y * world->width)].foreground, world->items[x + (y * world->width)].background, x, y, realid);
						}
					}
					if (getItemDef(worldInfo->items[squaresign].foreground).blockType == BlockTypes::SIGN)
					{
						bool cmdhadi = std::experimental::filesystem::exists("signs/" + worldInfo->name + "X" + std::to_string(squaresign) + ".txt");
						if (cmdhadi) {
							int x123 = squaresign % worldInfo->width;
							int y123 = squaresign / worldInfo->width;
							WorldInfo* world = getPlyersWorld(peer);
							ifstream ifs("signs/" + worldInfo->name + "X" + std::to_string(squaresign) + ".txt");
							string content = "";
							getline(ifs, content);
							onSignBubble(peer, world->items[x123 + (y123 * world->width)].foreground, x123, y123, content, world->items[x123 + (y123 * world->width)].background);
						}
					}
				}
			}
			int otherpeople = 0;
			int count = 0;
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				count++;
				if (isHere(peer, currentPeer))
					otherpeople++;
			}

			int otherpeoples = otherpeople - 1;
			delete[] data;
			delete[] data2;
			Player::PlayAudio(peer, "audio/door_open.wav", 0);
			std::ifstream ifs("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
			std::string content((std::istreambuf_iterator<char>(ifs)),
				(std::istreambuf_iterator<char>()));
			int gembux = std::atoi(content.c_str());
			Player::OnSetBux(peer, gembux, 1);

			if (((PlayerInfo*)(peer->data))->haveGrowId) {
				PlayerInfo* p = ((PlayerInfo*)(peer->data));
				try {
					std::ifstream ifff("players/" + PlayerDB::getProperName(p->rawName) + ".json");
					json j;
					ifff >> j;
					p->currentWorld = worldInfo->name;
					int bac, han, fac, hai, fee, pan, nec, shi, mas, anc, ban, lgk, lgw, lgb, lgd, lkw, cwd, rfs, cdg, join, level, xp, adminlevel, rubble, rubblexp, amber, amberxp, opal, opalxp, gold, goldxp, sapphire, sapphirexp, diamond, diamondxp, emerald, emeraldxp;
					bool joinguild;
					bac = j["ClothBack"];
					han = j["ClothHand"];
					fac = j["ClothFace"];
					hai = j["ClothHair"];
					fee = j["ClothFeet"];
					pan = j["ClothPants"];
					nec = j["ClothNeck"];
					shi = j["ClothShirt"];
					mas = j["ClothMask"];
					anc = j["ClothAnces"];
					ban = j["isBanned"];
					adminlevel = j["adminLevel"];
					vector <string>frns;
					if (j.count("worldsowned") == 1) {
						for (int i = 0; i < j["worldsowned"].size(); i++) {
							frns.push_back(j["worldsowned"][i]);
						}
					}
					else {
						frns = {};
					}
					level = j["level"];
					xp = j["xp"];
					string guild;
					if (j.count("guild") == 1) {
						guild = j["guild"];
					}
					else {
						guild = "";
					}
					if (j.count("joinguild") == 1) {
						join = j["joinguild"];
					}
					else {
						join = false;
					}
					if (j.count("rubble") == 1) {
						rubble = j["rubble"];
					}
					else {
						rubble = 0;
					}
					if (j.count("rubblexp") == 1) {
						rubblexp = j["rubblexp"];
					}
					else {
						rubblexp = 0;
					}
					// Mining update starts here
					if (j.count("amber") == 1) {
						amber = j["amber"];
					}
					else {
						amber = 0;
					}
					if (j.count("amberxp") == 1) {
						amberxp = j["amberxp"];
					}
					else {
						amberxp = 0;
					}
					if (j.count("opal") == 1) {
						opal = j["opal"];
					}
					else {
						opal = 0;
					}
					if (j.count("opalxp") == 1) {
						opalxp = j["opalxp"];
					}
					else {
						opalxp = 0;
					}
					if (j.count("gold") == 1) {
						gold = j["gold"];
					}
					else {
						gold = 0;
					}
					if (j.count("goldxp") == 1) {
						goldxp = j["goldxp"];
					}
					else {
						goldxp = 0;
					}
					if (j.count("sapphire") == 1) {
						sapphire = j["sapphire"];
					}
					else {
						sapphire = 0;
					}
					if (j.count("sapphirexp") == 1) {
						sapphirexp = j["sapphirexp"];
					}
					else {
						sapphirexp = 0;
					}
					if (j.count("diamond") == 1) {
						diamond = j["diamond"];
					}
					else {
						diamond = 0;
					}
					if (j.count("diamondxp") == 1) {
						diamondxp = j["diamondxp"];
					}
					else {
						diamondxp = 0;
					}
					if (j.count("emerald") == 1) {
						emerald = j["emerald"];
					}
					else {
						emerald = 0;
					}
					if (j.count("emeraldxp") == 1) {
						emeraldxp = j["emeraldxp"];
					}
					else {
						emeraldxp = 0;
					}
					// Mining update ends here
					p->worldsowned = frns;
					p->adminLevel = adminlevel;
					p->cloth_back = bac;
					p->cloth_hand = han;
					p->cloth_face = fac;
					p->cloth_hair = hai;
					p->cloth_feet = fee;
					p->cloth_pants = pan;
					p->cloth_necklace = nec;
					p->cloth_shirt = shi;
					p->cloth_mask = mas;
					p->guild = guild;
					p->joinguild = join;
					p->level = level;
					p->xp = xp;
					p->rubble = rubble;
					p->rubblexp = rubblexp;
					// Mining update starts here
					p->amber = amber;
					p->amberxp = amberxp;
					p->opal = opal;
					p->opalxp = opalxp;
					p->gold = gold;
					p->goldxp = goldxp;
					p->sapphire = sapphire;
					p->sapphirexp = sapphirexp;
					p->diamond = diamond;
					p->diamondxp = diamondxp;
					p->emerald = emerald;
					p->emeraldxp = emeraldxp;
					// Mining update ends here
					//p->friendinfo = frns;
					//p->cloth_ances = anc;
					updateAllClothes(peer);
					ifff.close();
				}
				catch (std::exception& e)
				{
					std::cerr << e.what() << std::endl;
				}
				catch (const std::out_of_range& e) {
					cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
				}
				catch (...) {
					cout << "reading file violation" << endl;
				}
				PlayerInventory inventory;
				InventoryItem item;
				item.itemCount = 1;
				item.itemID = 18;
				inventory.items.push_back(item);
				item.itemCount = 1;
				item.itemID = 32;
				inventory.items.push_back(item);
				sendInventory(peer, inventory);
				string guildname = PlayerDB::getProperName(((PlayerInfo*)(peer->data))->guild);
				if (guildname != "") {
					try {
						std::ifstream ifff("guilds/" + guildname + ".json");
						if (ifff.fail()) {
							ifff.close();
							cout << "Failed loading guilds/" + guildname + ".json! From " + ((PlayerInfo*)(peer->data))->displayName + "." << endl;
							((PlayerInfo*)(peer->data))->guild = "";
						}
						json j;
						ifff >> j;
						int gfbg, gffg;
						string gstatement, gleader;
						vector<string> gmembers;
						gfbg = j["backgroundflag"];
						gffg = j["foregroundflag"];
						gstatement = j["GuildStatement"];
						gleader = j["Leader"];
						for (int i = 0; i < j["Member"].size(); i++) {
							gmembers.push_back(j["Member"][i]);
						}
						((PlayerInfo*)(peer->data))->guildBg = gfbg;
						((PlayerInfo*)(peer->data))->guildFg = gffg;
						((PlayerInfo*)(peer->data))->guildStatement = gstatement;
						((PlayerInfo*)(peer->data))->guildLeader = gleader;
						((PlayerInfo*)(peer->data))->guildMembers = gmembers;
						ifff.close();
					}
					catch (std::exception& e)
					{
						std::cerr << e.what() << std::endl;
					}
					catch (const std::out_of_range& e) {
						cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
					}
					catch (...) {
						cout << "reading file violation" << endl;
					}
				}
				if (!std::experimental::filesystem::exists("gemstorage/" + PlayerDB::getProperName(p->rawName) + ".txt"))
				{
					ofstream create("gemstorage/" + PlayerDB::getProperName(p->rawName) + ".txt");
					create << 0;
					create.close();
				}
				ifstream fdss("gemstorage/" + PlayerDB::getProperName(p->rawName) + ".txt");
				fdss >> p->plantgems;
				fdss.close();
				if (!std::experimental::filesystem::exists("fragments/" + PlayerDB::getProperName(p->rawName) + ".txt"))
				{
					ofstream create("fragments/" + PlayerDB::getProperName(p->rawName) + ".txt");
					create << 0;
					create << 0;
					create << 0;
					create << 0;
					create.close();
				}
				ifstream fd("fragments/" + PlayerDB::getProperName(p->rawName) + ".txt");
				fd >> p->fEarth;
				fd >> p->fDark;
				fd >> p->fFire;
				fd >> p->fWater;
				fd.close();
				if (p->isDuctaped) sendClothes(peer);
			}
			if (getPlyersWorld(peer)->allowMod != true)
			{
				((PlayerInfo*)(peer->data))->canWalkInBlocks = false;
				((PlayerInfo*)(peer->data))->skinColor = 0x8295C3FF;
				sendState(peer);
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->isZombie == false)
				{
					Player::OnConsoleMessage(peer, "`2Owner `ohas `2enabled `5Mod-Noclip `oin this world.");
					((PlayerInfo*)(peer->data))->canWalkInBlocks = true;
					sendState(peer);
				}
			}
			if (((PlayerInfo*)(peer->data))->effect != 8421376)
			{
				((PlayerInfo*)(peer->data))->effect = ((PlayerInfo*)(peer->data))->effect;
				sendState(peer);
				sendPuncheffectpeer(peer, ((PlayerInfo*)(peer->data))->effect);
			}
	}
}
void sendDrop(ENetPeer* peer, int netID, int x, int y, int item, int count, BYTE specialEffect)
{
	if (item >= maxItems) return;
	if (item < 0) return;
	ENetPeer* currentPeer;
	string name = "";
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			PlayerMoving data;
			data.packetType = 14;
			data.x = x;
			data.y = y;
			data.netID = netID;
			data.plantingTree = item;
			float val = count; // item count
			BYTE val2 = specialEffect;
			BYTE* raw = packPlayerMoving(&data);
			memcpy(raw + 16, &val, 4);
			memcpy(raw + 1, &val2, 1);
			SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		}
	}
}
void DropItem(ENetPeer* peer, int netID, int x, int y, int item, int count, BYTE specialEffect)
{
	WorldInfo* world = getPlyersWorld(peer);
	if (!world) return;
	if (item >= maxItems) return;
	if (item < 0) return;
	if (item == 112 && ((PlayerInfo*)(peer->data))->cloth_hand == 2592)
	{
		if (((PlayerInfo*)(peer->data))->chatnotifications == true)
		{
			Player::OnConsoleMessage(peer, "`2[BONUS] `^You Got `4Double Gems`^!");
		}
		count * 2;
	}
	DroppedItem itemDropped;
	itemDropped.id = item;
	itemDropped.count = count;
	itemDropped.x = x;
	itemDropped.y = y;
	itemDropped.uid = world->droppedItemUid++;
	world->droppedItems.push_back(itemDropped);
	sendDrop(peer, netID, x, y, item, count, specialEffect);
}
void SaveItemMoreTimes(int fItemid, int fQuantity, ENetPeer* peer, bool& success)
{
		size_t invsizee = ((PlayerInfo*)(peer->data))->currentInventorySize;
		bool invfull = false;
		bool alreadyhave = false;
		if (((PlayerInfo*)(peer->data))->inventory.items.size() == invsizee && CheckItemExists(peer, fItemid) == false) {
			GamePacket ps = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "add_label_with_icon|big|`4Whoops!|left|1048|\nadd_spacer|small|\nadd_textbox|`oSoory! Your inventory is full! You can purchase an inventory upgrade in the shop.`5Your item was dropped near to you.|\nadd_spacer|small|\nadd_button|close|`5Close|0|0|"));
			ENetPacket* packet = enet_packet_create(ps.data,
				ps.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			delete ps.data;
			int xx = ((PlayerInfo*)(peer->data))->x + (32 * (((PlayerInfo*)(peer->data))->isRotatedLeft ? -1 : 1));
			int netid = -1;
			int yy = ((PlayerInfo*)(peer->data))->y;
			DropItem(peer, netid, xx, yy, fItemid, fQuantity, 0);
			alreadyhave = true;
		}
		bool isFullStock = false;
		bool isInInv = false;
		for (int i = 0; i < ((PlayerInfo*)(peer->data))->inventory.items.size(); i++)
		{
			if (((PlayerInfo*)(peer->data))->inventory.items.at(i).itemID == fItemid && ((PlayerInfo*)(peer->data))->inventory.items.at(i).itemCount >= 200) {
				GamePacket ps = packetEnd(appendString(appendString(createPacket(), "OnDialogRequest"), "add_label_with_icon|big|`4Whoops!|left|1048|\nadd_spacer|small|\nadd_textbox|`oSoory! You already have full stock of this item!|\nadd_spacer|small|\nadd_button|close|`5Close|0|0|"));
				ENetPacket* packet = enet_packet_create(ps.data,
					ps.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				delete ps.data;
				isFullStock = true;
			}
			if (((PlayerInfo*)(peer->data))->inventory.items.at(i).itemID == fItemid && ((PlayerInfo*)(peer->data))->inventory.items.at(i).itemCount < 200)	isInInv = true;
		}
		if (isFullStock == true || alreadyhave == true)
		{
			success = false;
		}
		else
		{
			try {
				success = true;
				std::ifstream iffff("inventory/" + ((PlayerInfo*)(peer->data))->rawName + ".json");
				json jj;
				if (iffff.fail()) {
					iffff.close();
				}
				if (iffff.is_open()) {
				}
				iffff >> jj; //load
				std::ofstream oo("inventory/" + ((PlayerInfo*)(peer->data))->rawName + ".json");
				if (!oo.is_open()) {
					cout << GetLastError() << endl;
					_getch();
				}
				//jj["items"][aposition]["aposition"] = aposition;
				if (isInInv == false)
				{
					for (int i = 0; i < ((PlayerInfo*)(peer->data))->currentInventorySize; i++)
					{
						int itemid = jj["items"][i]["itemid"];
						int quantity = jj["items"][i]["quantity"];
						if (itemid == 0 && quantity == 0)
						{
							jj["items"][i]["itemid"] = fItemid;
							jj["items"][i]["quantity"] = fQuantity;
							break;
						}
					}
					oo << jj << std::endl;
					InventoryItem item;
					item.itemID = fItemid;
					item.itemCount = fQuantity;
					((PlayerInfo*)(peer->data))->inventory.items.push_back(item);
					sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
				}
				else
				{
					for (int i = 0; i < ((PlayerInfo*)(peer->data))->currentInventorySize; i++)
					{
						int itemid = jj["items"][i]["itemid"];
						int quantity = jj["items"][i]["quantity"];
						if (itemid == fItemid)
						{
							jj["items"][i]["quantity"] = quantity + fQuantity;
							break;
						}
					}
					oo << jj << std::endl;
					//oo.close();
					for (int i = 0; i < ((PlayerInfo*)(peer->data))->inventory.items.size(); i++)
					{
						if (((PlayerInfo*)(peer->data))->inventory.items.at(i).itemID == fItemid)
						{
							((PlayerInfo*)(peer->data))->inventory.items.at(i).itemCount += fQuantity;
							sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
						}
					}
				}
			}
			catch (std::exception& e)
			{
				std::cerr << e.what() << std::endl;
			}
			catch (const std::out_of_range& e) {
				cout << "[try-catch ERROR]: Out of Range error in id == 'wk'" << endl;
			}
			catch (...) {
				cout << "reading file violation" << endl;
			}
		}
}
void GiveChestPrizeItem(ENetPeer* peer, int itemid, int itemAmount, int chestWls)
{
	bool success = false;
	SaveItemMoreTimes(itemid, itemAmount, peer, success);
	if (success)
	{
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`9[LOOT] `^You Have Obtained `9" + getItemDef(itemid).name + "`^."));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
		GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`q" + ((PlayerInfo*)(peer->data))->displayName + " `^Have obtained the `9" + getItemDef(itemid).name + "`^!"), 0));
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
		int effect = 92;
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				int x = ((PlayerInfo*)(peer->data))->x;
				int y = ((PlayerInfo*)(peer->data))->y;
				Player::OnParticleEffect(currentPeer, effect, x, y, 0);
			}
		}
	}
}
void GiveOceanPrize(ENetPeer* peer, int itemid, int itemAmount, int chestWls)
{
	bool success = false;
	SaveItemMoreTimes(itemid, itemAmount, peer, success);
	if (success)
	{
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`1[OCEAN] `^You Have Obtained `9" + getItemDef(itemid).name + "`^."));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
		GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`q" + ((PlayerInfo*)(peer->data))->displayName + " `^Have obtained the `9" + getItemDef(itemid).name + "`^!"), 0));
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
		int effect = 19;
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				int x = ((PlayerInfo*)(peer->data))->x;
				int y = ((PlayerInfo*)(peer->data))->y;
				Player::OnParticleEffect(currentPeer, effect, x, y, 0);
			}
		}
	}
}
void GiveGBCPrize(ENetPeer* peer, int itemid, int itemAmount, int chestWls)
{
	bool success = false;
	SaveItemMoreTimes(itemid, itemAmount, peer, success);
	if (success)
	{
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4[VALENTINE] `^You Have Obtained `9" + getItemDef(itemid).name + "`^."));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
		GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(peer->data))->netID), "`q" + ((PlayerInfo*)(peer->data))->displayName + " `^Have obtained the `9" + getItemDef(itemid).name + "`^!"), 0));
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
		int effect = 19;
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				int x = ((PlayerInfo*)(peer->data))->x;
				int y = ((PlayerInfo*)(peer->data))->y;
				Player::OnParticleEffect(currentPeer, effect, x, y, 0);
			}
		}
	}
}
void joinWorld(ENetPeer* peer, string act, int x2, int y2)
{
	if (((PlayerInfo*)(peer->data))->isBot == true) {
		enet_peer_disconnect_now(peer, 0);
	}
	if (((PlayerInfo*)(peer->data))->isConfirmingCode == true) {
		enet_peer_disconnect_now(peer, 0);
	}
	if (act.length() > 24) {
		Player::OnConsoleMessage(peer, "`4Sorry, but world names with more than 24 characters are not allowed!");
		Player::OnFailedToEnterWorld(peer);
	}
	if (act.length() < 0) {
		Player::OnConsoleMessage(peer, "`4Sorry, but world names less than 0 characters are not allowed!");
		Player::OnFailedToEnterWorld(peer);
	}
	else {
		string upsd = act;
		std::transform(upsd.begin(), upsd.end(), upsd.begin(), ::toupper);
		if (upsd == "CON" || upsd == "PRN" || upsd == "AUX" || upsd == "NUL" || upsd == "COM1" || upsd == "COM2" || upsd == "COM3" || upsd == "COM4" || upsd == "COM5" || upsd == "COM6" || upsd == "COM7" || upsd == "COM8" || upsd == "COM9" || upsd == "LPT1" || upsd == "LPT2" || upsd == "LPT3" || upsd == "LPT4" || upsd == "LPT5" || upsd == "LPT6" || upsd == "LPT7" || upsd == "LPT8" || upsd == "LPT9" || upsd == "con" || upsd == "prn" || upsd == "aux" || upsd == "nul" || upsd == "com1" || upsd == "com2" || upsd == "com3" || upsd == "com4" || upsd == "com5" || upsd == "com6" || upsd == "com7" || upsd == "com8" || upsd == "com9" || upsd == "lpt1" || upsd == "lpt2" || upsd == "lpt3" || upsd == "lpt4" || upsd == "lpt5" || upsd == "lpt6" || upsd == "lpt7" || upsd == "lpt8" || upsd == "lpt9")
		{
			((PlayerInfo*)(peer->data))->currentWorld = "EXIT";
			Player::OnConsoleMessage(peer, "`4To reduce confusion, this is not a valid world name`w. `oTry another one`w?``");
			Player::OnFailedToEnterWorld(peer);
			return;
		}
		if (upsd.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") != string::npos) {
			Player::OnTextOverlay(peer, "Symbols not allowed!");
			Player::OnFailedToEnterWorld(peer);
			return;
		}
		if (upsd == "QQ")
		{
			if (((PlayerInfo*)(peer->data))->level <= 9)
			{
				Player::OnTextOverlay(peer, "You must be at least level 10!");
				Player::OnFailedToEnterWorld(peer);
				return;
			}
		}
		if (std::experimental::filesystem::exists("worlds/" + act + ".json"))
		{
			std::streampos fsize = 0;
			std::ifstream myfile("worlds/" + act + ".json", ios::in);  // File is of type const char*
			fsize = myfile.tellg();         // The file pointer is currently at the beginning
			myfile.seekg(0, ios::end);      // Place the file pointer at the end of file
			fsize = myfile.tellg() - fsize;
			myfile.close();
			static_assert(sizeof(fsize) >= sizeof(long long), "Oops.");
			if (fsize <= 90000)
			{
				Player::OnConsoleMessage(peer, "`4Oh no! ``This world have been corrupted.");
				Player::OnFailedToEnterWorld(peer);
				return;
			}
		}
		using namespace std::chrono;
		if (((PlayerInfo*)(peer->data))->lastJoinReq + 500 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
		{
			((PlayerInfo*)(peer->data))->lastJoinReq = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
		}
		else {
			Player::OnConsoleMessage(peer, "`oSlow down when entering worlds, jeez!``");
			Player::OnFailedToEnterWorld(peer);
			return;
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId == false)
		{
			if (act != "START")
			{
				WorldInfo info1 = worldDB.get("START");
				sendWorld(peer, &info1);
				Player::OnTextOverlay(peer, "`7Create `^Grow-ID `7First!");
				int id = 244;
				int xde = 3040;
				int yde = 736;
				for (int j = 0; j < info1.width * info1.height; j++)
				{
					if (info1.items[j].foreground == 6) {
						xde = (j % info1.width) * 32;
						yde = (j / info1.width) * 32;
					}
				}
				GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(xde) + "|" + std::to_string(yde) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				delete p.data;
				((PlayerInfo*)(peer->data))->netID = cId;
				onPeerConnect(peer);
				cId++;
				sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
				return;
			}
		}
		if (((PlayerInfo*)(peer->data))->isCursed == true)
		{
			if (act != "HELL")
			{
				WorldInfo info1 = worldDB.get("HELL");
				sendWorld(peer, &info1);
				Player::OnTextOverlay(peer, "You are cursed!");
				int id = 244;
				int xde = 3040;
				int yde = 736;
				for (int j = 0; j < info1.width * info1.height; j++)
				{
					if (info1.items[j].foreground == 6) {
						xde = (j % info1.width) * 32;
						yde = (j / info1.width) * 32;
					}
				}
				GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(xde) + "|" + std::to_string(yde) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet);
				delete p.data;
				((PlayerInfo*)(peer->data))->netID = cId;
				onPeerConnect(peer);
				cId++;
				sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
				return;
			}
		}
		WorldInfo info = worldDB.get(act);
		WorldInfo info2 = worldDB.get("HELL");
		WorldInfo info3 = worldDB.get("START");

		int playeriai = getPlayersCountInWorldSave(info.name);
		if (playeriai >= 20)
		{
			Player::OnConsoleMessage(peer, "World is at max capacity. Try again later...");
			Player::OnFailedToEnterWorld(peer);
			return;
		}
		bool existsban = std::experimental::filesystem::exists("worldbans/" + info.name + "/" + ((PlayerInfo*)(peer->data))->rawName);
		if (existsban)
		{
			Player::OnConsoleMessage(peer, "`4Oh no! ``You've been banned from that world by its owner! Try again later after ban wears off.");
			Player::OnFailedToEnterWorld(peer);
			return;
		}
		if (((PlayerInfo*)(peer->data))->isUseCode == false)
		{
			Player::OnConsoleMessage(peer, "`@Your account is `4Not `@Protected, To `^Secure `@Your account `@Wrench on yourself!");
		}
		if (((PlayerInfo*)(peer->data))->haveGrowId)
		{
			if (((PlayerInfo*)(peer->data))->lastdailyGems <= GetCurrentTimeInternalSeconds() / 60)
			{
				((PlayerInfo*)(peer->data))->lastdailyGems = (GetCurrentTimeInternalSeconds() / 60) + 1440; // 1440 - 24 valandos minutemis.
				int haveGems = 0;
				ifstream getgems("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
				getgems >> haveGems;
				getgems.close();
				int gemsReward = 15000;
				haveGems += gemsReward;
				Player::OnConsoleMessage(peer, "`6[REWARD] `^You got `2" + to_string(gemsReward) + " `9Gems `^For joining the server!");
				GamePacket ps2notf = packetEnd(appendInt(appendString(appendString(appendString(appendString(createPacket(), "OnAddNotification"), "interface/science_button.rttex"), "`^You Received `2" + to_string(gemsReward) + " `9Gems `^For joining the server!"), "audio/hub_open.wav"), 0));
				ENetPacket* packet3s = enet_packet_create(ps2notf.data,
					ps2notf.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(peer, 0, packet3s);
				delete ps2notf.data;
				ofstream myfileGems("gemdb/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
				myfileGems << haveGems;
				myfileGems.close();
				ofstream updateLastDailyGems("dailyrewards/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
				updateLastDailyGems << ((PlayerInfo*)(peer->data))->lastdailyGems;
				updateLastDailyGems.close();
			}
			bool iscontains = false;
			SearchInventoryItem(peer, 6336, 1, iscontains);
			if (!iscontains)
			{
				bool success = true;
				SaveItemMoreTimes(6336, 1, peer, success);
				Player::OnAddNotification(peer, "`^You Received the `9Growpedia", "audio/hub_open.wav", "interface/science_button.rttex");
			}

			if (((PlayerInfo*)(peer->data))->timeTogetToken == 0)
			{
				((PlayerInfo*)(peer->data))->timeTogetToken = GetCurrentTimeInternalSeconds() + 10800; // 18000 seconds - 5 hours
			}
			if (((PlayerInfo*)(peer->data))->timeTogetToken <= GetCurrentTimeInternalSeconds())
			{
				bool checkSuccess = false;
				SaveItemMoreTimes(9426, 1, peer, checkSuccess);
				if (!checkSuccess)
				{
					Player::OnConsoleMessage(peer, "`6[REWARD] `@Error issuing a reward!");
				}
				else
				{
					((PlayerInfo*)(peer->data))->timeTogetToken = GetCurrentTimeInternalSeconds() + 10800; // 18000 seconds - 5 hours
					givequestkatanastep3storetoken(peer, 1);
					Player::OnConsoleMessage(peer, "`6[REWARD] `^You Obtained 1 `@Store Token `^For `23 `^hours online in GTOS!");
				}
			}
		}
		sendWorld(peer, &info);
		int x = 3040;
		int y = 736;
		for (int j = 0; j < info.width * info.height; j++)
		{
			if (info.items[j].foreground == 6) {
				x = (j % info.width) * 32;
				y = (j / info.width) * 32;
			}
		}
		if (x2 != 0 && y2 != 0)
		{
			x = x2;
			y = y2;
		}

		if (((PlayerInfo*)(peer->data))->adminLevel >= 777)
		{
			int id = 244;
			GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(x) + "|" + std::to_string(y) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|1\ntype|local\n"));
			ENetPacket* packet = enet_packet_create(p.data,
				p.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			delete p.data;
			((PlayerInfo*)(peer->data))->netID = cId;
			onPeerConnect(peer);
			cId++;
			sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
		}
		else {
			int id = 245;
			GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(x) + "|" + std::to_string(y) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
			ENetPacket* packet = enet_packet_create(p.data,
				p.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			delete p.data;
			((PlayerInfo*)(peer->data))->netID = cId;
			onPeerConnect(peer);
			cId++;
			sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
		}
		WorldInfo* world = getPlyersWorld(peer);
		string nameworld = world->name;
		string ownerworld = world->Displayowner;
		int count = 0;
		ENetPeer* currentPeer;
		string name = "";
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			count++;
		}
		{
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (isHere(peer, currentPeer))
				{
					GamePacket p2 = packetEnd(appendInt(appendString(createPacket(), "OnSetCurrentWeather"), world->weather));
					ENetPacket* packet2 = enet_packet_create(p2.data,
						p2.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(currentPeer, 0, packet2);
					delete p2.data;
					continue;
					int x = ((PlayerInfo*)(peer->data))->x;
					int y = ((PlayerInfo*)(peer->data))->y;
					updateAllClothes(peer);
				}
			}
		}
		int otherpeople = 0;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
				otherpeople++;
		}
		int otherpeoples = otherpeople - 1;
		if (((PlayerInfo*)(peer->data))->isinv == false)
		{
			Player::OnConsoleMessage(peer, "`5<`w" + ((PlayerInfo*)(peer->data))->displayName + "`` `5entered, `w" + std::to_string(otherpeoples) + "`` `5others here>```w");
		}
		if (ownerworld != "") {
			Player::OnConsoleMessage(peer, "`5[`0" + nameworld + " `$World Locked `oby `w" + ownerworld + "`5]");
		}
	}
}
void testCount(ENetPeer* peer) {
	using namespace std::chrono;
	if (((PlayerInfo*)(peer->data))->packetsec + 1000 > (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count()) {
		if (((PlayerInfo*)(peer->data))->packetinsec >= 50) {
			enet_peer_reset(peer);
		}
		else {
			((PlayerInfo*)(peer->data))->packetinsec = ((PlayerInfo*)(peer->data))->packetinsec + 1;
		}
	}
	else {
		((PlayerInfo*)(peer->data))->packetsec = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
		((PlayerInfo*)(peer->data))->packetinsec = 0;
	}
}
void sendNothingHappened(ENetPeer* peer, int x, int y) {
	PlayerMoving data;
	data.netID = ((PlayerInfo*)(peer->data))->netID;
	data.packetType = 0x8;
	data.plantingTree = 0;
	data.netID = -1;
	data.x = x;
	data.y = y;
	data.punchX = x;
	data.punchY = y;
	SendPacketRaw(4, packPlayerMoving(&data), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
}
void sendPlayerToWorld(ENetPeer* peer, PlayerInfo* player, string wrldname)
{
	toUpperCase(wrldname);



	if (wrldname == "CON" || wrldname == "NUL" || wrldname == "PRN" || wrldname == "AUX" || wrldname == "CLOCK$" || wrldname == "COM0" || wrldname == "COM1" || wrldname == "COM2" || wrldname == "COM3" || wrldname == "COM4" || wrldname == "COM5" || wrldname == "COM6" || wrldname == "COM7" || wrldname == "COM8" || wrldname == "COM9" || wrldname == "LPT0" || wrldname == "LPT1" || wrldname == "LPT2" || wrldname == "LPT3" || wrldname == "LPT4" || wrldname == "LPT5" || wrldname == "LPT6" || wrldname == "LPT7" || wrldname == "LPT8" || wrldname == "LPT9")
	{
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`ono"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	else if (((PlayerInfo*)(peer->data))->isConfirmingCode == true) {
		enet_peer_disconnect_now(peer, 0);
	}
	else
	{
		{
			sendPlayerLeave(peer, (PlayerInfo*)(peer->data));
		}
		WorldInfo info = worldDB.get(wrldname);
		sendWorld(peer, &info);
		int x = 3040;
		int y = 736;
		for (int j = 0; j < info.width * info.height; j++)
		{
			if (info.items[j].foreground == 6) {
				x = (j % info.width) * 32;
				y = (j / info.width) * 32;
			}
		}
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(x) + "|" + std::to_string(y) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
		((PlayerInfo*)(peer->data))->netID = cId;
		onPeerConnect(peer);
		cId++;
		sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
	}
}
void sendFrozenState(ENetPeer* peer)
{
	PlayerInfo* info = ((PlayerInfo*)(peer->data));
	int netID = info->netID;
	ENetPeer* currentPeer;
	//int state = getState(info);
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			PlayerMoving data;
			data.packetType = 0x14;
			data.characterState = 0; // animation
			data.x = 1000;
			data.y = 100;
			data.punchX = 0;
			data.punchY = 0;
			data.XSpeed = 300;
			data.YSpeed = 600;
			data.netID = netID;
			data.plantingTree = 2048;
			BYTE* raw = packPlayerMoving(&data);
			int var = info->effect; // placing and breking
			memcpy(raw + 1, &var, 3);
			SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
		}
	}
}
void sendWorldOffers(ENetPeer* peer)
{
	if (!((PlayerInfo*)(peer->data))->isIn) return;
	vector<WorldInfo> worlds = worldDB.getRandomWorlds();
	string worldOffers = "default|";
	if (worlds.size() > 0) {
		worldOffers += worlds[0].name;
	}
	worldOffers += "\nadd_button|Start|START|0.6|3629161471|\n";
	for (int i = 0; i < worlds.size(); i++) {
		worldOffers += "add_floater|" + worlds[i].name + "|" + std::to_string(getPlayersCountInWorld(worlds[i].name)) + "|0.55|3529161471\n";
	}
	GamePacket p3 = packetEnd(appendString(appendString(createPacket(), "OnRequestWorldSelectMenu"), worldOffers));
	ENetPacket* packet3 = enet_packet_create(p3.data,
		p3.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet3);
	delete p3.data;
	//enet_host_flush(server);
}
void playerRespawn(ENetPeer* peer, bool isDeadByTile) {
	int netID = ((PlayerInfo*)(peer->data))->netID;
	if (isDeadByTile == false) {
		Player::OnKilled(peer, ((PlayerInfo*)(peer->data))->netID);
	}
	GamePacket p2x = packetEnd(appendInt(appendString(createPacket(), "OnSetFreezeState"), 0));
	memcpy(p2x.data + 8, &netID, 4);
	int respawnTimeout = 2000;
	int deathFlag = 0x19;
	memcpy(p2x.data + 24, &respawnTimeout, 4);
	memcpy(p2x.data + 56, &deathFlag, 4);
	ENetPacket* packet2x = enet_packet_create(p2x.data,
		p2x.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet2x);
	delete p2x.data;
	GamePacket p5 = packetEnd(appendInt(appendString(createPacket(), "OnSetFreezeState"), 2));
	memcpy(p5.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
	ENetPacket* packet5 = enet_packet_create(p5.data,
		p5.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet5);
	GamePacket p2;
	WorldInfo* world = getPlyersWorld(peer);
	int x = 3040;
	int y = 736;
	if (!world) return;
	for (int i = 0; i < world->width * world->height; i++)
	{
		if (world->items[i].foreground == 6) {
			x = (i % world->width) * 32;
			y = (i / world->width) * 32;
		}
	}
	if (((PlayerInfo*)(peer->data))->ischeck == true) {
		p2 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), ((PlayerInfo*)(peer->data))->checkx, ((PlayerInfo*)(peer->data))->checky));
	}
	else {
		p2 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), x, y));
	}
	memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
	respawnTimeout = 2000;
	memcpy(p2.data + 24, &respawnTimeout, 4);
	memcpy(p2.data + 56, &deathFlag, 4);
	ENetPacket* packet2 = enet_packet_create(p2.data,
		p2.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet2);
	delete p2.data;
	GamePacket p2a = packetEnd(appendString(appendString(createPacket(), "OnPlayPositioned"), "audio/teleport.wav"));
	memcpy(p2a.data + 8, &netID, 4);
	respawnTimeout = 2000;
	memcpy(p2a.data + 24, &respawnTimeout, 4);
	memcpy(p2a.data + 56, &deathFlag, 4);
	ENetPacket* packet2a = enet_packet_create(p2a.data,
		p2a.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet2a);
	delete p2a.data;
}
void sendChatMessage(ENetPeer* peer, int netID, string message)
{
	if (((PlayerInfo*)(peer->data))->currentWorld == "EXIT") return;
	if (((PlayerInfo*)(peer->data))->isIn == false) return;
	if (message.length() >= 80) return;
	if (message.length() == 0) return;
	if (1 > (message.size() - countSpaces(message))) return;
	removeExtraSpaces(message);
	message = trimString(message);
	if (((PlayerInfo*)(peer->data))->haveGrowId == true) {

		string ccode;
		if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
			ccode = "4";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
			ccode = "9";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
			ccode = "4";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
			ccode = "^";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
			ccode = "#";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
			ccode = "5";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
			ccode = "2";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
			ccode = "e";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
			ccode = "b";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
			ccode = "^";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
			ccode = "^";
		}
		if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
			ccode = "^";
		}
		if (((PlayerInfo*)(peer->data))->isNicked == true)
		{
			ccode = "^";
		}
		for (char c : message)
			if (c < 0x18 || std::all_of(message.begin(), message.end(), isspace))
			{
				return;
			}
		ENetPeer* currentPeer;
		string name = "";
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (((PlayerInfo*)(currentPeer->data))->netID == netID)
				name = ((PlayerInfo*)(currentPeer->data))->displayName;
		}
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "CP:_PL:0_OID:_CT:[W]_ `6<`w" + name + "`6> `" + ccode + message));
		GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), netID), "`" + ccode + message), 0));
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
			{
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet);
				//enet_host_flush(server);
				ENetPacket* packet2 = enet_packet_create(p2.data,
					p2.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2);
				//enet_host_flush(server);
			}
		}
		delete p.data;
		delete p2.data;
	}
}
void sendWho(ENetPeer* peer)
{
	ENetPeer* currentPeer;
	string name = "";
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer) && ((PlayerInfo*)(currentPeer->data))->isinv == false)
		{
			GamePacket p2 = packetEnd(appendIntx(appendString(appendIntx(appendString(createPacket(), "OnTalkBubble"), ((PlayerInfo*)(currentPeer->data))->netID), ((PlayerInfo*)(currentPeer->data))->displayName), 1));
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			delete p2.data;
			//enet_host_flush(server);
		}
	}
}
void sendAction(ENetPeer* peer, int netID, string action)
{
	ENetPeer* currentPeer;
	string name = "";
	GamePacket p2 = packetEnd(appendString(appendString(createPacket(), "OnAction"), action));
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			memcpy(p2.data + 8, &netID, 4);
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(currentPeer, 0, packet2);
			//enet_host_flush(server);
		}
	}
	delete p2.data;
}
void SendTake(ENetPeer* peer, int netID, int x, int y, int item)
{
	if (item >= 9999) return;
	if (item < 0) return;
	ENetPeer* currentPeer;
	string name = "";
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (isHere(peer, currentPeer)) {
			PlayerMoving data;
			data.packetType = 14;
			data.x = x;
			data.y = y;
			data.netID = netID;
			data.plantingTree = item;
			BYTE* raw = packPlayerMoving(&data);
			SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_EVENT_TYPE_RECEIVE);
			sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
			raw = NULL;
		}
	}
}
void sendResetState(ENetPeer* peer)
{
	if (((PlayerInfo*)(peer->data))->isCursed)
	{
		PlayerInfo* info = ((PlayerInfo*)(peer->data));
		int netID = info->netID;
		ENetPeer* currentPeer;
		//int state = getState(info);
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				PlayerMoving data;
				data.packetType = 0x14;
				data.characterState = 0; // animation
				data.x = 1000;
				data.y = 100;
				data.punchX = 0;
				data.punchY = 0;
				data.XSpeed = 300;
				data.YSpeed = 600;
				data.netID = netID;
				data.plantingTree = 4096;
				BYTE* raw = packPlayerMoving(&data);
				int var = info->effect; // placing and breking
				memcpy(raw + 1, &var, 3);
				SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
			}
			else
			{
				if (((PlayerInfo*)(peer->data))->isDuctaped)
				{
					PlayerInfo* info = ((PlayerInfo*)(peer->data));
					int netID = info->netID;
					ENetPeer* currentPeer;
					//int state = getState(info);
					for (currentPeer = server->peers;
						currentPeer < &server->peers[server->peerCount];
						++currentPeer)
					{
						if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
							continue;
						if (isHere(peer, currentPeer)) {
							PlayerMoving data;
							data.packetType = 0x14;
							data.characterState = 0; // animation
							data.x = 1000;
							data.y = 100;
							data.punchX = 0;
							data.punchY = 0;
							data.XSpeed = 300;
							data.YSpeed = 600;
							data.netID = netID;
							data.plantingTree = 8192;
							BYTE* raw = packPlayerMoving(&data);
							int var = info->effect; // placing and breking
							memcpy(raw + 1, &var, 3);
							SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
						}
						else
						{
							PlayerMoving data;
							data.packetType = 0x14;
							data.characterState = 0; // animation
							data.x = 1000;
							data.y = 100;
							data.punchX = 0;
							data.punchY = 0;
							data.XSpeed = 300;
							data.YSpeed = 600;
							data.netID = netID;
							data.plantingTree = 2;
							BYTE* raw = packPlayerMoving(&data);
							int var = info->effect; // placing and breking
							memcpy(raw + 1, &var, 3);
							SendPacketRaw(4, raw, 56, 0, currentPeer, ENET_PACKET_FLAG_RELIABLE);
						}
					}
				}
			}
		}
	}
}
void sendPlayerToPlayer(ENetPeer* peer, ENetPeer* otherpeer)
{
	sendPlayerLeave(peer, (PlayerInfo*)(peer->data));
	WorldInfo info = worldDB.get(((PlayerInfo*)(otherpeer->data))->currentWorld);
	sendWorld(peer, &info);
	int x = ((PlayerInfo*)(otherpeer->data))->x;
	int y = ((PlayerInfo*)(otherpeer->data))->y;
	GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(x) + "|" + std::to_string(y) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
	ENetPacket* packet = enet_packet_create(p.data,
		p.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet);
	delete p.data;
	((PlayerInfo*)(peer->data))->netID = cId;
	onPeerConnect(peer);
	cId++;
	sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
}
void sendPlayerToWorld2(ENetPeer* peer, PlayerInfo* player, string wrldname, int x_ = -1, int y_ = -1)
{
	toUpperCase(wrldname);
	if (wrldname == "CON" || wrldname == "NUL" || wrldname == "PRN" || wrldname == "AUX" || wrldname == "CLOCK$" || wrldname == "COM0" || wrldname == "COM1" || wrldname == "COM2" || wrldname == "COM3" || wrldname == "COM4" || wrldname == "COM5" || wrldname == "COM6" || wrldname == "COM7" || wrldname == "COM8" || wrldname == "COM9" || wrldname == "LPT0" || wrldname == "LPT1" || wrldname == "LPT2" || wrldname == "LPT3" || wrldname == "LPT4" || wrldname == "LPT5" || wrldname == "LPT6" || wrldname == "LPT7" || wrldname == "LPT8" || wrldname == "LPT9")
	{
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`eWhoops! `wThis `oworld`w can't be warped to, as it is used by `4System`w.``"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
	}
	else
	{
		{
			sendPlayerLeave(peer, (PlayerInfo*)(peer->data));
		}
		WorldInfo info = worldDB.get(wrldname);
		sendWorld(peer, &info);
		int x = 3040;
		int y = 736;
		for (int j = 0; j < info.width * info.height; j++)
		{
			if (info.items[j].foreground == 6) {
				x = (j % info.width) * 32;
				y = (j / info.width) * 32;
			}
		}
		if (x_ != -1 && y_ != -1) { x = x_ * 32; y = y_ * 32; }
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnSpawn"), "spawn|avatar\nnetID|" + std::to_string(cId) + "\nuserID|" + std::to_string(cId) + "\ncolrect|0|0|20|30\nposXY|" + std::to_string(x) + "|" + std::to_string(y) + "\nname|``" + ((PlayerInfo*)(peer->data))->displayName + "``\ncountry|" + ((PlayerInfo*)(peer->data))->country + "\ninvis|0\nmstate|0\nsmstate|0\ntype|local\n"));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet);
		delete p.data;
		((PlayerInfo*)(peer->data))->netID = cId;
		onPeerConnect(peer);
		cId++;
		sendInventory(peer, ((PlayerInfo*)(peer->data))->inventory);
	}
}
void SendGamePacket(ENetPeer* peer, GamePacket* p)
{
	ENetPacket* packet1 = enet_packet_create(p->data,
		p->len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet1);
}
void DoCancelTransitionAndTeleport(ENetPeer* peer, int x, int y)
{
	GamePacket p = packetEnd(appendInt(appendString(createPacket(), "OnZoomCamera"), 2));
	SendGamePacket(peer, &p);
	GamePacket p2 = packetEnd(appendIntx(appendString(createPacket(), "OnSetFreezeState"), 0));
	memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
	SendGamePacket(peer, &p2);
	GamePacket p3 = packetEnd(appendInt(appendString(createPacket(), "OnFailedToEnterWorld"), 1));
	SendGamePacket(peer, &p3);
	GamePacket p4 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), x * 32, y * 32));
	memcpy(p4.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
	SendGamePacket(peer, &p4);
}
void DoEnterDoor(ENetPeer* peer, WorldInfo* world, int x, int y)
{
	using namespace::std::chrono;
	if (((PlayerInfo*)(peer->data))->lastenterdoor + 1200 < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
	{
		((PlayerInfo*)(peer->data))->lastenterdoor = (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
	}
	else {
		Player::OnConsoleMessage(peer, "slow down before entering doors");
		x = 0;
		y = 0;
		for (int j = 0; j < world->width * world->height; j++)
		{
			if (world->items[j].foreground == 6) {
				x = (j % world->width);
				y = (j / world->width);
			}
		}
		DoCancelTransitionAndTeleport(peer, x, y);
		return;
	}
	int idx = x + world->width * y;
	{
		WorldItem block = world->items[idx];
		if (block.destWorld == "EXIT")
		{
			if (((PlayerInfo*)(peer->data))->canExit)
			{
				string online = "";
				int total = 0;
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (((PlayerInfo*)(currentPeer->data))->adminLevel >= 0) {
						total++;
					}
				}
				Player::OnConsoleMessage(peer, "Where would you like to go? (`w" + to_string(total) + " `oonline)");
				sendPlayerLeave(peer, (PlayerInfo*)(peer->data));
				sendWorldOffers(peer);
				((PlayerInfo*)(peer->data))->currentWorld = "EXIT";
			}
		}
		if (std::experimental::filesystem::exists("worlds/" + block.destWorld + ".json"))
		{
			std::streampos fsize = 0;
			std::ifstream myfile("worlds/" + block.destWorld + ".json", ios::in);  // File is of type const char*
			fsize = myfile.tellg();         // The file pointer is currently at the beginning
			myfile.seekg(0, ios::end);      // Place the file pointer at the end of file
			fsize = myfile.tellg() - fsize;
			myfile.close();
			static_assert(sizeof(fsize) >= sizeof(long long), "Oops.");
			if (fsize <= 90000)
			{
				Player::OnConsoleMessage(peer, "`4Oh no! ``This world have been corrupted.");
				DoCancelTransitionAndTeleport(peer, x, y);
				return;
			}
		}
		if (block.destWorld == "QQ")
		{
			if (((PlayerInfo*)(peer->data))->level <= 9)
			{
				Player::OnTextOverlay(peer, "You must be at least level 10!");
				DoCancelTransitionAndTeleport(peer, x, y);
				return;
			}
		}
		if (block.destWorld == "")
		{
			// it's this world, find a door here
			int x = 0;
			int y = 0;
			for (int i = 0; i < world->width * world->height; i++)
			{
				ItemDefinition def = getItemDef(world->items[i].foreground);
				if (def.blockType == BlockTypes::DOOR) {
					WorldItem blockDest = world->items[i];
					if (blockDest.currId == block.destId)
					{
						x = (i % world->width);
						y = (i / world->width);
						DoCancelTransitionAndTeleport(peer, x, y);
						return;
					}
				}
			}
			x = 0;
			y = 0;
			for (int j = 0; j < world->width * world->height; j++)
			{
				if (world->items[j].foreground == 6) {
					x = (j % world->width);
					y = (j / world->width);
				}
			}
			DoCancelTransitionAndTeleport(peer, x, y);
		}
		else
		{
			try
			{
				WorldInfo worldDest = worldDB.get(block.destWorld);

				bool existsban = std::experimental::filesystem::exists("worldbans/" + block.destWorld + "/" + ((PlayerInfo*)(peer->data))->rawName);
				if (existsban)
				{
					GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4Oh no! ``You've been banned from that world by its owner! Try again later after ban wears off."));
					ENetPacket* packet = enet_packet_create(p.data,
						p.len,
						ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packet);
					delete p.data;
					DoCancelTransitionAndTeleport(peer, x, y);
					return;
				}

				if (block.destId == "")
				{
					int x_ = 0;
					int y_ = 0;
					for (int j = 0; j < worldDest.width * worldDest.height; j++)
					{
						if (worldDest.items[j].foreground == 6) {
							x_ = (j % worldDest.width);
							y_ = (j / worldDest.width);
						}
					}
					sendPlayerToWorld2(peer, ((PlayerInfo*)(peer->data)), block.destWorld, x_, y_);
					return;
				}
				else
				{

					int x_ = 0;
					int y_ = 0;
					bool found = false;
					for (int i = 0; i < worldDest.width * worldDest.height; i++)
					{
						ItemDefinition def = getItemDef(worldDest.items[i].foreground);
						if (def.blockType == BlockTypes::DOOR) {
							WorldItem blockDest = worldDest.items[i];
							if (block.currId == blockDest.destId)
							{
								x_ = (i % world->width);
								y_ = (i / world->width);
								sendPlayerToWorld2(peer, ((PlayerInfo*)(peer->data)), block.destWorld, x_, y_);
								found = true;
								break;
							}
						}
					}
					if (!found)
					{
						int x = 0;
						int y = 0;
						for (int j = 0; j < worldDest.width * worldDest.height; j++)
						{
							if (worldDest.items[j].foreground == 6) {
								x = (j % worldDest.width);
								y = (j / worldDest.width);
							}
						}
						sendPlayerToWorld2(peer, ((PlayerInfo*)(peer->data)), block.destWorld, x, y);
					}
				}
			}
			catch (int e)
			{
				DoCancelTransitionAndTeleport(peer, x, y);
			}
		}
	}
	GamePacket p5 = packetEnd(appendInt(appendString(createPacket(), "OnSetFreezeState"), 0));
	memcpy(p5.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
	ENetPacket* packet5 = enet_packet_create(p5.data,
		p5.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet5);
	enet_host_flush(server);
	GamePacket p4 = packetEnd(appendIntx(appendString(createPacket(), "OnFailedToEnterWorld"), 1));
	ENetPacket* packet4 = enet_packet_create(p4.data,
		p4.len,
		ENET_PACKET_FLAG_RELIABLE);
	enet_peer_send(peer, 0, packet4);
	enet_host_flush(server);
}
void WhiteDoor(int x, int y, int tile, int causedBy, ENetPeer* peer)
{
	PlayerMoving data;
	//data.packetType = 0x14;
	data.packetType = 0x3;
	//data.characterState = 0x924; // animation
	data.characterState = 0x0; // animation
	data.x = x;
	data.y = y;
	data.punchX = x;
	data.punchY = y;
	data.XSpeed = 0;
	data.YSpeed = 0;
	data.netID = causedBy;
	data.plantingTree = tile;
	WorldInfo* world = getPlyersWorld(peer);
	if (world->items[x + (y * world->width)].foreground == 6)
	{
		if (((PlayerInfo*)(peer->data))->canExit)
		{
			string online = "";
			int total = 0;
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (((PlayerInfo*)(currentPeer->data))->adminLevel >= 0) {
					total++;
				}
			}
			Player::OnConsoleMessage(peer, "Where would you like to go? (`w" + to_string(total) + " `oonline)");
			sendPlayerLeave(peer, (PlayerInfo*)(peer->data));
			sendWorldOffers(peer);
			((PlayerInfo*)(peer->data))->currentWorld = "EXIT";
		}
	}
}
void CheckPlayerState(ENetPeer* peer)
{
	using namespace std::chrono;

	while (1)
	{
		Sleep(60000); // each 1 minute check

		if (peer->data == NULL) break;


		if (((PlayerInfo*)(peer->data))->currentWorld == "EXIT") continue;

		// check if cursed
		if (((PlayerInfo*)(peer->data))->isCursed == true)
		{
			long kiekDar = ((PlayerInfo*)(peer->data))->lastCursed - (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
			long min = kiekDar / 60000;
			ofstream fs("cursedplayers/" + ((PlayerInfo*)(peer->data))->rawName + ".txt");
			fs << min;
			fs.close();
			if (((PlayerInfo*)(peer->data))->lastCursed < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
			{
				if (std::experimental::filesystem::exists("cursedplayers/" + ((PlayerInfo*)(peer->data))->rawName + ".txt"))
				{
					Player::OnTextOverlay(peer, "`^Your `4Curse `^Has `2Expired, `4Don't `^Break `2Rules `^Anymore!");
					Player::OnConsoleMessage(peer, "`^Your `4Curse `^Has `2Expired, `4Don't `^Break `2Rules `^Anymore!");

					((PlayerInfo*)(peer->data))->skinColor = 0x8295C3FF;
					sendClothes(peer);
					((PlayerInfo*)(peer->data))->isCursed = false;
					sendState(peer);

					remove(("cursedplayers/" + ((PlayerInfo*)(peer->data))->rawName + ".txt").c_str());
					sendPlayerToWorld(peer, (PlayerInfo*)(peer->data), "START");
				}
			}
		}

		//check if muted isDuctaped
		if (((PlayerInfo*)(peer->data))->isDuctaped == true)
		{
			long kiekDar = ((PlayerInfo*)(peer->data))->lastMuted - (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count();
			long min = kiekDar / 60000;
			ofstream saveMuteTime("timemuted/" + PlayerDB::getProperName(((PlayerInfo*)(peer->data))->rawName) + ".txt");
			saveMuteTime << min;
			saveMuteTime.close();
			if (((PlayerInfo*)(peer->data))->lastMuted < (duration_cast<milliseconds>(system_clock::now().time_since_epoch())).count())
			{
				if (std::experimental::filesystem::exists("timemuted/" + ((PlayerInfo*)(peer->data))->rawName + ".txt"))
				{
					Player::OnTextOverlay(peer, "`^Your `4Mute `^Has `2Expired, `4Don't `^Break `2Rules `^Anymore!");
					Player::OnConsoleMessage(peer, "`^Your `4Mute `^Has `2Expired, `4Don't `^Break `2Rules `^Anymore!");
					((PlayerInfo*)(peer->data))->taped = false;
					((PlayerInfo*)(peer->data))->isDuctaped = false;
					((PlayerInfo*)(peer->data))->cantsay = false;
					sendState(peer);
					sendClothes(peer);
					remove(("timemuted/" + ((PlayerInfo*)(peer->data))->rawName + ".txt").c_str());
				}
			}
		}


	}
}
/*void checkmem()
{
	while (1)
	{
		Sleep(600000);
		MEMORYSTATUSEX memInfo;
		PROCESS_MEMORY_COUNTERS_EX pmc;
		GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));
		SIZE_T virtualMemUsedByMe = pmc.PrivateUsage;
		int realmb = virtualMemUsedByMe / 1024;
		int superrealmb = realmb / 1024;
		if (superrealmb >= 2000)
		{
			GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`4SERVER OVERLOADED, RESTARTING SERVER."));
			string text = "action|play_sfx\nfile|audio/sungate.wav\ndelayMS|0\n";
			BYTE* data = new BYTE[5 + text.length()];
			BYTE zero = 0;
			int type = 3;
			memcpy(data, &type, 4);
			memcpy(data + 4, text.c_str(), text.length());
			memcpy(data + 4 + text.length(), &zero, 1);
			ENetPeer* currentPeer;
			for (currentPeer = server->peers;
				currentPeer < &server->peers[server->peerCount];
				++currentPeer)
			{
				if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
					continue;
				if (!((PlayerInfo*)(currentPeer->data))->radio)
					continue;
				ENetPacket* packet = enet_packet_create(p.data,
					p.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet);
				ENetPacket* packet2 = enet_packet_create(data,
					5 + text.length(),
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packet2);
				//enet_host_flush(server);
			}
			delete data;
			delete p.data;
			saveAllWorlds();
			Sleep(3000);
			abort();
		}
	}
}*/

void SendTips()
{
	while (1)
	{
		Sleep(600000); // 10 minutes in mili s.
		string text2 = "action|play_sfx\nfile|audio/beep.wav\ndelayMS|0\n";
		BYTE* data2 = new BYTE[5 + text2.length()];
		BYTE zero2 = 0;
		int type2 = 3;
		memcpy(data2, &type2, 4);
		memcpy(data2 + 4, text2.c_str(), text2.length());
		memcpy(data2 + 4 + text2.length(), &zero2, 1);
		ENetPacket* packet22 = enet_packet_create(data2,
			5 + text2.length(),
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet22);

		const unsigned short totalTips = 7;
		string tips[totalTips] = { "If you want to sell the world, then wrench another player and choose 'Sell World'","Wanna report a player or ask a question? use /report <text>. (for mods to answer /ans <growid> <text>). Or report in our discord 'REPORT' channel.","Wanna get free rank? Or choose your skill? Use GrowPedia, that is in your inventory!","Read /rules to know all server's rules and not get punished.","Want enable game notifications? (such as [found] [loot]), type /chat.","Record a video of all your trades with other players. if you got scammed, you will have proof of this and that player will be punished.","Don't forget to enable security code if you didn't do it yet (wrench yourself - account security - code)" };

		string tip = tips[tipqueue];

		if (tipqueue >= totalTips - 1)
		{
			tipqueue = 0;
		}
		else
		{
			tipqueue++;
		}
		GamePacket p222 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`w[`4TIP`w] `5" + tip + ""));
		ENetPacket* packet222 = enet_packet_create(p222.data,
			p222.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet222);
		delete data2;
		delete p222.data;

	}
}
void autoSaveWorlds() {
	while (1) {
		Sleep(3540000);
		string text2 = "action|play_sfx\nfile|audio/beep.wav\ndelayMS|0\n";
		BYTE* data2 = new BYTE[5 + text2.length()];
		BYTE zero2 = 0;
		int type2 = 3;
		memcpy(data2, &type2, 4);
		memcpy(data2 + 4, text2.c_str(), text2.length());
		memcpy(data2 + 4 + text2.length(), &zero2, 1);
		ENetPacket* packet22 = enet_packet_create(data2,
			5 + text2.length(),
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet22);
		GamePacket p222 = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`w[`4SYSTEM`w] `5Auto clear drop in a minute. Pick up them."));
		ENetPacket* packet222 = enet_packet_create(p222.data,
			p222.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet222);
		delete data2;
		delete p222.data;
		Sleep(60000);
		string text = "action|play_sfx\nfile|audio/beep.wav\ndelayMS|0\n";
		BYTE* data = new BYTE[5 + text.length()];
		BYTE zero = 0;
		int type = 3;
		memcpy(data, &type, 4);
		memcpy(data + 4, text.c_str(), text.length());
		memcpy(data + 4 + text.length(), &zero, 1);
		ENetPacket* packet2 = enet_packet_create(data,
			5 + text.length(),
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet2);
		GamePacket p = packetEnd(appendString(appendString(createPacket(), "OnConsoleMessage"), "`w[`4SYSTEM`w] `5Auto Saving All Worlds..."));
		ENetPacket* packet = enet_packet_create(p.data,
			p.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_host_broadcast(server, 0, packet);
		delete data;
		delete p.data;
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
		}
		Sleep(500);
		saveAllWorlds();
	}
}
void Respawn(ENetPeer* peer) {
	int x = 3040;
	int y = 736;
	WorldInfo* world = getPlyersWorld(peer);
	if (world)
	{
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer)) {
				int x = ((PlayerInfo*)(peer->data))->x;
				int y = ((PlayerInfo*)(peer->data))->y;
				GamePacket psp = packetEnd(appendFloat(appendIntx(appendString(createPacket(), "OnParticleEffect"), 3), x, (y + 8)));
				ENetPacket* packetd = enet_packet_create(psp.data,
					psp.len,
					ENET_PACKET_FLAG_RELIABLE);
				enet_peer_send(currentPeer, 0, packetd);
				delete psp.data;
				string text = "action|play_sfx\nfile|audio/male_scream.wav\ndelayMS|0\n";
				BYTE* data = new BYTE[5 + text.length()];
				BYTE zero = 0;
				int type = 3;
				memcpy(data, &type, 4);
				memcpy(data + 4, text.c_str(), text.length());
				memcpy(data + 4 + text.length(), &zero, 1);
				{
					ENetPacket* packetres = enet_packet_create(data,
						5 + text.length(),
						ENET_PACKET_FLAG_RELIABLE);
					if (isHere(peer, currentPeer)) {
						enet_peer_send(currentPeer, 0, packetres);
					}
				}
			}
		}
		for (int i = 0; i < world->width * world->height; i++)
		{
			if (world->items[i].foreground == 6) {
				x = (i % world->width) * 32;
				y = (i / world->width) * 32;
				//world->items[i].foreground = 8;
			}
		}
		{
			PlayerMoving data;
			data.packetType = 0x0;
			data.characterState = 0x924; // animation
			data.x = x;
			data.y = y;
			data.punchX = -1;
			data.punchY = -1;
			data.XSpeed = 0;
			data.YSpeed = 0;
			data.netID = ((PlayerInfo*)(peer->data))->netID;
			data.plantingTree = 0x0; // 0x0
			SendPacketRaw(4, packPlayerMoving(&data), 56, 0, peer, ENET_PACKET_FLAG_RELIABLE);
		}
		{
			int x = 3040;
			int y = 736;
			for (int i = 0; i < world->width * world->height; i++)
			{
				if (world->items[i].foreground == 6) {
					x = (i % world->width) * 32;
					y = (i / world->width) * 32;
					//world->items[i].foreground = 8;
				}
			}
			GamePacket p2 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), x, y));
			memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			delete p2.data;
			//enet_host_flush(server);
		}
		{
			int x = 3040;
			int y = 736;
			for (int i = 0; i < world->width * world->height; i++)
			{
				if (world->items[i].foreground == 6) {
					x = (i % world->width) * 32;
					y = (i / world->width) * 32;
					//world->items[i].foreground = 8;
				}
			}
			GamePacket p2 = packetEnd(appendIntx(appendString(createPacket(), "OnSetFreezeState"), 0));
			memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
			ENetPacket* packet2 = enet_packet_create(p2.data,
				p2.len,
				ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet2);
			delete p2.data;
			enet_host_flush(server);
		}
	}
	if (((PlayerInfo*)(peer->data))->usedCP == false)
	{
		GamePacket p2 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), x, y));
		memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
	}
	else
	{
		GamePacket p2 = packetEnd(appendFloat(appendString(createPacket(), "OnSetPos"), ((PlayerInfo*)(peer->data))->cpX, ((PlayerInfo*)(peer->data))->cpY));
		memcpy(p2.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
		ENetPacket* packet2 = enet_packet_create(p2.data,
			p2.len,
			ENET_PACKET_FLAG_RELIABLE);
		enet_peer_send(peer, 0, packet2);
		delete p2.data;
	}
}
BOOL WINAPI HandlerRoutine(DWORD dwCtrlType)
{
	saveAllWorlds();
	return FALSE;
}
void FindGeiger(ENetPeer* peer)
{
	WorldInfo* world = getPlyersWorld(peer);

	ENetPeer* currentPeer;
	for (currentPeer = server->peers;
		currentPeer < &server->peers[server->peerCount];
		++currentPeer)
	{
		if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
			continue;
		if (world->geigerX == 0 && world->geigerY == 0)
		{
			srand(GetTickCount());
			int geigercounterx = rand() % 3000;
			int geigercountery = rand() % 1500;
			world->geigerX = geigercounterx;
			world->geigerY = geigercountery;
		}
		if (((PlayerInfo*)(peer->data))->x >= world->geigerX - 30 && ((PlayerInfo*)(peer->data))->x <= world->geigerX + 30 && ((PlayerInfo*)(peer->data))->y >= world->geigerY - 30 && ((PlayerInfo*)(peer->data))->y <= world->geigerY + 30)
		{
			int x = ((PlayerInfo*)(peer->data))->x;
			int y = ((PlayerInfo*)(peer->data))->y;
			Player::OnParticleEffect(peer, 200, x, y, 0);
			std::vector<int> list{ 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 2242, 2244, 2242, 2244, 2246, 2248, 2250, 2242, 2244, 2246, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 2242, 2244, 2246, 2248, 2250, 2242, 2244, 2246, 2248, 2250, 2242, 2244, 2246, 2248, 2250, 112, 9512, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 2242, 2244, 2246, 2248, 2250 };
			int index = rand() % list.size();
			int value = list[index];
			if (value == 2242) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found red crystal!", 0, true);
				bool success = true;
				SaveItemMoreTimes(2242, 1, peer, success);
			}
			else if (value == 2244) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found green crystal!", 0, true);
				bool success = true;
				SaveItemMoreTimes(2244, 1, peer, success);
			}
			else if (value == 2246) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found blue crystal!", 0, true);
				bool success = true;
				SaveItemMoreTimes(2246, 1, peer, success);
			}
			else if (value == 2248) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found white crystal!", 0, true);
				bool success = true;
				SaveItemMoreTimes(2248, 1, peer, success);
			}
			else if (value == 2250) {
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found black crystal!", 0, true);
				bool success = true;
				SaveItemMoreTimes(2250, 1, peer, success);
			}
			else if (value == 112)
			{
				if (((PlayerInfo*)(peer->data))->cloth_necklace == 9512)
				{
					int gemChance = rand() % 6000;
					GiveChestPrizeGems(peer, gemChance);
				}
				else {
					int gemChance = rand() % 3000;
					GiveChestPrizeGems(peer, gemChance);
				}
			}
			else if (value == 9512)
			{
				Player::OnTalkBubble(peer, ((PlayerInfo*)(peer->data))->netID, "You found geiger necklace!", 0, true);
				bool success = true;
				SaveItemMoreTimes(9512, 1, peer, success);
			}
			srand(GetTickCount());
			int geigercounterx = rand() % 3000;
			int geigercountery = rand() % 1500;
			world->geigerX = geigercounterx;
			world->geigerY = geigercountery;
		}
		else {
			int checkx = world->geigerX - ((PlayerInfo*)(peer->data))->x;
			int checky = ((PlayerInfo*)(peer->data))->y - world->geigerY;
			int x = ((PlayerInfo*)(peer->data))->x;
			int y = ((PlayerInfo*)(peer->data))->y;
			if (checkx > 200 || checkx < -200)
			{
				Player::OnParticleEffect(peer, 116, x, y, 0);
			}
			else if (checky > 200 || checky < -200)
			{
				Player::OnParticleEffect(peer, 116, x, y, 0);
			}
			else
			{
				Player::OnParticleEffect(peer, 345, x, y, 0);
			}
		}
	}
}
void updateplayerset(ENetPeer* peer, int targetitem)
{
	int clothitem = ((PlayerInfo*)(peer->data))->cloth_hand;
	int clothface = ((PlayerInfo*)(peer->data))->cloth_face;
	int clothneck = ((PlayerInfo*)(peer->data))->cloth_necklace;
	int clothshirt = ((PlayerInfo*)(peer->data))->cloth_shirt;
	int clothback = ((PlayerInfo*)(peer->data))->cloth_back;
	int clothances = ((PlayerInfo*)(peer->data))->cloth_ances;
	int clothpants = ((PlayerInfo*)(peer->data))->cloth_pants;
	int clothfeet = ((PlayerInfo*)(peer->data))->cloth_feet;
	int clothhair = ((PlayerInfo*)(peer->data))->cloth_hair;
	int clothmask = ((PlayerInfo*)(peer->data))->cloth_mask;
	int item = targetitem;

	if (clothmask == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_mask = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothitem == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_hand = 0;
			sendClothes(peer);
			((PlayerInfo*)(peer->data))->effect = 8421376;
			sendPuncheffectpeer(peer, ((PlayerInfo*)(peer->data))->effect);
		}
		else {

		}
	}

	if (clothface == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_face = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothneck == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_necklace = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothshirt == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_shirt = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothback == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_back = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothances == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_ances = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothpants == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_pants = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothfeet == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_feet = 0;
			sendClothes(peer);
		}
		else {

		}
	}

	if (clothhair == item)
	{
		bool iscontains = false;
		SearchInventoryItem(peer, item, 1, iscontains);
		if (!iscontains)
		{
			((PlayerInfo*)(peer->data))->cloth_hair = 0;
			sendClothes(peer);
		}
		else {

		}
	}
}
void updateworldremove(ENetPeer* peer) {
	/*if (((PlayerInfo*)(peer->data))->isNicked == true)
	{
		((PlayerInfo*)(peer->data))->isNicked = false;
		((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->displayNamebackup;
		GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->displayNamebackup));
		memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
		ENetPacket* packet7 = enet_packet_create(p7.data,
			p7.len,
			ENET_PACKET_FLAG_RELIABLE);
		ENetPeer* currentPeer;
		for (currentPeer = server->peers;
			currentPeer < &server->peers[server->peerCount];
			++currentPeer)
		{
			if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
				continue;
			if (isHere(peer, currentPeer))
			{
				if (((PlayerInfo*)(peer->data))->adminLevel >= 0) {
					enet_peer_send(currentPeer, 0, packet7);
				}
			}
		}
		delete p7.data;
	}*/
	if (((PlayerInfo*)(peer->data))->isNicked == false)
	{
		if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
			{
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4);
				if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 0) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
			{
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 111) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 222) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 333) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 444) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 555) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 666) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`#@" + ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 777) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`q@" + ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 888) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`@@" + ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 998) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
			{
				//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
				GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`4@" + ((PlayerInfo*)(peer->data))->tankIDName));
				memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
				if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
					((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
				}
				ENetPacket* packet7 = enet_packet_create(p7.data,
					p7.len,
					ENET_PACKET_FLAG_RELIABLE);
				ENetPeer* currentPeer;
				for (currentPeer = server->peers;
					currentPeer < &server->peers[server->peerCount];
					++currentPeer)
				{
					if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
						continue;
					if (isHere(peer, currentPeer)) {
						if (((PlayerInfo*)(peer->data))->adminLevel == 999) {
							enet_peer_send(currentPeer, 0, packet7);
						}
					}
				}
				delete p7.data;
			}
		}
		else if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
			{
				if (((PlayerInfo*)(peer->data))->isCreator == true) {
					//string name2 = "``" + str.substr(6, cch.length() - 6 - 1);
					GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`c@" + ((PlayerInfo*)(peer->data))->tankIDName));
					memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
					if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
					ENetPacket* packet7 = enet_packet_create(p7.data,
						p7.len,
						ENET_PACKET_FLAG_RELIABLE);
					ENetPeer* currentPeer;
					for (currentPeer = server->peers;
						currentPeer < &server->peers[server->peerCount];
						++currentPeer)
					{
						if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
							continue;
						if (isHere(peer, currentPeer)) {
							if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
								enet_peer_send(currentPeer, 0, packet7);
							}
						}
					}
					delete p7.data;
				}
				else {
					GamePacket p7 = packetEnd(appendString(appendString(createPacket(), "OnNameChanged"), "`9@" + ((PlayerInfo*)(peer->data))->tankIDName));
					memcpy(p7.data + 8, &(((PlayerInfo*)(peer->data))->netID), 4); // ffloor
					if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
						((PlayerInfo*)(peer->data))->displayName = ((PlayerInfo*)(peer->data))->tankIDName;
					}
					ENetPacket* packet7 = enet_packet_create(p7.data,
						p7.len,
						ENET_PACKET_FLAG_RELIABLE);
					ENetPeer* currentPeer;
					for (currentPeer = server->peers;
						currentPeer < &server->peers[server->peerCount];
						++currentPeer)
					{
						if (currentPeer->state != ENET_PEER_STATE_CONNECTED)
							continue;
						if (isHere(peer, currentPeer)) {
							if (((PlayerInfo*)(peer->data))->adminLevel == 1000) {
								enet_peer_send(currentPeer, 0, packet7);
							}
						}
					}
					delete p7.data;
				}
			}
		}
	}
}